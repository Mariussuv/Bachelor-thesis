﻿﻿using System;

namespace Backend.Models
{
    internal class ReducerAttribute : Attribute
    {
    }
}