﻿namespace Backend.Models
{
    public class VerifyTokenModel
    {
        public VerifyTokenModel(){}
        public string UserId { get; set; }
        public string Token { get; set; }
    }
}