﻿namespace Backend.Models
{
    public class InviteModel
    {
        public string UserId { get; set; }
        public string Token { get; set; }
        
        public string InvitedUserId { get; set; }
        public int EventId { get; set; }    
    }
}