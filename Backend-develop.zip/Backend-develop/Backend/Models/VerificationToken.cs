﻿using System;

namespace Backend.Models
{
    public class VerificationToken
    {
        /*
         * Containing data about user tokens and validity
         */
        private int TokenLength = 12;
        
        public VerificationToken(string userId)
        {
            UserId = userId;
            ValidTo = DateTime.Now.AddYears(1);

            var rand = new Random();
            for (var i = 0; i < TokenLength; i++)
            {
                Token += rand.Next(10);
            }
        }
        public int Id { get; set; }

        public string Token { get; set; }
        public DateTime ValidTo { get; set; }
        public String UserId { get; set; }
    }
}