﻿namespace Backend.Models
{
    public class GroupEditModel
    {
        /*
         * Class for editing groups. Use action to specify what you want to do
         */
        public GroupEditModel(){}
        
        public ApplicationGroup Group { get; set; }
        public string UserId { get; set; }
        public string Token { get; set; }
    }
}