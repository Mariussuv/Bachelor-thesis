﻿using System.ComponentModel.DataAnnotations;

namespace Backend.Models
{
    public class EventInvitation
    {
        public EventInvitation(){}
        public EventInvitation(ApplicationUser u, Event e)
        {
            User = u;
            UserId = u.Id;

            Event = e;
            EventId = e.Id;
            Status = Statuses.NotAnswered;
        }
        
        [Key]
        public int Id { get; set; }
        
        public string UserId { get; set; }
        public ApplicationUser User { get; set; }
        
        public int EventId { get; set; }
        public Event Event { get; set; }
        
        public Statuses Status { get; set; }
        
        //enum to set status of given invitation
        public enum Statuses
        {
            NotAnswered,
            Attending,
            NotAttending
        }
    }
}