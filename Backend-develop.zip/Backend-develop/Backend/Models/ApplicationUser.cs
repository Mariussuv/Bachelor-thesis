﻿﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
 using Microsoft.AspNetCore.Identity;

namespace Backend.Models
{
    //this is the model for normal users
    public class ApplicationUser : IdentityUser
    {
        public ApplicationUser(string phoneNr, string firstName, string lastName, string email)
        {
            PhoneNumber = phoneNr;
            FirstName = firstName;
            LastName = lastName;
            Email = email;
            UserName = email;
        }
        public ApplicationUser(){}
        
        [Required]
        public string FirstName { get; set; }
        
        [Required]
        public string LastName { get; set; }
        
        public string ExternalLogin { get; set; }
        
        public string ExternalLoginToken { get; set; }
        
        public string ExternalId { get; set; }
        
        public string ImageUri { get; set; }
    }
}
