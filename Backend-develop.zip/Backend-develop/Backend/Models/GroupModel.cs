﻿using System.Collections.Generic;

namespace Backend.Models
{
    public class GroupModel
    {
        public GroupModel(){}
        public string userId { get; set; }
        public string token { get; set; }
        public string Name { get; set; }
        public List<string> MemberIds { get; set; }
        public string Description { get; set; }
        public string ImageUri { get; set; }
    }
}