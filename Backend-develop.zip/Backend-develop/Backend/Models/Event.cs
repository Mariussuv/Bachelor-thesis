﻿﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Backend.Models
{
    public class Event
    {
        public Event() { }

        public Event(string title, string description, string location, 
            DateTime dateTime, string ownerId)
        {
            Title = title;
            Description = description;
            Location = location;
            DateTime = dateTime;
            OwnerId = ownerId;
        }
        public int Id { get; set; }
        
        [Required]
        public string Title { get; set; }
        public string Description { get; set; }    
        public string Location { get; set; }
        
        public string ImageUri { get; set; }
        
        public DateTime DateTime { get; set; }
        public string OwnerId { get; set; }
    }
}
