namespace Backend.Models
{
    public class EventModel
    {
        public string UserId { get; set; }
        public string Token { get; set; }
        public Event Event { get; set; }
    }
}