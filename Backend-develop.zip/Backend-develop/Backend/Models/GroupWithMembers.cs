using System;
using System.Collections.Generic;

namespace Backend.Models
{
    public class GroupWithMembers
    {
        public GroupWithMembers(){}

        public GroupWithMembers(ApplicationGroup group, List<ApplicationUser> users)
        {
            Group = group;
            Users = users;
        }
        
        public ApplicationGroup Group { get; set; }
        public List<ApplicationUser> Users { get; set; }
    }
}