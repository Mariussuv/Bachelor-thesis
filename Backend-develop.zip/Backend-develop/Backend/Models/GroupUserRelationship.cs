﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Backend.Models
{
    public class GroupUserRelationship
    {
        public GroupUserRelationship(){}
        [Key]
        public int Id { get; set; }
        public string UserId { get; set; }
        public ApplicationUser ApplicationUser { get; set; }

        public int GroupId { get; set; }
        public ApplicationGroup ApplicationGroup { get; set; }
    }
}