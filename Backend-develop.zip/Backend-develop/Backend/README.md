#Backend
##Deploy to server
    
 - Push code to a remote branch
 - Log into server from cmd:
 
       ssh root@167.172.186.184
       
 - Change directory to mad2020/Backend
       
 - Pull from develop or checkout your branch
    
       git fetch
       git checkout <Branch>
       
 - Stop server
 
       docker-compose down
       
 - If db is updated, and we're not in production, delete db-image
 
       docker volume ls
       docker volume rm <name>
       
 - Build new image
 
       docker-compose build
       
 - Run container
 
       docker-compose up