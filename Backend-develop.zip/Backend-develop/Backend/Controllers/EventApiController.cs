﻿﻿using System.Collections.Generic;
 using System.Linq;
 using System.Threading.Tasks;
 using Microsoft.AspNetCore.Mvc;
using Backend.Models;
using Backend.Data;
using Backend.BusinessLogic;
 using Microsoft.AspNetCore.Hosting;
 using Microsoft.AspNetCore.Http;
 using Microsoft.AspNetCore.Identity;
 using Microsoft.Extensions.Logging;

 namespace Backend.Controllers
{
    [Route("api/event")]
    [ApiController]
    public class EventApiController : ControllerBase
    {
        private readonly ApplicationDbContext _db;
        private readonly EventLogic _logic;
        private readonly VerifyController _vc;
        private readonly ILogger<EventApiController> _log;

        public EventApiController(ApplicationDbContext db, UserManager<ApplicationUser> um, 
            ILogger<EventApiController> log, IWebHostEnvironment webHostEnvironment)
        {
            _db = db;
            _logic = new EventLogic(db, webHostEnvironment);
            _vc = new VerifyController(db,um);
            _log = log;
        }
        
        //get all event
        [HttpPost]
        [Route("events")]
        public IActionResult Get(VerifyTokenModel model)
        {
            if (!_vc.CheckToken(model.Token, model.UserId))
            {
                _log.LogInformation("Authorization failed: Get all");
                return Unauthorized();
            }
            
            List<Event> e = _db.Events.ToList();
            return Ok(e);
        }

        //get one event
        [HttpPost]
        [Route("id/{id}")]
        public IActionResult Get(int id,[FromBody] VerifyTokenModel model)
        {
            if (!_vc.CheckToken(model.Token, model.UserId))
            {
                _log.LogInformation("Authorization failed: Get one event");
                return Unauthorized();
            }
            var e = _logic.GetEvent(id);

            if (e == null)
            {
                _log.LogInformation("Could not find event");
                return NotFound();
            }
            
            return Ok(e);
        }

        
        [HttpPost]
        public IActionResult Post(EventModel model)
        {
            if (!_vc.CheckToken(model.Token, model.UserId))
                {
                _log.LogInformation("Authorization failed: Post event");
                return Unauthorized("User could not be authenticated.");
            }

            if (model.Event.Id != 0)
            {
                _log.LogInformation("Posted event contains id");
                return BadRequest();
            }

            var e = model.Event;
            
            _db.Events.Add(e);
            _db.SaveChanges();

            return Ok(e);   
        }
        
        /**
         * Uploads an image to server an links it to an event.
         * Returns event
         */
        [HttpPost("{eventId}/image/userId/{userId}")]
        public async Task<IActionResult> PostEventImage(int eventId, string userId, IFormFile image)
        {
            if (image == null)
            {
                _log.LogInformation("No image received for event with id: " + eventId);
                return Content("Error: No image received.");
            }
            
            var e = _logic.GetEvent(eventId);

            if (e == null)
            {
                _log.LogInformation("Could not find the event with eventId: " + eventId);
                return NotFound();
            }

            if (userId != e.OwnerId)
            {
                _log.LogInformation("UserId and ownerId do not match on event. Cannot add image.");
                return BadRequest();
            }

            var eventWithImage = await _logic.AddEventImage(e, image);
            return Ok(eventWithImage);
        }
        
        //Edit an event
        [HttpPut]
        [Route("edit")]
        public IActionResult Edit(EventModel model)
        {
            if (!_vc.CheckToken(model.Token, model.UserId))
            {
                _log.LogInformation("Authorization failed: Edit event");
                return Unauthorized();
            }
            if (model.Event.Id == 0) return BadRequest();
            
            var e = _logic.EditEvent(model);

            if (e == null)
            {
                _log.LogInformation("Something went wrong while editing event");
                return BadRequest();
            }
            return Ok(e);
        }

        [HttpDelete]
        [Route("{eventId}")]
        public IActionResult Delete(int eventId, [FromBody] VerifyTokenModel model)
        {
            if (!_vc.CheckToken(model.Token, model.UserId))
            {
                _log.LogInformation("Authorization failed: delete event");
                return Unauthorized();
            }

            if (!_logic.DeleteEvent(eventId, model.UserId))
                return BadRequest();

            return Ok(eventId);
        }
    }
}