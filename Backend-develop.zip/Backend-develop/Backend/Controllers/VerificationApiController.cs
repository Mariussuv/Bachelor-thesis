﻿using Backend.Data;
using Backend.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Backend.Controllers
{
    [Route("api/verify")]
    [ApiController]
    public class VerificationApiController : ControllerBase
    {
        private VerifyController _vc;
        private ILogger<VerificationApiController> _log;
        
        public VerificationApiController(ApplicationDbContext db, UserManager<ApplicationUser> um, ILogger<VerificationApiController> log)
        {
           _vc = new VerifyController(db,um);
           _log = log;
        }
        [HttpPost]
        public IActionResult Verify(VerifyTokenModel model)
        {
            if (!_vc.CheckToken(model.Token, model.UserId))
            {
                _log.LogInformation("Token is outdated or invalid");
                return Unauthorized("Token is outdated or invalid");
            }
            return Ok(model.Token);
        }
    }
}