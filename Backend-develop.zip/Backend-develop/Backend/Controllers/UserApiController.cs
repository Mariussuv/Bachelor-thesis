﻿using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Backend.BusinessLogic;
using Backend.Data;
using Microsoft.AspNetCore.Mvc;
using Backend.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;

 namespace Backend.Controllers
{
    [Route("api/user")]
    [ApiController]
    public class UserApiController : ControllerBase
    {
        private UserLogic logic;
        private readonly ApplicationDbContext _db;
        private ILogger<UserApiController> _log;
        private VerifyController _vc;

        
        public UserApiController(ApplicationDbContext db, ILogger<UserApiController> log, 
            UserManager<ApplicationUser> um, IWebHostEnvironment webHostEnvironment)
        {
            _db = db;
            logic = new UserLogic(db, webHostEnvironment);
            _log = log;
            _vc = new VerifyController(db,um);
        }

        [HttpGet]
        public IActionResult Get()
        {
            var e = _db.ApplicationUsers.ToList<ApplicationUser>();
            return Ok(e);
        }

        [HttpGet("{id}")]
        public IActionResult Get(string id)
        {
            var user = _db.ApplicationUsers.Find(id);

            if (user == null)
            {
                _log.LogInformation("No user with given id");
                return NotFound();
            }
            
            return Ok(user);
        }
        
        /**
         * Uploads an image to server an links it to a user.
         * Returns user
         */
        [HttpPost("{userId}/image")]
        public async Task<IActionResult> PostEventImage(string userId, IFormFile image)
        {
            if (image == null)
            {
                _log.LogInformation("No image received for user with id: " + userId);
                return Content("Error: No image received.");
            }
            
            var user = _db.ApplicationUsers.Find(userId);
            
            if (user == null)
            {
                _log.LogInformation("Could not find the user with userId: " + userId);
                return NotFound();
            }

            var userWithImage = await logic.AddUserImage(user, image);

            return Ok(userWithImage);
        }
        
        // Edit personal information
        [HttpPut]
        public IActionResult Edit(UserModel model)
        {
            if (!_vc.CheckToken(model.Token, model.UserId))
            {
                _log.LogInformation("Authorization failed: Get user");
                return Unauthorized();
            }

            if (!logic.EditUser(model))
            {
                _log.LogInformation("Could not edit user's first-, last name or phone number");
                return BadRequest();
            }     
            return Ok();
        }
    }
}