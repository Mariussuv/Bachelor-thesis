﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Backend.BusinessLogic;
using Backend.Data;
using Backend.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Backend.Controllers
{
    [Route("api/Group")]
    [ApiController]
    public class GroupApiController : ControllerBase
    {
        private readonly VerifyController _vc;
        private readonly GroupLogic _gl;
        private readonly ILogger<GroupApiController> _log;
        private ApplicationDbContext _db;

        public GroupApiController(ApplicationDbContext db,UserManager<ApplicationUser> um, 
            ILogger<GroupApiController> log, IWebHostEnvironment webHostEnvironment)
        {
            _vc = new VerifyController(db,um);
            _gl = new GroupLogic(db, webHostEnvironment);
            _log = log;
            _db = db;
        }
        
        //get all groups
        [HttpPost]
        [Route("groups")]
        public IActionResult Index(VerifyTokenModel model)
        {
            //Method for fetching all groups for a user
            if (!_vc.CheckToken(model.Token, model.UserId))
            {
                _log.LogInformation("Authorization failed: All groups");
                return Unauthorized("Token is not valid!");
            }
            return Ok(_gl.GetFullList(model.UserId));
        }

        //get one group
        [HttpPost]
        [Route("id/{id}")]
        public IActionResult GetGroup(int id,[FromBody]VerifyTokenModel model)
        {
            if (!_vc.CheckToken(model.Token, model.UserId))
            {
                _log.LogInformation("Authorization failed: Get one group ");
                return Unauthorized();
            }
            var group = _gl.GetGroup(id, model.UserId);

            if (group == null) return NotFound("Could not find group you asked for");
                
            //find members of this group
            var members = _gl.GetUsers(id);
                
            var collection = new Tuple<ApplicationGroup,List<ApplicationUser>>(group,members);
            return Ok(collection);
        }

        [HttpPost]
        public IActionResult CreateGroup(GroupModel model)
        {
            if (!_vc.CheckToken(model.token, model.userId))
            {
                _log.LogInformation("Authorization failed: Create group");
                return Unauthorized();
            }
            var group = _gl.CreateGroup(model);
            if (group == null)
            {
                _log.LogInformation("Something went wrong while creating group");
                return BadRequest();
            }

            var members = _gl.GetUsers(group.Id);
            var groupWithMembers = new GroupWithMembers(group,members);
                
            return Ok(groupWithMembers);
        }
        
        /**
         * Uploads an image to server an links it to a group.
         * Returns group (id, name, description, imageUri)
         */
        [HttpPost("{groupId}/image/userId/{userId}")]
        public async Task<IActionResult> PostGroupImage(int groupId, string userId, IFormFile image)
        {
            if (image == null)
            {
                _log.LogInformation("No image received for group with id: " + groupId);
                return Content("Error: No image received.");
            }
            
            var group = _gl.GetGroup(groupId, userId);

            if (group == null)
            {
                _log.LogInformation("Could not find the group with groupId: " + groupId);
                return NotFound();
            }
            var groupWithImage = await _gl.AddGroupImage(group, image);
            return Ok(groupWithImage);
        }

        [HttpPatch("{id}")]
        public IActionResult UpdateGroup(int id, [FromBody] GroupModel model)
        {
            if (!_vc.CheckToken(model.token, model.userId))
            {
                _log.LogInformation("Authorization failed: Add user to group");
                return Unauthorized("Invalid token");
            }
            _gl.UpdateGroup(id,model);
            var group = _gl.GetGroup(id, model.userId);
            var members = _gl.GetUsers(id);

            var groupWithMembers = new GroupWithMembers(group, members);
            return Ok(groupWithMembers);
        }

        [HttpDelete]
        [Route("{groupId}")]
        public IActionResult DeleteGroup(int groupId, [FromBody] VerifyTokenModel model)
        {
            if (!_vc.CheckToken(model.Token, model.UserId)) return Unauthorized();

            if (!_gl.DeleteGroup(groupId, model.UserId)) return BadRequest();

            return Ok();
        }
        
    }
}