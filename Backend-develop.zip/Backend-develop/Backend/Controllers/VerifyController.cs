﻿using System.Linq;
using System.Threading.Tasks;
using Backend.Data;
using Backend.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;

namespace Backend.Controllers
{
    
    /*
     * class for controlling verification around login and tokens
     */
    public class VerifyController 
    {
        private ApplicationDbContext _db;
        private UserManager<ApplicationUser> _um;

        public VerifyController(ApplicationDbContext db, UserManager<ApplicationUser> um)
        {
            _db = db;
            _um = um;
        }

        public ApplicationUser Register(UserModelView user)
        {
            var emailCheck = _db.ApplicationUsers.FirstOrDefault(e => e.Email == user.Email);
            if (emailCheck != null)
            {
                return null;
            }
            
            var registeredUser = new ApplicationUser(user.PhoneNumber, user.FirstName, user.LastName, user.Email);
            _db.ApplicationUsers.Add(registeredUser);
            _um.CreateAsync(registeredUser, user.Password).Wait();
            _db.SaveChanges();

            return registeredUser;
        }

        public bool CheckToken(string token, string userId)
        {
            var Token = _db.VerificationTokens.Where(t=>t.Token == token);
            foreach (var t in Token)
            {
                if (t.UserId == userId && t.ValidTo.CompareTo(System.DateTime.Now) > 0) return true;
            }
            return false;
        }

        public string GenerateToken(string userId)
        {
            var token = new VerificationToken(userId);
            _db.VerificationTokens.Add(token);
            _db.SaveChanges();

            return token.Token;
        }
    }
}