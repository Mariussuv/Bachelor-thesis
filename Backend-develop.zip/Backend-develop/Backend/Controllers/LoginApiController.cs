﻿using System;
using System.Reflection;
using System.Threading.Tasks;
using Backend.Data;
using Backend.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Backend.Controllers
{

    [Route("api/login")]
    [ApiController]
    public class LoginApiController : ControllerBase
    {
        private UserManager<ApplicationUser> _um;
        private VerifyController _vc;
        private ILogger<LoginApiController> _log;
        
        public LoginApiController(ApplicationDbContext db, UserManager<ApplicationUser> um, ILogger<LoginApiController> log)
        {
            _um = um;
            _vc = new VerifyController(db,um);
            _log = log;
        }

        [HttpGet]
        public IActionResult Get()
        {
            return Ok("No Content");
        }
        
        [HttpPost]
        public async Task<IActionResult> Login(LoginModel model)
        {
            var username = model.Username;
            var user = await _um.FindByNameAsync(username);
            var passwordOk = await _um.CheckPasswordAsync(user, model.Password);
            if (!passwordOk)
            {
                _log.LogInformation("Password is wrong");
                return BadRequest("Wrong username or password");
            }
            
            //login was successful, now we generate a verification token
            _log.LogInformation("Login was successful!");
            var token = _vc.GenerateToken(user.Id);

            //var collection = new Tuple<string, string>(user.Id, token);
            var collection = new VerifyTokenModel();
            collection.Token = token;
            collection.UserId = user.Id;
            
            return Ok(collection);
            
        }
    }
}