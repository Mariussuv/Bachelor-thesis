﻿using System;
using Backend.BusinessLogic;
using Backend.Data;
using Backend.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Backend.Controllers
{
    [Route("api/register")]
    [ApiController]
    public class RegisterApiController : ControllerBase
    {

        private ApplicationDbContext _db;
        private UserManager<ApplicationUser> _um;
        private VerifyController _vc;
        private RegisterLogic _rl;
        private ILogger<RegisterApiController> _log;

        public RegisterApiController(ApplicationDbContext db, UserManager<ApplicationUser> um, ILogger<RegisterApiController> log)
        {
            _db = db;
            _um = um;
            _vc = new VerifyController(db,um);
            _rl = new RegisterLogic(db, log);
            _log = log;
        }
        
        [HttpPost]
        public IActionResult RegisterUser(UserModelView user)
        {
            var response = _vc.Register(user);
            if (response == null)
            {
                _log.LogInformation("Failed to register: Email is already registered");
                return Conflict("Email is already registered");
            }
            
            return Ok(response);
        }

        [HttpPost]
        [Route("facebook/facebooktoken/{facebookToken}")]
        public IActionResult RegisterFacebook(string facebookToken)
        {
            var user = _rl.RegisterFacebook(facebookToken);
            if (user == null)
            {
                _log.LogInformation("Facebook registering failed. Token " + facebookToken);
                return BadRequest("Woops, an error occured");
            }

            var token = _vc.GenerateToken(user.Id);
            
            var collection = new VerifyTokenModel();
            collection.Token = token;
            collection.UserId = user.Id;

            return Ok(collection);
        }
    }
}