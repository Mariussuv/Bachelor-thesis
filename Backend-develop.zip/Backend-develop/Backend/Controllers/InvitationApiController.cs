﻿using System;
using Backend.BusinessLogic;
using Backend.Data;
using Backend.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Backend.Controllers
{
    [Route("api/invite")]
    [ApiController]
    public class InvitationApiController : ControllerBase
    {
        private InviteLogic _il;
        private VerifyController _vc;
        private ILogger<InvitationApiController> _log;
        
        public InvitationApiController(ApplicationDbContext db, UserManager<ApplicationUser> um, ILogger<InvitationApiController> log)
        {
            _il = new InviteLogic(db);
            _vc = new VerifyController(db,um);
            _log = log;
        }
        
        
        //get list of invites
        [HttpPost]
        [Route("invites")]
        public IActionResult GetInvitations(VerifyTokenModel model)
        {
            if (!_vc.CheckToken(model.Token, model.UserId))
            {
                _log.LogInformation("Authorization failed: get invites");
                return Unauthorized();
            }
            return Ok(_il.GetInvitations(model.UserId));
        }

        //use this to get invite if id is known
        [HttpPost]
        [Route("id/{id}")]
        public IActionResult GetInvite(int id,[FromBody] VerifyTokenModel model)
        {
            if (!_vc.CheckToken(model.Token, model.UserId))
            {
                _log.LogInformation("Authorization failed: Get invitation");
                return Unauthorized();
            }
            var invite = _il.GetInvitation(id);

            if (invite == null)
            {
                _log.LogInformation("Could not find invitation");
                return NoContent();
            }
            
            return Ok(invite);
        }

        //use this to search for an invite if event and user is known
        [HttpPost]
        [Route("find")]
        public IActionResult Find(InviteModel model)
        {
            if (!_vc.CheckToken(model.Token, model.UserId)) return Unauthorized();

            try
            {
                var invite = _il.FindInvitation(model.InvitedUserId, model.EventId);
                return Ok(invite);
            }
            catch (NullReferenceException e)
            {
                _log.LogInformation("Failed to find invitation: " + e.Message);
            }

            _log.LogInformation("Could not find invitation");
            return NoContent();
        }

        [HttpPost]
        public IActionResult CreateInvite(InviteModel model)
        {
            if (!_vc.CheckToken(model.Token, model.UserId))
            {
                _log.LogInformation("Authorization failed: Create invitation");
                return Unauthorized();
            }
            
            var invitation = _il.CreateInvitation(model.EventId,model.InvitedUserId);

            if (invitation == null)
            {
                _log.LogInformation("No invitation was created");
                return NoContent();
            }
            
            return Ok(invitation);
        }

        [HttpPost]
        [Route("group")]
        public IActionResult InviteGroup(InviteGroupModel model)
        {
            if (!_vc.CheckToken(model.Token, model.UserId))
            {
                _log.LogInformation("Authorization failed: inviting group");
                return Unauthorized();
            }
            var inviteList = _il.InviteGroup(model.EventId, model.InvitedUserIds);

            return Ok(inviteList);
        }

        //Update Invite
        [HttpPut]
        [Route("id/{id}/status/{status}")]
        public IActionResult UpdateInvite(int id,int status, [FromBody] VerifyTokenModel model)
        {
            if (!_vc.CheckToken(model.Token, model.UserId)) return Unauthorized();
            try
            {
                var invitation = _il.UpdateInvitation(id, status, model.UserId);
                return Ok(invitation);
            }
            catch (NullReferenceException e)
            {
                _log.LogInformation("Invite update failed: "+e);
            }

            return NoContent();
        }

        [HttpPost]
        [Route("event/{eventId}")]
        public IActionResult getUsers(int eventId, [FromBody] VerifyTokenModel model)
        {
            if(!_vc.CheckToken(model.Token, model.UserId))
            {
                _log.LogInformation("Authorization failed");
                return Unauthorized();
            }
            var i = _il.GetAllInvitesToEvent(eventId);
            return Ok(i);
        }
    }
}