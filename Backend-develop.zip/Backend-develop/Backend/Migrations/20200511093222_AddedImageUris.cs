﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Backend.Migrations
{
    public partial class AddedImageUris : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ImageUri",
                table: "Events",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ImageUri",
                table: "AspNetUsers",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ImageUri",
                table: "ApplicationGroups",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ImageUri",
                table: "Events");

            migrationBuilder.DropColumn(
                name: "ImageUri",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "ImageUri",
                table: "ApplicationGroups");
        }
    }
}
