﻿using System;
using System.Collections.Generic;
using System.Text;
using Backend.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Backend.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        
        public DbSet<Event> Events { get; set; }

        public DbSet<ApplicationUser> ApplicationUsers { get; set; }
        
        public DbSet<VerificationToken> VerificationTokens { get; set; }
        
        public DbSet<ApplicationGroup> ApplicationGroups { get; set; }
        
        public DbSet<GroupUserRelationship> GroupUserRelationships { get; set; }
        
        public DbSet<EventInvitation> EventInvitations { get; set; }
    }
}
