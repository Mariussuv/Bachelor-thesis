﻿﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

using Backend.Models;
 using Microsoft.AspNetCore.Hosting;
 using Microsoft.AspNetCore.Identity;

 namespace Backend.Data
{
    public static class ApplicationDbInitializer
    {
        public static void Initialize(ApplicationDbContext context, UserManager<ApplicationUser> _um, bool development)
        {
            // Run migrations if we're not in development mode
            if (!development)
            {
                context.Database.Migrate();
                return;
            }
            
            //Clears Database
            context.Database.EnsureDeleted();

            //Creating Database
            context.Database.EnsureCreated();

            context.ApplicationUsers.AddRange(new List<ApplicationUser>
            {
                new ApplicationUser("1881","Lisa","Lisadottir","test@test.test"),
                new ApplicationUser("113","Jon","Jonson","test1@test.test"),
                new ApplicationUser("99808879","Alf","Skøyen","test2@test.no"),
                new ApplicationUser("99808880","Lars","Hakke","test3@test.no"),
                new ApplicationUser("99808881","Jonas","Klype","test4@test.no"),
                new ApplicationUser("99808882","Hans","Majestet","test5@test.no"),
                new ApplicationUser("99808883","Ali","Kaffe","test6@test.no"),
                new ApplicationUser("99808884","Boris","Johnson","test7@test.no"),
                new ApplicationUser("99808878","Donald","Trump","test8@test.no"),
                new ApplicationUser("99808877","Stig","Trappesen","test9@test.no"),
                new ApplicationUser("99808876","Unni","Ken","test10@test.no"),
                new ApplicationUser("99808875","Tord","Envær","test11@test.no"),
                new ApplicationUser("99808874","Aslak","Pratesen","test12@test.no"),
                new ApplicationUser("99808873","Elin","Blåklokke","test13@test.no"),
                new ApplicationUser("99808872","Svein","Monsen","test14@test.no"),
                new ApplicationUser("99808871","Knut","Knutsen","test15@test.no"),
                new ApplicationUser("99808870","Kari","Traa","test16@test.no"),
            });
            
            var registeredUser = new ApplicationUser("99809980", "Ole", 
                "Testmann", "test@test.no");
            context.ApplicationUsers.Add(registeredUser);
            _um.CreateAsync(registeredUser, "Password1#").Wait();
            context.SaveChanges();
            
            //Save Database
            context.SaveChanges();

            var users = context.ApplicationUsers.ToList();
            var ownerId = users[2].Id;
            
            //test data
            context.Events.AddRange(new List<Event>
            {
                new Event("VolleyBall With the Boiz","Meet at the beach 14.00", "Groos", 
                    new DateTime(2020, 5, 1, 20, 30, 52), ownerId),
                new Event("Waffles and Saft",
                    "Hot and delicious waffles and ice cold bringbærsaft at my place", 
                    "Storgaten 35", new DateTime(2020, 6, 30, 20, 30, 52), 
                    ownerId),
                new Event("Coffee and baking","Baking at my place. Bring coffee","CasaMarius",
                    new DateTime(2020, 5, 1, 20, 30, 52), ownerId),
                new Event("Birthday","Celebrating my birthday in Jumbo Lekeland","Jumbo Lekeland",
                    new DateTime(2020, 5, 1, 20, 30, 52), ownerId),
                new Event("Shopping","Shopping at the biggest mall in Grimstad.","Odden",
                    new DateTime(2020, 5, 1, 20, 30, 52), ownerId),
                new Event("Bowling Night","Hyper-Bowling with all my friends","Arendal",
                    new DateTime(2020, 5, 1, 20, 30, 52), ownerId),
                new Event("School","Work together at school?","UiA",
                    new DateTime(2020, 5, 1, 20, 30, 52), ownerId),
                new Event("Soccer","Soccer at Landvik with old Imås-players","Landvik",
                    new DateTime(2020, 5, 1, 20, 30, 52), ownerId)
            }); 
            
            context.SaveChanges();

            
            var events = context.Events.ToList();

            foreach (var e in events)
            {
                var invite = new EventInvitation(users[2], e);
                context.EventInvitations.Add(invite);
                context.SaveChanges();
            }
        }
    }
}
