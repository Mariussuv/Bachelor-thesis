﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Backend.Data;
using Backend.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace Backend.BusinessLogic
{
    public class GroupLogic
    {
        /*
         * Business logic for creating, changing or removing goups
         */
        private readonly ApplicationDbContext _db;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public GroupLogic(ApplicationDbContext db, IWebHostEnvironment webHostEnvironment)
        {
            _db = db;
            _webHostEnvironment = webHostEnvironment;

        }

        public ApplicationGroup CreateGroup(GroupModel model)
        {
            ApplicationGroup group = new ApplicationGroup(model.Name,model.Description);

            _db.ApplicationGroups.Add(group);
            _db.SaveChanges();
            
            //add users to relation in db
            foreach (var m in model.MemberIds)
            {
                var relation = new GroupUserRelationship();
                
                relation.GroupId = group.Id;
                relation.ApplicationGroup = group;

                relation.UserId = m;
                try {relation.ApplicationUser = _db.ApplicationUsers.Find(model.userId);}
                catch(NullReferenceException e){Console.Write(e.Message);}

                _db.GroupUserRelationships.Add(relation);
                _db.SaveChanges();
            }
            
            _db.SaveChanges();

            return group;
        }

        public ApplicationGroup GetGroup(int id, string userId)
        {
            var members = _db.GroupUserRelationships.Where(r => r.GroupId == id).ToList();

            var group = _db.ApplicationGroups.Find(id);

            if (group != null)
            {
                //check if user is a part of the group
                foreach (var m in members)
                {
                    if (m.UserId == userId) return group;
                }

            }
            //return null if user is not part of group asked for
            return null;
        }

        public List<ApplicationGroup> FindGroups(string userId)
        {
           //code to get all groups where user is member
           List<ApplicationGroup> groups = new List<ApplicationGroup>();
           var relations = _db.GroupUserRelationships.Where(r => r.UserId == userId).ToList();

           foreach (var r in relations)
           {
               groups.Add(_db.ApplicationGroups.Find(r.GroupId));
           }
           
           return groups;
        }

        public List<ApplicationUser> GetUsers(int groupId)
        {
            List<ApplicationUser> members = new List<ApplicationUser>();
            var relations = _db.GroupUserRelationships.Where(x => x.GroupId == groupId).ToList();
            foreach (var r in relations)
            {
                try
                {
                    var user = _db.ApplicationUsers.Find(r.UserId);
                    members.Add(user);
                }
                catch(NullReferenceException e){ Console.Write(e.Message);}
            } 
            return members;
        }

        /**
         * Adds image to server and imageUri to group.
         * Returns group (id, groupName, description, imageUri)
         */
        public async Task<ApplicationGroup> AddGroupImage(ApplicationGroup group, IFormFile image)
        {
            string webRootPath = _webHostEnvironment.WebRootPath;
            string imgPath = webRootPath + "/img/group/" + image.FileName;
            
            group.ImageUri = "img/group/" + image.FileName;
            _db.ApplicationGroups.Update(group);
            _db.SaveChanges();
            
            using (var stream = new FileStream(imgPath, FileMode.Create))
            {
                await image.CopyToAsync(stream);
            }

            return group;
        }
        
        public List<GroupWithMembers> GetFullList(string userId)
        {
            var groupsWithMembers = new List<GroupWithMembers>();
            var groups = FindGroups(userId);

            foreach (var g in groups)
            {
                var users = GetUsers(g.Id);
                var temp = new GroupWithMembers(g,users);
                
                groupsWithMembers.Add(temp);
            }

            return groupsWithMembers;
        }
        public void UpdateGroup(int id, GroupModel model)
        {
            var group = _db.ApplicationGroups.Find(id);
            var members = GetUsers(id);
            
            //check if user is part of group
            foreach (var m in members)
            {
                if (m.Id == model.userId)
                {
                    group.GroupName = model.Name;
                    group.Description = model.Description;
                    group.ImageUri = model.ImageUri;
                    UpdateMembers(id,model);

                    _db.SaveChanges();
                }
            }
        }
        
        public void UpdateMembers(int id, GroupModel model)
        {
            var relations = _db.GroupUserRelationships
                .Where(r => r.GroupId == id)
                .ToList();

            //taking ids from relations into one list containing only strings for simpler handling later
            var memberIds = new List<String>();
            foreach (var r in relations)
            {
                memberIds.Add(r.UserId); 
            }

            //add new members
            foreach (var m in model.MemberIds)
            {
                if (!memberIds.Contains(m))
                {
                    var relation = new GroupUserRelationship();
                    relation.UserId = m;
                    relation.ApplicationUser = _db.ApplicationUsers.Find(m);

                    relation.GroupId = id;
                    relation.ApplicationGroup = _db.ApplicationGroups.Find(id);

                    _db.GroupUserRelationships.Add(relation);
                    _db.SaveChanges();
                }
            }
            //remove users
            foreach (var r in relations)
            {
                if (!model.MemberIds.Contains(r.UserId))
                {
                    _db.GroupUserRelationships.Remove(r);
                    _db.SaveChanges();
                }
            }
        }

        public bool DeleteGroup(int groupId, string userId)
        {
            var group = _db.ApplicationGroups.Find(groupId);
            if (group == null) return false;
            
            //find if there is a relation between group and user
            var groupMember =
                _db.GroupUserRelationships.FirstOrDefault(r =>
                    r.GroupId == groupId &&
                    r.UserId == userId);

            //if user is not a part of the group the group cannot be removed
            if(groupMember == null) return false;

            //finding all relations between users and group, and remove them before group is deleted
            var relations = _db.GroupUserRelationships.Where(r => r.GroupId == groupId);
            _db.GroupUserRelationships.RemoveRange(relations);

            _db.ApplicationGroups.Remove(group);
            _db.SaveChanges();
            
            return true;

        }
    }
}