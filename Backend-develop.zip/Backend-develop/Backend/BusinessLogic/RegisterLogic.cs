using System;
using System.IO;
using System.Linq;
using System.Net;
using Backend.Controllers;
using Backend.Data;
using Backend.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;

namespace Backend.BusinessLogic
{
    public class RegisterLogic
    {
        readonly ApplicationDbContext _db;
        private ILogger<RegisterApiController> _log;


        public RegisterLogic(ApplicationDbContext db, ILogger<RegisterApiController> log)
        {
            _db = db;
            _log = log;
        }

        public ApplicationUser RegisterFacebook(string token)
        {
            var newUser = CheckFacebook(token);
            if (newUser == null) return null;
            
            //check if user is registered
            var registeredUser = _db.ApplicationUsers.FirstOrDefault(u => u.ExternalId == newUser.ExternalId);
            if (registeredUser != null){
                _log.LogInformation("User " + registeredUser.Email + " is already registered");
                return registeredUser; //return already registered user
            }
                
            //user is not registered already
            _db.ApplicationUsers.Add(newUser);
            _db.SaveChanges();

            return newUser;
        }

        private ApplicationUser CheckFacebook(string token)
        {
            var user = new ApplicationUser();
            
            //create request
                WebRequest request =
                    WebRequest.Create("https://graph.facebook.com/me?fields=email,first_name,last_name&access_token=" +
                                      token);

                //get respons
                HttpWebResponse response = (HttpWebResponse) request.GetResponse();

                // Get the stream containing content returned by the server.
                // The using block ensures the stream is automatically closed.
                using (Stream dataStream = response.GetResponseStream())
                {
                    if (dataStream != null)
                    {
                        // Open the stream using a StreamReader for easy access.
                        StreamReader reader = new StreamReader(dataStream);
                        // Read the content.
                        string responseFromServer = reader.ReadToEnd();

                        JObject json = JObject.Parse(responseFromServer);
                        var firstName = json.Property("first_name").Value.ToString();
                        var lastName = json.Property("last_name").Value.ToString();
                        var email = json.Property("email").Value.ToString();
                        var id = json.Property("id").Value.ToString();

                        user.FirstName = firstName;
                        user.LastName = lastName;
                        user.Email = email;
                        user.ExternalLogin = "Facebook";
                        user.ExternalLoginToken = token;
                        user.ExternalId = id;
                    }
                }

                if (response.StatusDescription != "OK") return null;
                response.Close();
                return user;
        }
    }
}