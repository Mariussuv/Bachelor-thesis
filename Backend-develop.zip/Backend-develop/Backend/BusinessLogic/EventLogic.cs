﻿﻿using Backend.Data;
using Backend.Models;
using System;
using System.Collections.Generic;
 using System.IO;
 using System.Linq;
using System.Threading.Tasks;
 using Microsoft.AspNetCore.Hosting;
 using Microsoft.AspNetCore.Http;

 //This class will handle logic around events,
//such as which events to return and how to use them.
//This will make the API-controller cleaner, and we reduce coupling.
namespace Backend.BusinessLogic
{
    public class EventLogic
    {
        private readonly ApplicationDbContext _db;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public EventLogic(ApplicationDbContext db, IWebHostEnvironment webHostEnvironment)
        {
            _db = db;
            _webHostEnvironment = webHostEnvironment;
        }

        public List<Event> GetEvents(int userId)
        {
            List<Event> e = _db.Events.Where(p => p.OwnerId.Equals(userId)).ToList();

            return e;
        }
        public Event GetEvent(int Id)
        {
            return _db.Events.Find(Id);
        }
        
        /**
         * Adds image to server and imageUri to event.
         * Returns event
         */
        public async Task<Event> AddEventImage(Event e, IFormFile image)
        {
            string webRootPath = _webHostEnvironment.WebRootPath;
            string imgPath = webRootPath + "/img/event/" + image.FileName;
            
            e.ImageUri = "img/event/" + image.FileName;
            _db.Events.Update(e);
            _db.SaveChanges();
            
            using (var stream = new FileStream(imgPath, FileMode.Create))
            {
                await image.CopyToAsync(stream);
            }

            return e;
        }

        public Event EditEvent(EventModel model)
        {
            var e = _db.Events.Find(model.Event.Id);//ensure user is owner
            if (e.OwnerId != model.UserId) return null;

            e.Title = model.Event.Title;
            e.Description = model.Event.Description;
            e.Location = model.Event.Location;
            e.DateTime = model.Event.DateTime;
            e.ImageUri = model.Event.ImageUri;
            
            _db.Events.Update(e);
            _db.SaveChanges();
        
            return model.Event;
        }

        public bool DeleteEvent(int eventId, string userId)
        {
            var e = _db.Events.Find(eventId);
            if (e.OwnerId != userId) return false;

            _db.Events.Remove(e);
            _db.SaveChanges();
            return true;
        }
    }
}
