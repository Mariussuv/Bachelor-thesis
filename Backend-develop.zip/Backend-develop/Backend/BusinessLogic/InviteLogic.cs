﻿using System;
using System.Collections.Generic;
using System.Linq;
using Backend.Data;
using Backend.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query;
using Microsoft.Extensions.Logging;

namespace Backend.BusinessLogic
{
    public class InviteLogic
    {
        private ApplicationDbContext _db;

        public InviteLogic(ApplicationDbContext db)
        {
            _db = db;
        }

        public EventInvitation CreateInvitation(int eventId, string userId)
        {
            try
            {
                var e = _db.Events.Find(eventId);
                var u = _db.ApplicationUsers.Find(userId);
                
                var invitation = new EventInvitation(u,e);

                _db.EventInvitations.Add(invitation);
                _db.SaveChanges();

                return invitation;
            }
            catch (NullReferenceException error)
            {
                Console.Write("Could not find users and/or events");
                Console.Write(error.Message);
            }

            return null;
        }
        
        //get one invitation
        public EventInvitation GetInvitation(int id)
        {
            try
            {
                var invite = _db.EventInvitations.Find(id);
                return invite;
            }
            catch (NullReferenceException e)
            {
                Console.Write("Could not find invitation");
                Console.Write(e.Message);
            }

            return null;
        }
        
        public EventInvitation FindInvitation(string userId, int eventId)
        {
            try
            {
                var invitation = _db.EventInvitations.FirstOrDefault(i => i.UserId == userId && i.EventId == eventId);
                return invitation;
            }
            catch (NullReferenceException e)
            {
                Console.Write("Could not find invitation");
                Console.Write(e.Message);
            }

            return null;

        }
        //get invitations
        public List<EventInvitation> GetInvitations(string userId)
        {
            var invitations = _db.EventInvitations.Where(i => i.UserId == userId).Include(i => i.Event).ToList();
            return invitations;
        }

        public EventInvitation UpdateInvitation(int inviteId, int status, string userId)
        {
            try
            {
                var invite = GetInvitation(inviteId);

                if (invite.UserId != userId) return null;

                
                if (status == 0) invite.Status = EventInvitation.Statuses.NotAnswered;
                else if (status == 1) invite.Status = EventInvitation.Statuses.Attending;
                else if (status == 2) invite.Status = EventInvitation.Statuses.NotAttending;

                _db.SaveChanges();

                return invite;
            }
            catch (NullReferenceException e)
            {
                Console.Write(e.Message);
            }

            return null;
        }

        public List<EventInvitation> InviteGroup(int eventId, List<string> users)
        {
            var list = new List<EventInvitation>();
            foreach (var u in users)
            {
                var invite = CreateInvitation(eventId, u);
                list.Add(invite);
            }

            return list;
        }

        public List<Event> GetEventsByInvite(string userId)
        {
            var invites = GetInvitations(userId);
            var events = new List<Event>();
            foreach (var invite in invites)
            {
                events.Add(_db.Events.Find(invite.EventId));
            }

            return events;
        }

        public IIncludableQueryable<EventInvitation,ApplicationUser> GetAllInvitesToEvent(int eventId)
        {
            var invites = _db.EventInvitations.Where(i => i.EventId == eventId).Include(i => i.User);
            return invites;
        }
    }
}