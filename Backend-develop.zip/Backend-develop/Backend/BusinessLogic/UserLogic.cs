using System.IO;
using System.Threading.Tasks;
using Backend.Data;
using Backend.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;

namespace Backend.BusinessLogic
{
    public class UserLogic
    {
        private ApplicationDbContext _db;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public UserLogic(ApplicationDbContext db, IWebHostEnvironment webHostEnvironment)
        {
            _db = db;
            _webHostEnvironment = webHostEnvironment;
        }
        
        /**
         * Adds image to server and imageUri to user.
         * Returns user
         */
        public async Task<ApplicationUser> AddUserImage(ApplicationUser user, IFormFile image)
        {
            string webRootPath = _webHostEnvironment.WebRootPath;
            string imgPath = webRootPath + "/img/user/" + image.FileName;
            user.ImageUri = "img/user/" + image.FileName;
            
            _db.ApplicationUsers.Update(user);
            _db.SaveChanges();
            
            using (var stream = new FileStream(imgPath, FileMode.Create))
            {
                await image.CopyToAsync(stream);
            }

            return user;
        }

        public bool EditUser(UserModel model)
        {
            var oldUser = _db.ApplicationUsers.Find(model.UserId);
            if (oldUser == null)
                return false;

            oldUser.FirstName = model.User.FirstName;
            oldUser.LastName = model.User.LastName;
            oldUser.PhoneNumber = model.User.PhoneNumber;
            oldUser.ImageUri = model.User.ImageUri;

            _db.ApplicationUsers.Update(oldUser);
            _db.SaveChanges();

            return true;
        }
    }
}