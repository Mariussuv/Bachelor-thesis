// Norwegian language

const nb_NO = {
    attending: 'Deltagere',
    confirmPassword: 'Bekreft passord',
    create: 'Opprett',
    description: 'Beskrivelse',
    details: 'Detaljer',
    done: 'Ferdig',
    email: 'Epost',
    firstName: 'Fornavn',
    friends: 'Venner',
    groups: 'Grupper',
    hello: 'Hei',
    invited: 'Inviterte',
    lastName: 'Etternavn',
    location: 'Sted',
    login: 'Logg inn',
    loginWithFacebook: 'Logg inn med Facebook',
    loginWithGoogle: 'Logg inn med Google',
    next: 'Neste',
    no: 'Nei',
    noAccountQuestion: 'Ingen konto?',
    password: 'Passord',
    phoneNumber: 'Telefonnummer',
    roqet: 'Roqet',
    save: 'Lagre',
    signUp: 'Registrer deg',
    title: 'Tittel',
    welcome: 'Velkommen',
    yes: 'Ja',

    // Nested messages (order alphabetically):
    about: {
        aboutApp: 'Om Appen',
        aboutUs: 'Om Oss'
    },
    account: {
        edit: 'Endre personopplysninger',
        placeholder: {
            editFirstName: 'Endre fornavn',
            editLastName: 'Endre etternavn',
            editPhoneNumber: 'Endre telefonnummer'
        }
    },
    api: {
        addEventImageFailed: 'Kunne ikke laste opp bilde til eventet: ',
        addGroupImageFailed: 'Kunne ikke laste opp bilde til gruppen: ',
        addUserImageFailed: 'Kunne ikke laste opp profilbilde: ',
        answerInviteFailed: 'Kunne ikke svare på invitasjonen: ',
        createEventFailed: 'Vi kunne dessverre ikke opprette dette eventet: ',
        createGroupFailed: 'Vi kunne dessverre ikke opprette denne gruppen: ',
        deleteEventFailed: 'Vi kunne dessverre ikke slette dette eventet: ',
        editAccountFailed: 'Vi kunne dessverre ikke endre brukerinformasjonen din: ',
        editEventFailed: 'Vi kunne dessverre ikke endre dette eventet: ',
        editGroupFailed: 'Vi kunne dessverre ikke endre denne gruppen: ',
        fbLoginFailed: 'Det var ikke mulig å logge deg inn med Facebook: ',
        fbRegisterFailed: 'Det var ikke mulig å registrere deg med Facebook.',
        findInviteFailed: 'Kunne ikke finne invitasjon: ',
        getEventFailed: 'Vi kunne dessverre ikke hente eventet: ',
        getEventsFailed: 'Vi kunne dessverre ikke hente eventene dine: ',
        getGroupsFailed: 'Vi kunne dessverre ikke hente gruppene dine: ',
        getSpecificEventInvitationsFailed: 'Vi kunne dessverre ikke hente invitasjonene til dette eventet: ',
        getUserFailed: 'Vi kunne dessverre ikke hente brukerinformasjonen din: ',
        getUsersFailed: 'Vi kunne dessverre ikke hente vennelisten din: ',
        googleLoginFailed: 'Det var ikke mulig å logge deg inn med Google.',
        inviteUsersFailed: 'Det var ikke mulig å sende invitasjonene: ',
        logInFailed: 'Vi har problemer med våre servere. Prøv igjen om et øyeblikk: ',
        logInWrong: 'Brukernavnet og/eller passordet er feil. Vennligst prøv igjen.',
        registerUserFailed: 'Vi kunne dessverre ikke registrere brukeren: ',
        verifyTokenFailed: 'Vi kunne dessverre ikke verifisere din token: '
    },
    error: {
        cameraPermissions: 'Beklager, vi trenger tilgang til ditt kamera for å kunne fullføre denne handlingen!',
        cameraRollPermissions: 'Beklager, vi trenger tilgang til dine bilder for å kunne fullføre denne handlingen!',
        invalid: 'Ugyldig',
        invalidEmail: 'Oppgi en gyldig e-postadresse',
        invalidInput: 'Ugyldig input',
        invalidPassword: 'Oppgi et gyldig passord',
        invalidPhoneNumber: 'Oppgi et gyldig telefonnummer',
        passwordsMismatch: 'Passordene er ikke like',
        passwordRequirements: 'Passordet må være minst 10 tegn langt, inneholde store og små bokstaver,' +
            ' tall og spesialtegn',
        requiredField: 'Påkrevd felt'
    },
    event: {
        active: 'Aktive',
        all: 'Alle',
        alphabetical: 'Sorter etter tittel',
        date: 'Sorter etter dato',
        delete: 'Slett event',
        deleteMessage: 'Er du sikker på at du vil slette dette eventet?',
        edit: 'Rediger event',
        filter: 'Filtrer dine eventer',
        host: 'Eventer du har laget',
        hostedBy: 'Arrangert av ',
        noEvents: 'Opprett et event eller sveip ned fra toppen for å oppdatere',
        notAnswered: 'Venter på svar',
        old: 'Tidligere',
        placeholder: {
            description: 'Beskriv eventet ditt',
            location: 'Hvor foregår eventet ditt?',
            title: 'Navngi eventet ditt'
        },
    },
    futureImplementation: {
        facebook: 'Facebook autentisering er foreløpig kun tilgjengelig for Android.',
        google: 'Google autentisering er en kommende funksjon som vil gjøres tilgjengelig i en senere versjon.',
        notAvailable: 'Ikke tilgjengelig'
    },
    group: {
        addMembers: 'Legg til gruppemedlemmer',
        delete: 'Slett gruppe',
        deleteMessage: 'Er du sikker på at du vil slette denne gruppa?',
        create: 'Opprett ny gruppe',
        description: 'Gruppebeskrivelse',
        edit: 'Rediger gruppe',
        members: 'Gruppemedlemmer',
        name: 'Gruppenavn',
        noGroups: 'Trykk + for å opprette din første gruppe',

        error: {
            noMembers: 'En gruppe må bestå av minst to personer'
        },
        placeholder: {
            description: 'Beskriv denne gruppen (valgfritt)',
            name: 'F.eks. Familie, Kollegaer ...'
        }
    },
    invite: {
        inviteSelected: 'Inviter valgte personer',
        invite: 'Inviter',
        attendingQuestion: 'Skal du delta på dette eventet?'
    },
    navigation: {
        events: 'Eventer',
        groups: 'Grupper',
        newEvent: 'Nytt event',
        settings: 'Innstillinger',
    },
    register: {
        alreadyRegistered: 'Allerede registrert?',
        withFacebook: 'Registrer med Facebook',
        withGoogle: 'Registrer med Google',
    },
    settings: {
        account: 'Konto',
        privacy: 'Personverninnstillinger',
        logOut: 'Logg ut',
        general: 'Generelt',
        notifications: 'Notifikasjoner',
        preferences: 'Preferanser',
        availability: 'Tilgjengelighet',
        appearance: 'Utseende',
        about: 'Om',
        aboutApp: 'Om appen',
        aboutUs: 'Om oss'
    }
};

export default nb_NO;
