// English language

const en = {
    attending: 'Attending',
    confirmPassword: 'Confirm Password',
    create: 'Create',
    description: 'Description',
    details: 'Details',
    done: 'Done',
    email: 'Email',
    firstName: 'First Name',
    friends: 'Friends',
    groups: 'Groups',
    hello: 'Hello',
    invited: 'Invited',
    lastName: 'Last Name',
    location: 'Location',
    login: 'Log In',
    loginWithFacebook: 'Log in with Facebook',
    loginWithGoogle: 'Log in with Google',
    next: 'Next',
    no: 'No',
    noAccountQuestion: 'Don\'t have an account?',
    password: 'Password',
    phoneNumber: 'Phone Number',
    roqet: 'Roqet',
    save: 'Save',
    signUp: 'Sign Up',
    title: 'Title',
    welcome: 'Welcome',
    yes: 'Yes',

    // Nested messages (order alphabetically):
    about: {
        aboutApp: 'About the App',
        aboutUs: 'About Us'
    },
    account: {
        edit: 'Edit your personal information',
        placeholder: {
            editFirstName: 'Edit your first name',
            editLastName: 'Edit your last name',
            editPhoneNumber: 'Edit your phone number'
        }
    },
    api: {
        addEventImageFailed: 'Failed to upload image to event: ',
        addGroupImageFailed: 'Failed to upload image to group: ',
        addUserImageFailed: 'Failed to upload image to user: ',
        answerInviteFailed: 'Unable to answer the invite request: ',
        createEventFailed: 'Failed to create new event: ',
        createGroupFailed: 'Failed to create new group: ',
        deleteEventFailed: 'Failed to delete event: ',
        editAccountFailed: 'Failed to edit account information: ',
        editEventFailed: 'Failed to edit event: ',
        editGroupFailed: 'Failed to edit group: ',
        fbLoginFailed: 'Failed to login with Facebook: ',
        fbRegisterFailed: 'Failed to register with Facebook.',
        findInviteFailed: 'Failed to find invite: ',
        getEventFailed: 'Failed to load event: ',
        getEventsFailed: 'Failed to load your events: ',
        getGroupsFailed: 'Failed to load your groups: ',
        getSpecificEventInvitationsFailed: 'Failed to load invited people to this event: ',
        getUserFailed: 'We were unable to get your information: ',
        getUsersFailed: 'We were not able to get your friend list: ',
        googleLoginFailed: 'Unable to login with Google.',
        inviteUsersFailed: 'Unable to send invitations: ',
        logInFailed: 'We are experiencing some issues with our servers. Please try again in a moment: ',
        logInWrong: 'Your username and/or password is incorrect. Please try again.',
        registerUserFailed: 'Failed to register user: ',
        verifyTokenFailed: 'Failed to verify token: '
    },
    error: {
        cameraPermissions: 'Sorry, we need camera permissions to make this work!',
        cameraRollPermissions: 'Sorry, we need camera roll permissions to make this work!',
        invalid: 'Invalid',
        invalidEmail: 'Please enter a valid email address',
        invalidInput: 'Invalid input',
        invalidPassword: 'Please enter a valid password',
        invalidPhoneNumber: 'Please enter a valid phone number',
        passwordsMismatch: 'Passwords are not identical',
        passwordRequirements: 'The password must be at least 10 characters long, ' +
            'include uppercase and lowercase letters, numbers and special characters',
        requiredField: 'Required field'
    },
    event: {
        active: 'Active',
        all: 'All',
        alphabetical: 'Sort by title',
        date: 'Sort by date',
        delete: 'Delete Event',
        deleteMessage: 'Are you sure you want to delete this event?',
        edit: 'Edit Event',
        filter: 'Filter your events',
        host: 'Events you created',
        hostedBy: 'Hosted by ',
        noEvents: 'Create your first event, or swipe down to refresh',
        notAnswered: 'Waiting for your response',
        old: 'Include Old',
        placeholder: {
            description: 'Describe your event',
            location: 'Where does your event take place?',
            title: 'Name your event',
        },
    },
    futureImplementation: {
        facebook: 'Facebook authentication is currently only available for Android.',
        google: 'Google authentication is an upcoming feature in a future release.',
        notAvailable: 'Not available'
    },
    group: {
        addMembers: 'Add Group Members',
        delete: 'Delete Group',
        deleteMessage: 'Are you sure you want to delete this group?',
        create: 'Create Group',
        description: 'Group Description',
        edit: 'Edit Group',
        members: 'Group Members',
        name: 'Group Name',
        noGroups: 'Press + to create your first group',

        error: {
            noMembers: 'A group must contain at least two members'
        },
        placeholder: {
            description: 'Describe this group (optional)',
            name: 'E.g. Family, Colleagues ...'
        }
    },
    invite: {
        inviteSelected: 'Invite selected people',
        invite: 'Invite',
        attendingQuestion: 'Are you attending this event?'

    },
    navigation: {
        events: 'Events',
        groups: 'Groups',
        newEvent: 'New Event',
        settings: 'Settings',
    },
    register: {
        alreadyRegistered: 'Already have an account?',
        withFacebook: 'Register with Facebook',
        withGoogle: 'Register with Google'
    },
    settings: {
        account: 'Account',
        privacy: 'Privacy Settings',
        logOut: 'Log Out',
        general: 'General',
        notifications: 'Notifications',
        preferences: 'Preferences',
        availability: 'Availability',
        appearance: 'Appearance',
        about: 'About',
        aboutApp: 'About the App',
        aboutUs: 'About Us'
    }
};

export default en;
