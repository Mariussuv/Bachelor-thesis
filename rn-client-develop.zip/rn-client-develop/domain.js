class Domain {
    getDomain() {
        const domain = 'https://roqet.xyz/';

        //Keep this line for testing backend - just comment out the above line
        // const domain = 'https://adaec486.ngrok.io/';

        return domain;
    }

    getApiDomain() {
        return this.getDomain() + 'api/';
    }
}

const domain = new Domain();
export default domain;
