import React, {Component} from 'react';
import {View, Text, Image, StyleSheet, StatusBar} from 'react-native';
import logo from "../assets/images/logo.png";
import RButton from "../components/Basic/RButton";
import LoginScreen from "./LoginScreen";
import i18n from "i18n-js";
import Colors from '../constants/Colors'

export default class WelcomeScreen extends Component {

    constructor(props) {
        super(props);

        this.state = {
            screen: 'welcome',
        }
    }

    render() {
        return (
            <View style={styles.container}>
                <StatusBar hidden/>
                <View style={styles.imgContainer}>
                    <Image source={logo} style={styles.img}/>
                </View>
                <View style={styles.headerContainer}>
                    <Text style={styles.headerText}>{i18n.t('roqet')}</Text>
                </View>
                <View style={styles.btnContainer}>
                    <View style={styles.btn}>
                        <RButton title={i18n.t('login')} color={'basic'}
                                 onPress={() => this.props.navigation.navigate('LoginScreen')}/>
                    </View>
                    <View style={styles.btn}>
                        <RButton title={i18n.t('signUp')} color={'basic'}
                                 onPress={() => this.props.navigation.navigate('RegisterScreen1')}/>
                    </View>
                </View>
            </View>
        )
    }
}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        backgroundColor: Colors.roqet
    },
    btnContainer: {
        flex: 1,
        flexDirection: 'row',
        marginTop: '15%'
    },
    headerContainer: {
        alignSelf: 'stretch',
        alignItems: 'center'
    },
    headerText: {
        fontSize: 100,
        color: 'white'
    },
    imgContainer: {
        marginTop: '15%',
    },
    img: {
        borderColor: 'white',
        borderWidth: 2,
        borderRadius: 30,
        height: 250,
        width: 250
    },
    btn: {
        margin: 8,
        padding: 2
    }
});
