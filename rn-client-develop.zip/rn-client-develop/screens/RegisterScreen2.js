import React, {Component} from 'react';
import {View, AsyncStorage, StatusBar, StyleSheet} from 'react-native';
import UserAPI from "../api/UserApiHandler";
import RInputField from "../components/Basic/RInputField";
import RButton from "../components/Basic/RButton";
import RAlertMessage from "../components/Basic/RAlertMessage";
import UserContext from "../context/user-context";
import i18n from "i18n-js";
import Colors from "../constants/Colors";

export default class RegisterScreen2 extends Component {

    static contextType = UserContext;

    constructor(props) {
        super(props);
        this.state = {
            validName: false,
            validSurname: false,
            validPhoneNumber: false,
            loggedIn: props.loggedIn,
            name: '',
            surname: '',
            phoneNumber: '',
            errorMessage: '',
            showError: false,
            validateName: false,
            validateSurname: false,
            validatePhoneNumber: false,
        };

        this.registerUser = this.registerUser.bind(this);
        this.showError = this.showError.bind(this);
        this.setCredentials = this.setCredentials.bind(this);
        this.validateFields = this.validateFields.bind(this);
    }

    setCredentials(token, userId) {
        AsyncStorage.setItem(
            '@Roqet:Token',
            JSON.stringify(token)
        );
        AsyncStorage.setItem(
            '@Roqet:UserId',
            JSON.stringify(userId)
        );
    }

    registerUser() {
        this.validateFields();
        if (this.state.validName && this.state.validSurname && this.state.validPhoneNumber) {
            const {email, password} = this.props.route.params;
            const user = {
                firstName: this.state.name,
                lastName: this.state.surname,
                email: email,
                phoneNumber: this.state.phoneNumber,
                password: password,
            };
            UserAPI.registerUser(user).then(newUser => {
                const user = {
                    username: email,
                    password: password,
                };
                UserAPI.logIn(user).then((data) => {
                        this.setCredentials(data.token, data.userId);
                        this.context.setToken(data.token);
                        this.context.setUserId(data.userId);
                        this.context.logIn();
                    }
                ).catch(error => {
                    this.setState({errorMessage: error.message, showError: true});
                    this.context.loggedIn = false;
                });
            }).catch((error) => this.setState({showError: true, errorMessage: error.message}));
        }
    }

    validateFields() {
        this.setState({
            validateName: true,
            validateSurname: true,
            validatePhoneNumber: true
        });
    }

    showError() {
        if (this.state.showError) {
            return (
                <RAlertMessage type={'danger'} text={this.state.errorMessage}/>
            )
        }
    }

    render() {
        return (
            <View style={styles.container}>
                <StatusBar hidden={true}/>
                <RInputField label={i18n.t('firstName')}
                             onChange={(name) => this.setState({name, validateName: false})}
                             value={this.state.name}
                             onValidate={(valid) => this.setState({validName: valid})}
                             validate={this.state.validateName}
                             type={'default'}
                             required={true}/>
                <RInputField label={i18n.t('lastName')}
                             onChange={(surname) => this.setState({surname, validateSurname: false})}
                             value={this.state.surname}
                             onValidate={(valid) => this.setState({validSurname: valid})}
                             validate={this.state.validateSurname}
                             type={'default'}
                             required={true}/>
                <RInputField label={i18n.t('phoneNumber')}
                             onChange={(phoneNumber) => this.setState({phoneNumber, validatePhoneNumber: false})}
                             value={this.state.phoneNumber}
                             onValidate={(valid) => this.setState({validPhoneNumber: valid})}
                             validate={this.state.validatePhoneNumber}
                             type={'phoneNumber'}
                             required={true}/>
                {this.showError()}
                <View style={styles.btn}>
                    <RButton color={'info'} title={'Sign Up'} onPress={() => this.registerUser()}/>
                </View>
            </View>
        )
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        paddingTop: 30,
        backgroundColor: Colors.backgroundColor
    },
    btn: {
        marginTop: 30,
        marginBottom: 40,
        padding: 2,
        alignItems: 'center'
    }
});
