import React, {Component} from 'react';
import {
    View,
    ScrollView,
    StatusBar,
    StyleSheet,
    Image,
    TouchableHighlight,
    Text,
    AsyncStorage,
    Alert,
    Platform
} from 'react-native';
import RInputField from "../components/Basic/RInputField";
import RButton from "../components/Basic/RButton";
import RAlertMessage from "../components/Basic/RAlertMessage";
import UserContext from "../context/user-context";
import fbLogo from "../assets/images/fb-logo.png";
import googleLogo from "../assets/images/google-logo.png";
import UserAPI from '../api/UserApiHandler';
import i18n from "i18n-js";
import Colors from "../constants/Colors";

export default class RegisterScreen1 extends Component {

    static contextType = UserContext;

    constructor(props) {
        super(props);
        this.state = {
            validEmail: false,
            validPassword: false,
            email: '',
            password: '',
            errorMessage: '',
            showError: false,
            missingField: false,
            validateEmail: false,
            validatePassword: false,
            validateConfirmedPassword: false
        };
        this.showError = this.showError.bind(this);
        this.validateFields = this.validateFields.bind(this);
        this.setCredentials = this.setCredentials.bind(this);
        this.sendExternalRegisterRequest = this.sendExternalRegisterRequest.bind(this);
    }

    setCredentials(token, userId) {
        AsyncStorage.setItem(
            '@Roqet:Token',
            JSON.stringify(token)
        );
        AsyncStorage.setItem(
            '@Roqet:UserId',
            JSON.stringify(userId)
        );
    }

    sendExternalRegisterRequest(provider) {
        if (provider === 'facebook') {
            UserAPI.authorizeWithFb().then(user => {
                    this.setCredentials(user.token, user.userId);
                    this.context.setToken(user.token);
                    this.context.setUserId(user.userId);
                    this.context.logIn();
                }
            ).catch(e => console.log(e));
        } else {
            UserAPI.authorizeWithGoogle()
                .then(response => {
                    this.setCredentials(response.accessToken, response.idToken);
                    this.context.logIn();
                }).catch(e => console.log(e));
        }
    }

    nextPage() {
        this.validateFields();
        if (this.state.validEmail && this.state.validPassword) {
            this.props.navigation.navigate('RegisterScreen2',
                {email: this.state.email, password: this.state.password})
        } else {
            this.setState({missingField: true});
        }
    }

    validateFields() {
        this.setState({
            validateEmail: true,
            validatePassword: true,
            validateConfirmedPassword: true,
        });
    }

    showError() {
        if (this.state.showError) {
            return (
                <RAlertMessage type={'danger'} text={this.state.errorMessage}/>
            )
        }
    }

    render() {
        return (
            <ScrollView style={styles.container}>
                <StatusBar hidden={true}/>
                <RInputField label={i18n.t('email')}
                             onChange={(email) => this.setState({email, validateEmail: false})}
                             value={this.state.email}
                             onValidate={(valid) => this.setState({validEmail: valid})}
                             validate={this.state.validateEmail}
                             type={'email'}
                             required={true}/>
                <RInputField onChange={(password) => {
                    this.setState({password, validatePassword: false});
                }}
                             onChangeConfirmedPassword={() => this.setState({validateConfirmedPassword: false})}
                             type={'confirmPassword'}
                             value={this.state.password}
                             onValidate={(valid) => this.setState({validPassword: valid})}
                             validate={this.state.validatePassword}
                             validateConfirmedPassword={this.state.validateConfirmedPassword}
                             required={true}/>
                {this.showError()}
                <View style={styles.btn}>
                    <RButton color={'info'} title={i18n.t('next')} onPress={() => this.nextPage()}/>
                </View>
                <View style={styles.externalLoginContainer}>
                    {
                        Platform.OS === 'ios' ?
                            <View style={styles.externalLoginBtn}>
                                <RButton icon={<Image source={fbLogo} style={styles.img}/>}
                                         title={i18n.t('register.withFacebook')} color={'facebook'} onPress={() =>
                                    Alert.alert(i18n.t('futureImplementation.notAvailable'),
                                        i18n.t('futureImplementation.facebook'))}/>
                            </View>
                            :
                            <View style={styles.externalLoginBtn}>
                                <RButton icon={<Image source={fbLogo} style={styles.img}/>}
                                         title={i18n.t('register.withFacebook')} color={'facebook'} onPress={() =>
                                    this.sendExternalRegisterRequest('facebook')}/>
                            </View>
                    }

                    <View style={styles.externalLoginBtn}>
                        <RButton icon={<Image source={googleLogo} style={styles.img}/>}
                                 title={i18n.t('register.withGoogle')} color={'basic'} onPress={() =>
                            Alert.alert(i18n.t('futureImplementation.notAvailable'),
                                i18n.t('futureImplementation.google'))}/>
                    </View>
                </View>

                <View style={styles.bottomTxt}>
                    <Text>{i18n.t('register.alreadyRegistered') + " "}</Text>
                    <TouchableHighlight
                        onPress={() => this.props.navigation.navigate('LoginScreen')}
                        activeOpacity={0.60}
                        underlayColor='white'>
                        <Text style={{color: 'blue'}}>{i18n.t('login')}</Text>
                    </TouchableHighlight>
                </View>
            </ScrollView>
        )
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        paddingTop: 10,
        backgroundColor: Colors.backgroundColor
    },
    btn: {
        margin: 15,
        alignItems: 'stretch'
    },
    externalLoginContainer: {
        margin: 15,
    },
    externalLoginBtn: {
        marginTop: '4%'
    },
    img: {
        width: 40,
        height: 40
    },
    bottomTxt: {
        flexDirection: 'row',
        justifyContent: 'center',
    }
});
