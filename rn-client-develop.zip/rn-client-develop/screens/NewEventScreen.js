import * as React from 'react';
import {Image, Keyboard, Platform, StatusBar, StyleSheet, Text, View} from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
import {ScrollView} from 'react-native-gesture-handler';
import {Component} from "react";
import UserContext from "../context/user-context";
import moment from "moment";
import EventAPI from "../api/EventApiHandler";
import {Icon} from "react-native-elements";
import RInputField from "../components/Basic/RInputField";
import i18n from "i18n-js";
import RDateTimePicker from "../components/Basic/RDateTimePicker";
import UploadImage from "../systemComponents/UploadImageComponents";
import Colors from "../constants/Colors";

export default class NewEventScreen extends Component {
    static contextType = UserContext;

    constructor(props) {
        super(props);
        this.state = {
            title: '',
            description: '',
            location: '',
            mode: 'date',
            show: false,
            aspNetDateTime: moment().add(2, 'h').startOf('hour'),
            jsDateTime: moment().add(2, 'h').startOf('hour').toDate(),
            imageUri: '',
            imageExtension: '',
            validate: false,
            validTitle: false,
            keyboardShown: false
        };

        this.postEvent = this.postEvent.bind(this);
    }

    componentDidMount() {
        Keyboard.addListener("keyboardDidShow", ()=> this.setState({keyboardShown: true}));
        Keyboard.addListener("keyboardDidHide", ()=> this.setState({keyboardShown: false}));
    }

    postEvent(navigation) {
        this.setState({validate: true});
        if (!this.state.validTitle) {
            return;
        }
        const newEvent = {
            title: this.state.title,
            description: this.state.description,
            location: this.state.location,
            dateTime: this.state.aspNetDateTime,
            ownerId: this.context.userId,
            imageUri: '' // If image, imageUri will be set in separate API
        };
        EventAPI.createNewEvent(this.context.userId, this.context.token, newEvent)
            .then(event => {
                if (this.state.imageUri !== '') {
                    const imageFile = UploadImage.createImageFile('',
                        this.state.imageUri, 'event', event.id, this.context.userId);
                    EventAPI.addEventImage(event.id, imageFile, this.context.userId)
                        .then(eventWithImage => {
                            this.setState({title: '', description: '', location: '', dateTime: '', imageUri: ''});
                            // Reset BottomTabNavigator to EventScreen
                            navigation.jumpTo('Events');
                            navigation.navigate('InviteScreen', {event: eventWithImage});
                        })
                        .catch(err => console.log(err));
                } else {
                    this.setState({title: '', description: '', location: '', dateTime: '', imageUri: '',
                    validate: false});
                    // Reset BottomTabNavigator to EventScreen
                    navigation.jumpTo('Events');
                    navigation.navigate('InviteScreen', {event});
                }
            }).catch(err => {
            console.log(err);
        });
    }

    render() {
        const {navigation} = this.props;
        let {imageUri} = this.state;

        return (
            <View style={styles.container}>
            <ScrollView style={styles.container}>
                <KeyboardAwareScrollView behavior='padding'
                                         resetScrollToCoords={{ x: 0, y: 0 }}
                                         scrollEnabled={false}>
                <View style={styles.imageContainer}>
                    {imageUri !== '' && <Image source={{uri: imageUri}} style={styles.img}/>}
                </View>
                {imageUri !== '' &&
                <View style={{position: 'absolute', right: '19.4%', top: '0.3%'}}>
                    <Icon name='times-circle-o' type='font-awesome' size={25} color={Colors.text}
                          onPress={() => this.setState({imageUri: ''})}/>
                </View>
                }
                <View style={styles.imageIcons}>
                    <View style={styles.cameraIcon}>
                        <Icon name='camera' type='font-awesome' size={30} color={Colors.text}
                              onPress={async () => this.setState(await UploadImage.getImageFromCamera())}/>
                    </View>
                    <View style={styles.cameraRollIcon}>
                        <Icon name='picture-o' type='font-awesome' size={30} color={Colors.text}
                              onPress={async () => this.setState(await UploadImage.getImageFromCameraRoll())}/>
                    </View>
                </View>
                <RInputField
                    label={i18n.t('title')}
                    placeholder={i18n.t('event.placeholder.title')}
                    onValidate={(valid) => this.setState({validTitle: valid})}
                    validate={this.state.validate}
                    maxLength={30}
                    onChange={title => this.setState({title})}
                    value={this.state.title}
                    required
                    type={'default'}
                />
                <RInputField
                    label={i18n.t('description')}
                    placeholder={i18n.t('event.placeholder.description')}
                    onChange={description => this.setState({description})}
                    value={this.state.description}
                    multiline={true}
                    numberOfLines={3}
                    type={'default'}
                />
                <RInputField
                    label={i18n.t('location')}
                    placeholder={i18n.t('event.placeholder.location')}
                    type={'default'}
                    onChange={location => this.setState({location})}
                    value={this.state.location}
                />
                <View style={{marginTop: '6%', marginBottom: 10}}>
                    <RDateTimePicker value={this.state.jsDateTime} onChange={(jsDateTime, aspNetDateTime) =>
                        this.setState({jsDateTime, aspNetDateTime})}/>
                </View>
                    <View style={styles.btn}>
                        <Icon raised reverse name='arrow-right' type='font-awesome'
                              color={Colors.roqet} size={25} onPress={() => this.postEvent(navigation)}/>
                    </View>
                </KeyboardAwareScrollView>
            </ScrollView>
                <View style={styles.hideKeyboardButton}>
                    {
                        this.state.keyboardShown && Platform.OS === 'android' &&
                            <Icon raised reverse name='arrow-down' type='font-awesome'
                                  color={Colors.primary} size={25} onPress={() => Keyboard.dismiss()}/>
                    }
                </View>
            </View>
        )
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.backgroundColor
    },
    btn: {
        alignItems: 'center',
        marginTop: 10
    },
    img: {
        borderWidth: 1,
        borderColor: Colors.text,
        borderRadius: 10,
        width: 200,
        height: 200,
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: '1%'
    },
    imageIcons: {
        flexDirection: 'row',
        justifyContent: 'center'
    },
    imageContainer: {
        alignItems: 'center',
        marginBottom: '4%',
        marginTop: '4%'
    },
    cameraIcon: {
        marginRight: 10,
        padding: '1%',
        borderWidth: 1,
        borderColor: Colors.text,
        borderRadius: 10
    },
    cameraRollIcon: {
        padding: '1%',
        borderWidth: 1,
        borderRadius: 10,
        borderColor: Colors.text
    },
    hideKeyboardButton: {
        flexDirection: 'row',
        justifyContent: 'center',
        borderTopWidth: StyleSheet.hairlineWidth,
        backgroundColor: Colors.backgroundColor,
        borderColor: Colors.text
    }
});
