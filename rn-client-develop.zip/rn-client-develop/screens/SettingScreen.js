import React, {Component} from 'react';
import {View, StyleSheet, AsyncStorage} from 'react-native';
import SettingElement from '../components/Settings/SettingElement';
import RHeader from '../components/Basic/RHeader';
import {ScrollView} from 'react-native-gesture-handler';
import UserContext from '../context/user-context'
import AboutUsScreen from "../components/Settings/AboutUsScreen";
import AboutAppScreen from "../components/Settings/AboutAppScreen";
import i18n from "i18n-js";
import Colors from "../constants/Colors";

export default class SettingScreen extends Component {

    static contextType = UserContext;

    // dummy function, does absolutely nothing. Only for prototype versions
    doNothing() {
    }

    async logOut() {
        this.context.logOut();
        try {
            await AsyncStorage.removeItem('@Roqet:Token');
            await AsyncStorage.removeItem('@Roqet:UserId');
        } catch (e) {
            console.log(e)
        }
    }

    render() {
        const {navigation} = this.props;
        return (
            <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
                <View style={{padding: 10}}>
                    <RHeader label={i18n.t('settings.account')}/>
                    <SettingElement label={i18n.t('settings.account')}
                                    onPress={() => navigation.navigate('AccountScreen')}/>
                    <View style={styles.disabled}>
                        <SettingElement label={i18n.t('settings.privacy')} onPress={this.doNothing}/>
                    </View>
                    <SettingElement label={i18n.t('settings.logOut')} onPress={() => this.logOut()}/>
                    <RHeader label={i18n.t('settings.general')}/>
                    <View style={styles.disabled}>
                        <SettingElement label={i18n.t('settings.notifications')} onPress={this.doNothing}/>
                        <SettingElement label={i18n.t('settings.preferences')} onPress={this.doNothing}/>
                        <SettingElement label={i18n.t('settings.availability')} onPress={this.doNothing}/>
                        <SettingElement label={i18n.t('settings.appearance')} disabled={true} onPress={this.doNothing}/>
                    </View>
                    <RHeader label={i18n.t('settings.about')}/>
                    <SettingElement label={i18n.t('settings.aboutApp')}
                                    onPress={() => navigation.navigate('AboutAppScreen')}/>
                    <SettingElement label={i18n.t('settings.aboutUs')}
                                    onPress={() => navigation.navigate('AboutUsScreen')}/>
                </View>
            </ScrollView>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.backgroundColor,
    },
    contentContainer: {
        paddingTop: 15,
    },
    disabled: {
        backgroundColor: 'lightgray'
    }
});
