import * as React from 'react';
import {Picker, RefreshControl, StyleSheet, Text, View} from 'react-native';
import UserContext from "../context/user-context";
import EventAPI from "../api/EventApiHandler";
import {ScrollView} from "react-native-gesture-handler";
import RButton from "../components/Basic/RButton";
import i18n from "i18n-js";
import EventTeaser from "../components/Event/EventTeaser";
import Colors from "../constants/Colors";

export default class EventScreen extends React.Component {
  static contextType = UserContext;

  constructor(props) {
    super(props);
    this.state = {
      text: '',
      loading: false,
      events: [],
      filteredEvents: [],
      filter: "active",
      refreshing: false,
      showFilter: false
    };

    this.refresh = this.refresh.bind(this);
  }

  componentDidMount() {
    this.refresh();
  };

  refresh = () => {
    this.setState({refreshing: true});
    this.loadEvents();
    this.setState({refreshing: false});
  };

  loadEvents(){
    EventAPI.getEvents(this.context.token, this.context.userId)
        .then(events => {
          // Order by date and then filter active.
          events.sort((a,b) => (a.event.dateTime < b.event.dateTime) ? -1 : (a.event.dateTime > b.event.dateTime) ? 1 : 0);
          this.setState({events, loading: false});
          this.filterEvents('active');
        }).catch(err => {
      console.log('Could not fetch from API: ' + err);
    });
  }

  filterEvents(f){
    this.setState({filter: f, filteredEvents: []});
    switch(f){
      case "active"://All events that is not declined
        var filteredList = this.state.events.filter(e => e.status != 2);
        this.setState({filteredEvents: filteredList});
        break;
      case "notAnswered"://All events that is not answered
        var filteredList = this.state.events.filter(e => e.status == 0);
        this.setState({filteredEvents: filteredList});
        break;
      case "alphabetical": //sort all events alphabetically
        var list = [...this.state.events];
        var sortedList = list.sort(function(a,b){
          return (a.event.title < b.event.title) ? -1 : (a.event.title > b.event.title) ? 1 : 0;
        });
        this.setState({filteredEvents: sortedList});
        break;
      case "date":
        var list = [...this.state.events];
        var sortedList = list.sort(function(a,b){
          return (a.event.dateTime < b.event.dateTime) ? -1 : (a.event.dateTime > b.event.dateTime) ? 1 : 0;
        });
        this.setState({filteredEvents: sortedList});
        break;
      case "host":
        var filteredList = this.state.events.filter(e => e.event.ownerId == this.context.userId);
        this.setState({filteredEvents: filteredList});
        break;
      default:
        this.setState({filteredEvents: this.state.events})
    }
  }

  showFilter(){
    this.setState({showFilter: !this.state.showFilter})
  }

  render() {
    const {navigation} = this.props;

    return (
        <View style={styles.container}>
          <ScrollView style={styles.scrollContainer} refreshControl={
            <RefreshControl refreshing={this.state.refreshing} onRefresh={this.refresh}/>
          }>
            <View style={{flex: 1}}>
              <View style={styles.buttonContainer}>
                <RButton title={i18n.t("event.filter")} color="roqet" onPress={()=>this.showFilter()}/>
              </View>
              {this.state.showFilter &&
              <Picker
                  selectedValue={this.state.filter}
                  style={styles.picker}
                  onValueChange={(itemValue, itemIndex) => this.filterEvents(itemValue)}
              >
                <Picker.Item label={i18n.t("event.active")} value="active"/>
                <Picker.Item label={i18n.t("event.notAnswered")} value="notAnswered"/>
                <Picker.Item label={i18n.t("event.alphabetical")} value="alphabetical"/>
                <Picker.Item label={i18n.t("event.date")} value="date"/>
                <Picker.Item label={i18n.t("event.host")} value="host"/>
                <Picker.Item label={i18n.t("event.all")} value="all"/>

              </Picker>
              }
            </View>
            <View style={{flex: 10}}>
              {this.state.loading ?
                  <View style={styles.loadingContainer}>
                    <Text>Loading...</Text>
                  </View>
                  :
                  this.state.filteredEvents.length > 0 ?
                      this.state.filteredEvents.map(i =>
                          <EventTeaser key={i.id} event={i.event}
                                       id={i.id} status={i.status}
                                       navigation={navigation}
                                       updateEvent={this.refresh}/>)
                      :
                      <View style={styles.noEventsContainer}>
                        <Text style={styles.noEventsTxt}>{i18n.t('event.noEvents')}</Text>
                      </View>
              }
            </View>
          </ScrollView>
        </View>
    )
  }
}

EventScreen.navigationOptions = {
  header: null,
};

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: Colors.backgroundColor,
    alignItems: 'flex-start',
  },
  noEventsContainer: {
    paddingTop: 200,
    padding: 40,
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center'
  },
  noEventsTxt: {
    fontSize: 20,
    color: 'gray',
    textAlign: 'center'
  },
  scrollContainer: {
    flex: 1,
    backgroundColor: Colors.backgroundColor
  },
  buttonContainer:{
    padding: 10
  },
  picker:{
    width: 350,
    flex: 1,
    alignSelf: "center",
    color: Colors.text
  },
  container:{
    flex: 1,
  }
});
