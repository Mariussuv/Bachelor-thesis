import React, {Component} from 'react';
import {StyleSheet, ScrollView, View, Text, RefreshControl} from 'react-native';
import GroupAPI from '../api/GroupApiHandler'
import i18n from "i18n-js";
import GroupTeaser from "../components/Group/GroupTeaser";
import UserContext from "../context/user-context";
import {Icon} from "react-native-elements";
import Colors from '../constants/Colors'

export default class GroupScreen extends Component {

    static contextType = UserContext;

    constructor(props) {
        super(props);

        this.state = {
            groupsWithMembers: [],
            addGroup: this.addGroup,
            loading: true,
            refreshing: false
        };

        this.addGroup = this.addGroup.bind(this);
        this.updateGroup = this.updateGroup.bind(this);
        this.deleteGroup = this.deleteGroup.bind(this);
        this.refresh = this.refresh.bind(this);
        this.loadGroups = this.loadGroups.bind(this);
    }

    componentDidMount() {
        this.loadGroups();
    }

    refresh = () => {
        this.setState({refreshing: true});
        this.loadGroups();
        this.setState({refreshing: false});
    };

    loadGroups() {
        GroupAPI.getGroups(this.context.token, this.context.userId)
            .then(groupsWithMembers => {
                groupsWithMembers.sort((a,b) =>
                    (a.group.groupName < b.group.groupName) ? -1 : (a.group.groupName > b.group.groupName) ? 1 : 0);
                this.setState({groupsWithMembers, loading: false});
            });
    }

    addGroup(newGroupWithMembers) {
        this.setState({groupsWithMembers: [...this.state.groupsWithMembers, newGroupWithMembers]})
    }

    updateGroup(newGroupWithMembers) {
        const tempGroupWithMembers = this.state.groupsWithMembers.filter(gwm =>
            gwm.group.id !== newGroupWithMembers.group.id);
        this.setState({groupsWithMembers: [...tempGroupWithMembers, newGroupWithMembers]})
    }

    deleteGroup(groupId) {
        const tempGroupWithMembers = this.state.groupsWithMembers.filter(gwm =>
            gwm.group.id !== groupId);
        this.setState({groupsWithMembers: tempGroupWithMembers});
    }

    render() {
        const {navigation} = this.props;
        return (
            <View style={styles.container}>
                {this.state.loading ?
                    <View style={styles.loadingContainer}>
                        <Text style={styles.loadingTxt}>Loading...</Text>
                    </View>
                    :
                    this.state.groupsWithMembers.length > 0 ?

                        <ScrollView style={styles.scrollView} refreshControl={
                            <RefreshControl refreshing={this.state.refreshing} onRefresh={this.refresh}/>}>
                            {
                                this.state.groupsWithMembers.map(groupWithMembers =>
                                    (<GroupTeaser key={groupWithMembers.group.id} groupWithMembers={groupWithMembers}
                                                  navigation={navigation} updateGroup={this.updateGroup}
                                                  deleteGroup={this.deleteGroup}/>))
                            }
                        </ScrollView>
                        :
                        <View style={styles.noGroupsContainer}>
                            <Text style={styles.noGroupsTxt}>{i18n.t('group.noGroups')}</Text>
                        </View>
                }
                <View style={styles.newGroupButton}>
                    <Icon
                        raised
                        reverse
                        name='plus'
                        type='font-awesome'
                        color={Colors.roqet}
                        size={27}
                        onPress={() => navigation.navigate('CreateGroup', {addGroup: this.addGroup})}/>
                </View>
            </View>
        );
    }

}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.backgroundColor,
    },
    scrollView: {
        flex: 1,
        backgroundColor: '#fafafa',
    },
    newGroupButton: {
        position: 'absolute',
        right: 10,
        bottom: 10,
    },
    noGroupsContainer: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        margin: 10
    },
    noGroupsTxt: {
        fontSize: 20,
        color: 'gray',
        textAlign: 'center'
    },
    loadingContainer: {
        alignItems: 'center',
        marginTop: 20
    },
    loadingTxt: {
        fontSize: 20,
        color: 'gray'
    }
});
