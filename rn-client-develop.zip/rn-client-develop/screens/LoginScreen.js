import React, {Component} from 'react';
import {
    StatusBar,
    StyleSheet,
    View,
    AsyncStorage,
    Image,
    Alert,
    Text,
    TouchableHighlight,
    ScrollView,
    Platform
} from 'react-native';
import RInputField from '../components/Basic/RInputField'
import RButton from '../components/Basic/RButton'
import UserAPI from '../api/UserApiHandler'
import UserContext from '../context/user-context'
import RAlertMessage from "../components/Basic/RAlertMessage";
import googleLogo from "../assets/images/google-logo.png";
import fbLogo from "../assets/images/fb-logo.png";
import Colors from "../constants/Colors";
import i18n from "i18n-js";

export default class LoginScreen extends Component {

    // Requires React V.16 or higher.
    static contextType = UserContext;

    constructor(props) {
        super(props);
        this.state = {
            validEmail: false,
            validPassword: false,
            loggedIn: props.loggedIn,
            passwordsAreIdentical: false,
            username: '',
            password: '',
            confirmedPassword: '',
            token: '',
            error: '',
            showError: false
        };

        this.sendExternalLoginRequest = this.sendExternalLoginRequest.bind(this);
        this.sendLoginRequest = this.sendLoginRequest.bind(this);
        this.setCredentials = this.setCredentials.bind(this);
        this.showError = this.showError.bind(this);
    }

    async setCredentials(token, userId) {
        try {
            await AsyncStorage.setItem('@Roqet:Token', token);
            await AsyncStorage.setItem('@Roqet:UserId', userId);
        } catch (e) {
            console.log(e)
        }
    }

    sendExternalLoginRequest(provider) {
        if (provider === 'facebook') {
            UserAPI.authorizeWithFb().then(async (user) => {
                    await this.setCredentials(user.token, user.userId);
                    this.context.setToken(user.token);
                    this.context.setUserId(user.userId);
                    this.context.logIn();
                }
            ).catch(err => console.log(err));
        } else {
            UserAPI.authorizeWithGoogle()
                .then(response => {
                    this.setCredentials(response.accessToken, response.idToken);
                    this.context.logIn();
                }).catch(err => console.log(err));
        }
    }

    sendLoginRequest() {
        const model = {
            username: this.state.username,
            password: this.state.password,
        };
        UserAPI.logIn(model).then(data => {
            this.setCredentials(data.token, data.userId);
            this.context.setToken(data.token);
            this.context.setUserId(data.userId);
            this.context.logIn();
        }).catch(error => {
            console.log(error);
            this.setState({errorMessage: error.message, showError: true, password: ''});
            this.context.loggedIn = false;
        });
    }

    showError() {
        if (this.state.showError) {
            return (
                <RAlertMessage type={'danger'} text={this.state.errorMessage}/>
            )
        } else {
            return null;
        }
    }

    render() {
        return (
            <ScrollView style={styles.container}>
                <StatusBar hidden={true}/>
                <View style={styles.inputFieldContainer}>
                    <RInputField label={i18n.t('email')} placeholder={''}
                                 onChange={(username) => this.setState({username})}
                                 value={this.state.username}
                                 type={'email'}
                                 required={false}/>
                </View>
                <View style={styles.inputFieldContainer}>
                    <RInputField label={i18n.t('password')}
                                 onChange={(password) => this.setState({password})}
                                 value={this.state.password}
                                 type={'password'}
                                 required={false}/>
                </View>
                {this.showError()}
                <View style={styles.btn}>
                    <RButton title={i18n.t('login')} color={'info'} onPress={() => this.sendLoginRequest()}/>
                </View>
                <View style={styles.externalLoginContainer}>
                    {
                        Platform.OS === 'ios' ?
                            <View style={styles.externalLoginBtn}>
                                <RButton icon={<Image source={fbLogo} style={styles.img}/>}
                                         title={i18n.t('register.withFacebook')} color={'facebook'} onPress={() =>
                                    Alert.alert(i18n.t('futureImplementation.notAvailable'),
                                        i18n.t('futureImplementation.facebook'))}/>
                            </View>
                            :
                            <View style={styles.externalLoginBtn}>
                                <RButton icon={<Image source={fbLogo} style={styles.img}/>}
                                         title={i18n.t('loginWithFacebook')} color={'facebook'} onPress={() =>
                                    this.sendExternalLoginRequest('facebook')}/>
                            </View>
                    }
                    <View style={styles.externalLoginBtn}>
                        <RButton icon={<Image source={googleLogo} style={styles.img}/>}
                                 title={i18n.t('loginWithGoogle')} color={'basic'}
                                 onPress={() => Alert.alert(i18n.t('futureImplementation.notAvailable'),
                                     i18n.t('futureImplementation.google'))}/>
                    </View>
                </View>
                <View style={styles.bottomTxt}>
                    <Text>{i18n.t('noAccountQuestion')} </Text>
                    <TouchableHighlight
                        onPress={() => this.props.navigation.navigate('RegisterScreen1')}
                        activeOpacity={0.60}
                        underlayColor='white'>
                        <Text style={{color: 'blue'}}>{i18n.t('signUp')}</Text>
                    </TouchableHighlight>
                </View>
            </ScrollView>
        )
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        paddingTop: 10,
        backgroundColor: Colors.backgroundColor
    },
    inputFieldContainer: {
        marginBottom: 0
    },
    btn: {
        flex: 1,
        margin: 15,
        marginBottom: 5
    },
    txt: {
        color: 'white',
        fontSize: 20
    },
    txtContainer: {
        alignItems: 'center'
    },
    externalLoginContainer: {
        marginTop: '10%',
        margin: '6%',
    },
    externalLoginBtn: {
        marginTop: '5%'
    },
    img: {
        width: 40,
        height: 40
    },
    bottomTxt: {
        flexDirection: 'row',
        justifyContent: 'center',
        marginBottom: 10
    }
});
