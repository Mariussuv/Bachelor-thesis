import React, {Component} from 'react';
import {TouchableHighlight, View, Text, StyleSheet, Platform, Modal} from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import moment from 'moment'
import Colors from "../../constants/Colors";
import { Icon } from 'react-native-elements'

/**
 * Props:
 *
 * - onPress() -> runs when ok button is pressed and is used to set the time in the mother component
 * - value -> the default time shown by the date / time picker
 */

export default class RDateTimePicker extends Component {
    constructor(props) {
        super(props);
        this.state = {
            displayTime: moment(this.props.value).format('HH:mm'),
            time: moment(this.props.value),
            displayDate: moment(this.props.value).format('DD.MM.YYYY'),
            date: moment(this.props.value),
            mode: '',
        };

        this.showDatePicker = this.showDatePicker.bind(this);
        this.showTimePicker = this.showTimePicker.bind(this);
        this.onChange = this.onChange.bind(this);
    }

    showDatePicker = () => {
        this.setState({mode: 'date', show: true});
    };

    showTimePicker = () => {
        this.setState({mode: 'time', show: true});
    };

    // If mode is date or time, return the date or time in each respective format
    onChange = (event, selectedDateTime) => {

        // Keep current date if cancel button is pressed
        if(event.type === "dismissed") {
            this.setState({show: false});
            return;
        }

        // setState must be called here, because it is an asynchronous operation, so it does not run right away
        this.setState({show: false});

         if(this.state.mode === 'date') {
             this.setState({date: moment(selectedDateTime),
                 displayDate: Platform.OS === 'ios' ? moment.utc(selectedDateTime).format('DD.MM.YYYY') :
                     moment(selectedDateTime).format('DD.MM.YYYY')})
         } else {
             this.setState({time: moment(selectedDateTime),
                 displayTime: Platform.OS === 'ios' ? moment.utc(selectedDateTime).format('HH:mm') :
                     moment(selectedDateTime).format('HH:mm')
             })
         }

            // Concatenate date and time to one variable. Using two variables because different
            // formats are used in js and asp net
            const aspNetDateTime = moment(moment(this.state.date).startOf('day'))
                .add(this.state.time.hours(), 'h').add(this.state.time.minute(), 'm')
                .format();

            const jsDateTime = moment(moment(this.state.date).startOf('day'))
                .add(this.state.time.hours(), 'h').add(this.state.time.minute(), 'm').toDate();


            // Run function from parent component: CreateEvent
            this.props.onChange(jsDateTime, aspNetDateTime);
    };

    render() {
        return (
            <View style={styles.container}>
                <View style={styles.subContainer1}>
                    <TouchableHighlight style={[styles.dateBtn, styles.btn]} onPress={() => this.showDatePicker()}
                                        activeOpacity={0.85} underlayColor={'gray'}>
                        <Text style={styles.text}>
                            {this.state.displayDate}
                        </Text>
                    </TouchableHighlight>
                    <TouchableHighlight style={[styles.iconBtn, styles.btn]} onPress={() => this.showDatePicker()}
                                        activeOpacity={0.85} underlayColor={'gray'}>
                        <Icon name='event' type='material' size={35}/>
                    </TouchableHighlight>
                </View>

                <View style={styles.subContainer2}>
                    <TouchableHighlight style={[styles.timeBtn, styles.btn]} onPress={() => this.showTimePicker()}
                                        activeOpacity={0.85} underlayColor={'gray'}>
                            <Text style={styles.text}>
                                {this.state.displayTime}
                            </Text>
                    </TouchableHighlight>
                    <TouchableHighlight style={[styles.iconBtn, styles.btn]} onPress={() => this.showTimePicker()}
                                        activeOpacity={0.85} underlayColor={'gray'}>
                            <Icon name='schedule' type='material' size={35}/>
                    </TouchableHighlight>
                </View>



                {this.state.show && Platform.OS === 'ios' && (
                    <Modal
                        visible={this.state.visible}
                        onDismiss={() => this.setState({ visible: false })}
                    >
                        <DateTimePicker
                            style={{ width: '100%', backgroundColor: Colors.backgroundColor, height: '100%' }}
                            timeZoneOffsetInMinutes={0}
                            value={this.props.value}
                            mode={this.state.mode}
                            display='default'
                            onChange={this.onChange}
                        />
                    </Modal>
                )}

                {this.state.show && Platform.OS === 'android' && (
                        <DateTimePicker
                            style={{ width: '100%', backgroundColor: Colors.backgroundColor, height: '100%' }}
                            value={this.props.value}
                            mode={this.state.mode}
                            is24Hour={true}
                            display='default'
                            onChange={this.onChange}
                        />
                )}
            </View>
        )
    }
}

// styles are same as in RInputField
const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: '2%',
    },
    subContainer1: {
        flex: 3,
        flexDirection: 'row',
        marginLeft: '4%',
        marginRight: '4%',
        borderWidth: 1,
        borderColor: 'gray',
        borderRadius: 6
    },
    subContainer2: {
        flex: 2,
        flexDirection: 'row',
        marginLeft: '4%',
        marginRight: '4%',
        borderWidth: 1,
        borderColor: 'gray',
        borderRadius: 6
    },
    text: {
        fontSize: 20,
        paddingTop: '9%',
        paddingBottom: '9%',
        color: Colors.text
    },
    btn: {
        alignItems: 'center',
        justifyContent: 'center',
    },
    dateBtn: {
        flex: 2,
    },
    timeBtn: {
        flex: 1,
    },
    iconBtn: {
        flex: 1,
        borderLeftWidth: 1,
        borderColor: 'gray',
        backgroundColor: 'lightgray',
        borderTopRightRadius: 5,
        borderBottomRightRadius: 5
    },
    icon: {
        borderColor: 'gray',
        justifyContent: 'center',
        backgroundColor: 'lightgray'
    },
    clockIconContainer: {
        borderColor: 'gray',
        borderTopRightRadius: 6,
        borderBottomRightRadius: 6,
        borderWidth: 1,
        padding: '0%',
        paddingRight: '4%',
        paddingLeft: '4%',
        justifyContent: 'center',
        backgroundColor: 'lightgray'
    }
});
