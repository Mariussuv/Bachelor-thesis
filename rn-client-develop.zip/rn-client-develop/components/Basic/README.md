#Basic Components
This document contains information about how to use the basic components
in our app.

RInputField
---
Props:
   - label
   - placeholder
   - onChange() -> function that runs when text is changed
   - onChangeConfirmedPassword() -> only if type = confirmPassword
   - value
   - type (email, password, numeric, default, alphabetical, confirmPassword, phoneNumber) -> searches regex to see if content is valid
   - required (true, false)
   - onFocus -> function that runs when focus
   - autofocus (boolean) -> focus inputBox on componentDidMount
   - maxLength (integer) -> Maximum characters allowed
   - multiline (boolean)
   - numberOfLines -> must be used together with multiline
   - validate (boolean) - indicates when error is going to be shown.
   - validateConfirmedPassword -> indicates when error is going to be shown. (only if type = confirmPassword)
   - onValidate(valid) - toggles a boolean from the mother component which indicates if the input is correct or not.
   
Example:
```
<RInputField label={'Password'}
             onChange={(password) => this.setState({password})}
             value={this.state.password}
             type={'password'}
             required={true}/>
```

RButton
---
Props:
   - onPress
   - title
   - color
   - icon
   
Example:
```
<RButton title={'Create'} color='primary' onPress= {() => this.postEvent()} />
```

RAlertMessage
---
Props:
   - Type (default, primary, info, warning, danger, success, secondary, basic, roqet). 
   Sets the color of the alert container.
   - Text (the alert message displayed)
   
Example:
```
<RAlertMessage type={'danger'} text={'This is an error message.'}/>
```

RDateTimePicker
---
Props:
   - onPress(dateTimeJSformat, dateTimeAspNetformat) -> runs when ok button is pressed and is used to update the time in the mother component
   - value -> the default time shown by the date / time picker
   
Example:
```
<RDateTimePicker value={this.state.dateTime} onChange={(dateTime) =>
                         this.setState({dateTimeJS, datetimeAspNet})}/>
```

RHeader
---
Props:
   - label
   
Example:
```
<RHeader label={i18n.t('settings.account')}/>
```
