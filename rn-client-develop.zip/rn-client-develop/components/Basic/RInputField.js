import React, {Component} from 'react';
import {StyleSheet, Text, TextInput, View} from 'react-native';
import i18n from "i18n-js";
import {Icon} from "react-native-elements";
import Colors from "../../constants/Colors";

/**
 * Props:
 *
 * - label
 * - placeholder
 * - onChange -> function that runs when text is changed
 * - onChangeConfirmedPassword() -> only if type = confirmPassword
 * - value
 * - type (email, password, numeric, default, alphabetical, confirmPassword, phoneNumber) -> search regex to see if content is valid
 * - required (true, false)
 * - onFocus -> function that runs when focus
 * - autofocus (boolean) -> focus inputBox on componentDidMount
 * - maxLength (integer) -> Maximum characters allowed
 * - multiline (boolean)
 * - numberOfLines -> must be used together with multiline
 * - validate (boolean) - indicates when error is going to be shown.
 * - validateConfirmedPassword -> indicates when error is going to be shown. (only if type = confirmPassword)
 * - onValidate(valid) - toggles a boolean from the mother component which indicates if the input is correct or not.
 */

export default class RInputField extends Component {
    constructor(props) {
        super(props);
        this.state = {
            input: '',
            borderColor: 'gray',
            borderColorConfirmedPassword: 'gray',
            keyboardType: 'default',
            regex: /^.*/,
            whiteSpaceRegex: /^\s+/,
            secure: false,
            confirmedPassword: '',
            errorMessageWrong: i18n.t('error.invalid') + ' ' + this.props.label?.toLowerCase(),
            errorMessageEmpty: i18n.t('error.requiredField'),
            errorMessageConfirmedPassword: '',
            passwordHidden: true,
            confirmPasswordHidden: true
        };
        this.validate = this.validate.bind(this);
    }

    componentDidMount() {
        switch (this.props.type) {
            case 'email':
                this.setState({
                    keyboardType: 'email-address',
                    errorMessageWrong: i18n.t('error.invalidEmail'),
                    regex: /^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/
                });
                break;
            case 'numeric':
                this.setState({
                    keyboardType: 'numeric',
                    errorMessageWrong: i18n.t('error.invalidInput'),
                    regex: /^[0-9]+$/
                });
                break;
            case 'phoneNumber':
                this.setState({
                    keyboardType: 'phone-pad',
                    errorMessageWrong: i18n.t('error.invalidPhoneNumber'),
                    regex: /^[0-9 \+\#\*\-]+$/
                });
                break;
            case 'password':
                // Password must be at least 10 characters long and contain at least numbers, uppercase,
                // lowercase and one of these characters: !@#$%^&.*
                this.setState({
                    keyboardType: 'default',
                    errorMessageWrong: i18n.t('error.invalidPassword'),
                    regex: /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*\.])(?=.{10,})/,
                    secure: true
                });
                break;
            case 'confirmPassword':
                // Password must be at least 10 characters long and contain at least numbers, uppercase, lowercase and  one of these characters: !@#$%^&*
                this.setState({
                    errorMessageWrong: i18n.t('error.invalidPassword'),
                    regex: /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*\.])(?=.{10,})/,
                    passwordRequirements: i18n.t('error.passwordRequirements'),
                    errorMessageConfirmedPassword: i18n.t('error.passwordsMismatch')
                });
                break;
            case 'alphabetical':
                this.setState({
                    errorMessageWrong: i18n.t('error.invalidInput'),
                    regex: /^[a-zA-Z\.\-]+[a-zA-Z\.\- ]*$/
                });
                break;
            default:
                break;
        }
    }

    validate(text) {
        this.props.onChange(text);
        if (this.props.type === 'confirmPassword') {
            if ((!this.state.regex.test(text))) {
                if (this.state.confirmedPassword) {
                    this.setState({borderColorConfirmedPassword: 'firebrick'});
                }
                this.setState({borderColor: 'firebrick'});
                if (this.props.onValidate)
                    this.props.onValidate(false);
            } else {
                if (this.state.confirmedPassword && text === this.state.confirmedPassword) {
                    this.setState({borderColor: 'lightgreen', borderColorConfirmedPassword: 'lightgreen'});
                    if (this.props.onValidate)
                        this.props.onValidate(true);
                } else if (this.state.confirmedPassword) {
                    this.setState({borderColorConfirmedPassword: 'firebrick', borderColor: 'lightgreen'});
                    if (this.props.onValidate)
                        this.props.onValidate(false);
                } else {
                    this.setState({borderColor: 'lightgreen'});
                    if (this.props.onValidate)
                        this.props.onValidate(false);
                }
            }
        } else {
            if (!this.props.required) {
                this.setState({borderColor: 'gray'});
            } else if (!this.state.regex.test(text) || text === '' || this.state.whiteSpaceRegex.test(text)) {
                this.setState({borderColor: 'firebrick'});
                if (this.props.onValidate)
                    this.props.onValidate(false);
            } else {
                this.setState({borderColor: 'gray'});
                if (this.props.onValidate)
                    this.props.onValidate(true);
            }
        }
    }

    validatePassword(confirmedPassword) {
        this.setState({confirmedPassword});
        this.props.onChangeConfirmedPassword(false);
        if (confirmedPassword === this.props.value && this.state.regex.test(this.props.value)) {
            this.setState({borderColorConfirmedPassword: 'lightgreen'});
            if (this.props.onValidate)
                this.props.onValidate(true);
        } else {
            this.setState({borderColorConfirmedPassword: 'firebrick'});
            if (this.props.onValidate)
                this.props.onValidate(false);
        }
    }

    calculatePasswordEyePosition() {
        if ((this.state.borderColor === 'firebrick' || !this.props.value) && this.props.validate) {
            if (this.props.value === '') {
              return '41.8%';
            } else {
                return '29%';
            }
        } else {
            return '54%';
        }
    }

    render() {
        return (
            <View>
                {this.props.type !== 'confirmPassword' ?
                    <View style={styles.container}>
                        <Text style={styles.label}>{this.props.label}</Text>
                        <TextInput
                            keyboardType={this.state.keyboardType}
                            style={[styles.txtBox, {borderColor: this.state.borderColor, maxHeight: 200,
                                minHeight: this.props.multiline ? 30*this.props.numberOfLines : 0}]}
                            placeholder={this.props.placeholder}
                            secureTextEntry={this.state.secure}
                            onChangeText={(text) => this.validate(text)}
                            multiline={this.props.multiline}
                            maxLength={this.props.maxLength}
                            numberOfLines={this.props.numberOfLines}
                            textAlignVertical={'top'}
                            onFocus={() => {
                                if (this.props.onFocus)
                                    this.props.onFocus()
                            }}
                            autofocus={this.props.autofocus}
                            value={this.props.value}/>
                        {
                            this.props.type === 'password' &&
                            <Icon
                                name={this.state.secure ? 'eye' : 'eye-slash'}
                                type='font-awesome'
                                containerStyle={[styles.eye, {top: '55%'}]}
                                onPress={() => this.setState({secure: !this.state.secure})} />
                        }
                        {(this.state.borderColor === 'firebrick' || this.props.value === '')
                        && this.props.validate && <Text style={styles.errorTxt}>{'\u25CF'} {
                            this.props.value === '' ? this.state.errorMessageEmpty
                                :
                                this.state.errorMessageWrong}</Text>
                        }
                    </View>
                    :
                    // Confirm password fields
                    <View>
                        <View style={styles.container}>
                            <Text style={styles.label}>{i18n.t('password')}</Text>
                            <TextInput
                                placeholder={this.props.placeholder}
                                keyboardType={this.state.keyboardType}
                                style={[styles.txtBox, {borderColor: this.state.borderColor}]}
                                secureTextEntry={this.state.passwordHidden}
                                autofocus={this.props.autofocus}
                                onChangeText={(password) => this.validate(password)}
                                value={this.props.value}/>
                            <Icon
                                name={this.state.passwordHidden ? 'eye' : 'eye-slash'}
                                type='font-awesome'
                                containerStyle={[styles.eye, {top: this.calculatePasswordEyePosition()}]}
                                onPress={() => this.setState({passwordHidden: !this.state.passwordHidden})} />
                            {
                                (this.state.borderColor === 'firebrick' || this.props.value === '')
                                && this.props.validate &&
                                <View>
                                    <Text style={styles.errorTxt}>{'\u25CF'}
                                        {
                                            this.props.value === '' ? this.state.errorMessageEmpty
                                                :
                                                this.state.errorMessageWrong
                                        }
                                    </Text>
                                    {
                                        this.props.value !== '' &&
                                        <Text style={styles.errorTxtPwd}>
                                            - {this.state.passwordRequirements}
                                        </Text>
                                    }
                                </View>
                            }
                        </View>
                        <View style={styles.container}>
                            <Text style={styles.label}>{i18n.t('confirmPassword')}</Text>
                            <TextInput style={[styles.txtBox, {borderColor: this.state.borderColorConfirmedPassword}]}
                                       secureTextEntry={this.state.confirmPasswordHidden}
                                       onChangeText={(confirmedPassword) => this.validatePassword(confirmedPassword)}
                                       value={this.state.confirmedPassword}/>
                            <Icon
                                name={this.state.confirmPasswordHidden ? 'eye' : 'eye-slash'}
                                type='font-awesome'
                                containerStyle={[styles.eye, {top:
                                        (this.state.borderColorConfirmedPassword === 'firebrick' ||
                                            !this.state.confirmedPassword) && this.props.validateConfirmedPassword ?
                                            (!this.props.confirmedPassword ? '40.5%' : '35%') : '55%'}]}
                                onPress={() =>
                                    this.setState({confirmPasswordHidden: !this.state.confirmPasswordHidden})} />
                            {
                                (this.state.borderColorConfirmedPassword === 'firebrick' ||
                                    this.state.confirmedPassword === '') && this.props.validateConfirmedPassword &&
                                <Text style={styles.errorTxt}>{'\u25CF'}
                                    {
                                        this.state.confirmedPassword === '' ? this.state.errorMessageEmpty
                                            :
                                            this.state.errorMessageConfirmedPassword
                                    }
                                </Text>
                            }
                        </View>
                    </View>
                }
            </View>
        )
    }
}
const styles = StyleSheet.create({
    container: {
        marginBottom: 10,
        marginTop: 10,
        marginLeft: '4%',
        marginRight: '4%'
    },
    label: {
        fontSize: 20,
        fontWeight: 'bold',
        marginLeft: 2,
        color: Colors.text
    },
    errorTxt: {
        fontSize: 15,
        marginLeft: 2,
        marginTop: 5,
        color: 'firebrick'
    },
    errorTxtPwd: {
        fontSize: 12,
        marginLeft: 20,
        marginTop: 5,
        color: 'firebrick'
    },
    txtBox: {
        borderRadius: 6,
        borderWidth: 1,
        fontSize: 20,
        padding: 10,
        paddingLeft: 15,
        marginTop: 8,
        alignSelf: 'stretch',
        backgroundColor: Colors.backgroundColor,
        color: Colors.text
    },
    eye: {
        position: 'absolute',
        right: '5%',
    }
});
