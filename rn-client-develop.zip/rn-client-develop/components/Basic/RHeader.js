import React, {Component} from 'react';
import  {Text, View, StyleSheet} from 'react-native';
import Colors from '../../constants/Colors'


/**
 * Props:
 *  - Label
 */

export default class RHeader extends Component{
    constructor(props){
        super(props);
    }

    render(){
        return(
            <View style={styles.container}>
                <Text style={styles.text}>{this.props.label}</Text>
            </View>
        )
    }
}

const styles = StyleSheet.create({
    container:{
        backgroundColor: Colors.roqet,
        padding: 10,
        borderBottomWidth: 1,
        fontSize: 40,
        borderColor: 'white'
    },
    text:{
        fontSize: 30,
        color: 'white'
    }
})
