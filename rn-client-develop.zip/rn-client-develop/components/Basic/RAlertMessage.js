import React, {Component} from 'react';
import {View, Text, StyleSheet} from 'react-native';
import Colors from '../../constants/Colors'

/**
 * Props:
 *  - Type (default, primary, info, warning, danger, success, secondary, basic, roqet)
 *  - Text
 */

export default class RAlertMessage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            backgroundColor: Colors.backgroundColor,
            txtColor:'black',
            borderColor:''
        }
    }

    componentDidMount() {
        switch(this.props.type) {
            case 'default':
                this.setState({backgroundColor: Colors.alert.default, txtColor: Colors.txtColors.default, borderColor: Colors.borderColors.default});
                break;
            case 'primary':
                this.setState({backgroundColor: Colors.alert.primary, txtColor: Colors.txtColors.primary, borderColor: Colors.borderColors.primary});
                break;
            case 'info':
                this.setState({backgroundColor: Colors.alert.info, txtColor: Colors.txtColors.info, borderColor: Colors.borderColors.info});
                break;
            case 'warning':
                this.setState({backgroundColor: Colors.alert.warning, txtColor: Colors.txtColors.warning, borderColor: Colors.borderColors.warning});
                break;
            case 'danger':
                this.setState({backgroundColor: Colors.alert.danger, txtColor: Colors.txtColors.danger, borderColor: Colors.borderColors.danger});
                break;
            case 'success':
                this.setState({backgroundColor: Colors.alert.success, txtColor: Colors.txtColors.success, borderColor: Colors.borderColors.success});
                break;
            case 'secondary':
                this.setState({backgroundColor: Colors.alert.secondary, txtColor: Colors.txtColors.secondary, borderColor: Colors.borderColors.secondary});
                break;
            case 'basic':
                this.setState({backgroundColor: Colors.alert.basic, txtColor: Colors.txtColors.basic, borderColor: Colors.borderColors.basic});
                break;
            case 'roqet':
                this.setState({backgroundColor: Colors.roqet, txtColor: Colors.txtColors.roqet, borderColor: Colors.borderColors.roqet});
                break;
        }
    }

    render() {
        return (
            <View style={[styles.container, {backgroundColor: this.state.backgroundColor, borderColor: this.state.borderColor}]}>
                <Text style={[styles.txt, {color: this.state.txtColor}]}>{this.props.text}</Text>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        padding: 10,
        borderWidth: 1,
        borderRadius: 6,
        overflow: 'hidden',
        margin: 20
    },
    txt: {
        fontSize: 20
    }
}) ;
