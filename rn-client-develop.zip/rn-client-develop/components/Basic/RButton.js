import React, { Component } from 'react';
import {StyleSheet, Text, TouchableHighlight, View} from 'react-native';
import Colors from '../../constants/Colors';


/**
 * Props:
 *
 *  - color -> background color (success, info, warning, default, danger, primary, secondary, basic, facebook). Same
 *  as bootstrap button colors.
 *  - title -> button text
 *  - icon
 *  - onPress()
 */
export default class RButton extends Component {
    constructor(props) {
        super(props);
        this.state = {
            color: 'blue',
            txtColor: 'white',
            borderColor: 'black'
        }
    }

    componentDidMount() {
        switch (this.props.color) {
            case 'default':
                this.setState({color: Colors.default, txtColor: 'black', borderColor: Colors.borderColors.default});
                break;
            case 'primary':
                this.setState({color: Colors.primary, borderColor: Colors.borderColors.primary});
                break;
            case 'info':
                this.setState({color: Colors.info, borderColor: Colors.borderColors.info});
                break;
            case 'warning':
                this.setState({color: Colors.warning, borderColor: Colors.borderColors.warning});
                break;
            case 'danger':
                this.setState({color: Colors.danger, borderColor: Colors.borderColors.danger});
                break;
            case 'success':
                this.setState({color: Colors.success, borderColor: Colors.borderColors.success});
                break;
            case 'secondary':
                this.setState({color: Colors.secondary, borderColor: Colors.borderColors.secondary});
                break;
            case 'basic':
                this.setState({color: Colors.basic, borderColor: Colors.borderColors.basic, txtColor: Colors.txtColors.basic});
                break;
            case 'roqet':
                this.setState({color: Colors.roqet, borderColor: Colors.borderColors.roqet});
                break;
            case 'facebook':
                this.setState({color: Colors.facebook, borderColor: Colors.borderColors.facebook});
                break;
            default:
                // Option for writing colors or color codes into the color prop
                this.setState({color: this.props.color, borderColor: this.props.color});
                break;
        }
    }

    render() {
        return (
            <TouchableHighlight
                style={[styles.container, {backgroundColor: this.state.color,
                borderColor: this.state.borderColor}]}
                activeOpacity={0.85}
                underlayColor={this.state.borderColor}
                title={this.props.title} onPress={() => this.props.onPress()}>
                {
                    this.props.icon ?
                        <View style={styles.btnContent}>
                            <View style={styles.icon}>{this.props.icon}</View>
                            <Text style={[styles.txt, {color: this.state.txtColor}]}>{this.props.title}</Text>
                        </View>
                        :
                        <Text style={[styles.txt, {color: this.state.txtColor}]}>{this.props.title}</Text>
                }
            </TouchableHighlight>
        )
    }
}
const styles = StyleSheet.create({
    container: {
        alignItems: 'center',
        padding: 6,
        borderWidth: 1,
        borderRadius: 6,
    },
    txt: {
        fontSize: 22,
        margin: 2,
        marginLeft: 5,
        marginRight: 5
    },
    btnContent: {
        alignSelf: 'stretch',
        flexDirection: 'row'
    },
    icon: {
        marginRight: 20,
        marginLeft: 5
    }
});
