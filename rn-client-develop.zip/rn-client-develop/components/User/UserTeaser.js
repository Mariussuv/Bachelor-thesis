import React, {Component} from "react";
import {TouchableHighlight} from "react-native-gesture-handler";
import {Icon} from "react-native-elements";
import {Text, View, StyleSheet, Image} from "react-native";
import Ionicons from "react-native-vector-icons/Ionicons";
import domain from "../../domain";
import Colors from "../../constants/Colors";

const DOMAIN = domain.getDomain();

/**
 * Props:
 *
 * - user
 * - selected (boolean)
 * - onPress()
 * - locked (boolean) - gives a gray color to indicates it is disabled
 * - status (invited/attending) - green heart if attending, yellow if not.
 */

export default class UserTeaser extends Component {
    constructor(props) {
        super(props);
        this.state = {
            name: '',
            id: props.id,
            selected: false
        }
    }

    render() {
        const name = this.props.user.firstName + ' ' + this.props.user.lastName;
        // If name is longer than 28 characters it will not be fully displayed, because it will overlap the icon
        const extension = name.length > 28 ? '...' : '';
        let displayName = name.substring(0, 28) + extension;
        return (
            <TouchableHighlight style={[styles.touchableContainer,
                {backgroundColor: this.props.selected ? this.props.locked ? '#dddddd' : 'rgb(235, 241, 242)' : 'transparent'}]}
                                onPress={() => this.props.onPress()}
                                activeOpacity={1} underlayColor={this.props.selected ? this.props.locked ?
                '#dddddd' : 'rgb(235, 241, 242)' : 'transparent'}>
                <View style={styles.container}>
                    <View style={styles.icon}>
                        {
                            this.props.user.imageUri ?
                                <Image source={{uri: DOMAIN + this.props.user.imageUri}} style={styles.img}/>
                                :
                                < Icon
                                    raised
                                    name='user'
                                    type='font-awesome'
                                    color={Colors.roqet}
                                    size={18}
                                />
                        }
                    </View>
                    <View style={styles.txtContainer}>
                        <Text style={styles.name}>{displayName}</Text>
                    </View>
                    {
                        this.props.selected &&
                        <View style={styles.checkMark}>
                            <Icon color='#79a2ab' name='check' position='absolute' right={10} top={10} size={35}/>
                        </View>
                    }
                    {
                        this.props.status &&
                        <View style={styles.heartIcon}>
                            <Ionicons color={this.props.status === 'invited' ? Colors.heart.yellow : Colors.heart.green}
                                      name='md-heart' size={25}/>
                        </View>
                    }
                </View>
            </TouchableHighlight>
        )
    }
}

const styles = StyleSheet.create({
    touchableContainer: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'flex-start',
    },
    container: {
        flexDirection: 'row',
        flex: 1,
        paddingRight: 10
    },
    txtContainer: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'center',
        padding: 2,
        paddingLeft: 0,
        marginLeft: 6,
    },
    icon: {
        justifyContent: 'center',
        alignItems: 'center'
    },
    checkMark: {
        alignContent: 'flex-end',
    },
    name: {
        fontSize: 15,
        color: Colors.text
    },
    heartIcon: {
        justifyContent: 'center',
        alignItems: 'flex-end',
        paddingRight: 10,
    },
    img: {
        width: 40,
        height: 40,
        margin: 7,
        borderRadius: 50,
        borderWidth: StyleSheet.hairlineWidth,
        borderColor: Colors.text
    }
});
