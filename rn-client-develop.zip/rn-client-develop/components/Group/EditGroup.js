import React, {Component} from 'react';
import {StyleSheet, Text, View, ScrollView, Alert, Image, Keyboard, Platform} from 'react-native';
import UserContext from "../../context/user-context";
import RInputField from "../Basic/RInputField";
import UserAPI from "../../api/UserApiHandler";
import GroupAPI from "../../api/GroupApiHandler";
import i18n from "i18n-js";
import {Icon} from "react-native-elements";
import UserTeaser from "../User/UserTeaser";
import UploadImage from "../../systemComponents/UploadImageComponents";
import domain from "../../domain";
import Colors from "../../constants/Colors";

const DOMAIN = domain.getDomain();

export default class EditEvent extends Component {

    static contextType = UserContext;

    constructor(props) {
        const {navigation} = props;
        const {group, users, deleteGroup} = props.route.params;

        // Make list of groupMemberIds
        let userIds = [];
        users.forEach(m => userIds = [...userIds, m.id]);

        super(props);
        this.state = {
            groupName: group.groupName,
            description: group.description,
            groupId: group.id,
            groupMembers: users,
            groupMemberIds: userIds,
            allUsers: [],
            validate: false,
            validName: group.groupName.length > 1,
            deleteGroup: deleteGroup,
            navigation: navigation,
            imageUri: group.imageUri ? DOMAIN + group.imageUri : '',
            oldImageUri: group.imageUri,
            oldImageUriWithDomain: DOMAIN + group.imageUri,
            keyboardShown: false
        };

        this.selectFriend = this.selectFriend.bind(this);
        this.editGroup = this.editGroup.bind(this);
        this.deleteGroup = this.deleteGroup.bind(this);
    }

    editGroup() {
        // A group is only valid if it has a name and at least two members (yourself and one more)
        this.setState({validate: true});
        if (!this.state.validName || this.state.groupMemberIds.length < 2) {
            return;
        }

        const {group, users, updateGroup} = this.props.route.params;

        const groupModel = {
            userId: this.context.userId,
            token: this.context.token,
            description: this.state.description,
            name: this.state.groupName,
            memberIds: this.state.groupMemberIds,
            imageUri: this.state.imageUri === '' ? '' : this.state.oldImageUri
        };

        GroupAPI.editGroup(groupModel, group.id)
            .then(groupWithMembers => {
                if (this.state.imageUri && this.state.imageUri !== this.state.oldImageUriWithDomain) {
                    const groupId = groupWithMembers.group.id;
                    const imageFile = UploadImage.createImageFile(this.state.oldImageUri,
                        this.state.imageUri, 'group', groupId, this.context.userId);
                    GroupAPI.addGroupImage(groupId, imageFile, this.context.userId)
                        .then(group => {
                            // Add ImageUri to group
                            groupWithMembers.group = group;
                            if (updateGroup) {
                                updateGroup(groupWithMembers);
                            }
                            this.state.navigation.navigate('GroupDetails', {groupWithMembers});
                        })
                        .catch(err => console.log(err));
                } else {
                    if (updateGroup) {
                        updateGroup(groupWithMembers);
                    }
                    this.state.navigation.navigate('GroupDetails', {groupWithMembers});
                }
            }).catch(() => {
            const groupWithMembers = {group, users};
            this.state.navigation.navigate('GroupDetails', {groupWithMembers})
        });
    }

    deleteGroup() {
        GroupAPI.deleteGroup(this.state.groupId, this.context.userId, this.context.token)
            .then(() => {
                if (this.state.deleteGroup) {
                    this.state.deleteGroup(this.state.groupId);
                }
                this.state.navigation.popToTop()
            })
            .catch(err => console.log(err));
    }

    componentDidMount() {
        Keyboard.addListener("keyboardDidShow", () => this.setState({keyboardShown: true}));
        Keyboard.addListener("keyboardDidHide", () => this.setState({keyboardShown: false}));
        UserAPI.getUsers()
            .then(allUsers => {
                // Sort users alphabetically
                allUsers.sort((a, b) => (a.firstName < b.firstName) ? -1 : (a.firstName > b.firstName) ? 1 : 0);
                this.setState({allUsers});
            }).catch(err => {
            console.log(err);
        })
    }

    selectFriend(selectedId) {
        if (!this.state.groupMemberIds.includes(selectedId)) {
            const groupMemberIds = [...this.state.groupMemberIds, selectedId];
            this.setState({groupMemberIds});
        } else {
            const groupMemberIds = this.state.groupMemberIds.filter(id => id !== selectedId);
            this.setState({groupMemberIds});
        }
    }

    render() {
        let {imageUri} = this.state;

        return (
            <View style={styles.container}>
                <ScrollView style={styles.container}>
                    <View style={styles.imageContainer}>
                        {imageUri !== '' && <Image source={{uri: imageUri}} style={styles.img}/>}
                    </View>
                    {imageUri !== '' &&
                    <View style={{position: 'absolute', right: '19.4%', top: '0.3%'}}>
                        <Icon name='times-circle-o' type='font-awesome' size={25} color={Colors.text}
                              onPress={() => this.setState({imageUri: ''})}/>
                    </View>
                    }
                    <View style={styles.imageIcons}>
                        <View style={{marginRight: 10, padding: '1%', borderWidth: 1, borderRadius: 10}}>
                            <Icon name='camera' type='font-awesome' size={30} color={Colors.text}
                                  onPress={async () => this.setState(await UploadImage.getImageFromCamera())}/>
                        </View>
                        <View style={{padding: '1%', borderWidth: 1, borderRadius: 10}}>
                            <Icon name='picture-o' type='font-awesome' size={30} color={Colors.text}
                                  onPress={async () => this.setState(await UploadImage.getImageFromCameraRoll())}/>
                        </View>
                    </View>
                    <RInputField
                        label={i18n.t('group.name')}
                        placeholder={i18n.t('group.placeholder.name')}
                        onChange={groupName => this.setState({groupName})}
                        value={this.state.groupName}
                        maxLength={30}
                        type={'default'}
                        required={true}
                        validate={this.state.validate}
                        onValidate={(validName) => this.setState({validName})}
                    />
                    <RInputField
                        label={i18n.t('group.description')}
                        placeholder={i18n.t('group.placeholder.description')}
                        onChange={description => this.setState({description})}
                        value={this.state.description}
                        multiline={true}
                        numberOfLines={3}
                        type={'default'}
                    />
                    <View
                        style={{
                            marginTop: '5%',
                            marginBottom: '5%'
                        }}
                    />
                    <Text style={styles.label}>{i18n.t('group.members')}</Text>
                    {this.state.groupMemberIds.length < 2 && this.state.validate &&
                    <Text style={styles.errorTxt}>{'\u25CF'} {i18n.t('group.error.noMembers')}</Text>
                    }
                    <ScrollView style={styles.scrollView} nestedScrollEnabled={true}>
                        {this.state.allUsers.map(user => {
                                return (
                                    this.state.groupMemberIds.includes(user.id) ?
                                        <UserTeaser selected={true}
                                                    user={user}
                                                    key={user.id}
                                                    onPress={() => this.selectFriend(user.id)}/>
                                        :
                                        <UserTeaser selected={false}
                                                    user={user}
                                                    key={user.id}
                                                    onPress={() => this.selectFriend(user.id)}/>)
                            }
                        )}
                    </ScrollView>
                </ScrollView>
                {
                    this.state.keyboardShown && Platform.OS === 'android' ?
                        <View style={styles.footerBtnContainer}>
                            <Icon raised reverse name='arrow-down' type='font-awesome'
                                  color={Colors.primary} size={25} onPress={() => Keyboard.dismiss()}/>
                        </View>
                        :
                        <View style={styles.footerBtnContainer}>
                            <View style={styles.footerBtn}>
                                <Icon color={Colors.danger} name='trash-o' type='font-awesome' size={25} raised reverse
                                      onPress={() => Alert.alert(
                                          i18n.t('group.delete'),
                                          i18n.t('group.deleteMessage'),
                                          [
                                              {text: i18n.t('no')},
                                              {text: i18n.t('yes'), onPress: () => this.deleteGroup()}
                                          ])}/>
                            </View>
                            <View style={styles.footerBtn}>
                                <Icon name='save' type='font-awesome' color={Colors.success} size={25} raised reverse
                                      onPress={() => this.editGroup()}/>
                            </View>
                            {
                                this.state.validate && (!this.state.validName || this.state.selectedFriends < 2)
                                && <Text style={styles.asterisk}>*</Text>
                            }
                        </View>
                }
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.backgroundColor
    },
    scrollView: {
        margin: '5%',
        marginTop: '5%',
        borderTopWidth: 1
    },
    label: {
        fontSize: 20,
        fontWeight: 'bold',
        marginLeft: '5%',
        color: Colors.text
    },
    errorTxt: {
        fontSize: 15,
        marginLeft: '5%',
        marginTop: 5,
        color: 'firebrick'
    },
    footerBtnContainer: {
        flexDirection: 'row',
        justifyContent: 'center',
        padding: 4,
        borderTopWidth: StyleSheet.hairlineWidth,
    },
    footerBtn: {
        marginRight: 8,
    },
    img: {
        borderWidth: 1,
        borderRadius: 10,
        borderColor: Colors.text,
        width: 200,
        height: 200,
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: '1%'
    },
    imageIcons: {
        flexDirection: 'row',
        justifyContent: 'center'
    },
    imageContainer: {
        alignItems: 'center',
        marginBottom: '4%',
        marginTop: '4%'
    },
    asterisk: {
        color: 'firebrick',
        fontSize: 25,
        marginLeft: 6
    }
});
