import React, {Component} from 'react';
import {Image, StyleSheet, Text, View, Keyboard, Platform} from "react-native";
import UserAPI from '../../api/UserApiHandler'
import GroupAPI from '../../api/GroupApiHandler'
import RInputField from "../Basic/RInputField";
import UserContext from "../../context/user-context";
import i18n from "i18n-js";
import {ScrollView} from "react-native-gesture-handler";
import UserTeaser from "../User/UserTeaser";
import UploadImage from "../../systemComponents/UploadImageComponents";
import {Icon} from "react-native-elements";
import Colors from "../../constants/Colors";

export default class CreateGroup extends Component {

    static contextType = UserContext;

    constructor(props) {
        super(props);
        this.state = {
            name: '',
            description: '',
            friends: [],
            selectedFriends: [],
            loading: true,
            validName: false,
            validate: false,
            imageUri: '',
            imageExtension: '',
            keyboardShown: false
        };

        this.postGroup = this.postGroup.bind(this);
        this.selectFriend = this.selectFriend.bind(this);
    }

    componentDidMount() {
        Keyboard.addListener("keyboardDidShow", ()=> this.setState({keyboardShown: true}));
        Keyboard.addListener("keyboardDidHide", ()=> this.setState({keyboardShown: false}));
        UserAPI.getUsers()
            .then(friends => {
                friends.sort((a,b) => (a.firstName < b.firstName) ? -1 : (a.firstName > b.firstName) ? 1 : 0);
                this.setState({friends, loading: false});
            }).catch(err => {
            console.log(err);
        })
    }

    postGroup() {
        this.setState({validate: true});
        if (!this.state.validName || this.state.selectedFriends.length < 1) {
            return;
        }
        const {navigation} = this.props;
        const groupModel = {
            userId: this.context.userId,
            token: this.context.token,
            name: this.state.name,
            description: this.state.description,
            memberIds: [...this.state.selectedFriends, this.context.userId],
        };
        GroupAPI.createGroup(groupModel)
            .then(newGroupWithMembers => {
                const groupId = newGroupWithMembers.group.id;
                if (this.state.imageUri) {
                    const imageFile = UploadImage.createImageFile('',
                        this.state.imageUri, 'group', groupId, this.context.userId);
                    GroupAPI.addGroupImage(groupId, imageFile, this.context.userId)
                        .then(group => {
                            newGroupWithMembers.group = group;
                            // Reset BottomTabNavigator to EventScreen
                            this.props.route.params.addGroup(newGroupWithMembers);
                            navigation.navigate(i18n.t('navigation.events'), {newGroupWithMembers});
                        })
                        .catch(err => console.log(err));
                } else {
                    this.props.route.params.addGroup(newGroupWithMembers);
                    navigation.navigate(i18n.t('navigation.events'), {newGroupWithMembers});
                }
            }).catch(err => {
            console.log(err);
        });
    }

    selectFriend(selectedId) {
        if (!this.state.selectedFriends.includes(selectedId)) {
            const selectedFriends = [...this.state.selectedFriends, selectedId];
            this.setState({selectedFriends});
        } else {
            const selectedFriends = this.state.selectedFriends.filter(id => id != selectedId);
            this.setState({selectedFriends});
        }
    }

    render() {
        let {imageUri} = this.state;

        return (
            <View style={styles.container}>
            <ScrollView>
                <View style={styles.imageContainer}>
                    {imageUri !== '' && <Image source={{uri: imageUri}} style={styles.img}/>}
                </View>
                {imageUri !== '' &&
                <View style={{position: 'absolute', right: '19.4%', top: '0.3%'}}>
                    <Icon name='times-circle-o' type='font-awesome' size={25} color={Colors.text}
                          onPress={() => this.setState({imageUri: ''})}/>
                </View>
                }
                <View style={styles.imageIcons}>
                    <View style={styles.cameraIcon}>
                        <Icon name='camera' type='font-awesome' size={30} color={Colors.text}
                              onPress={async () => this.setState(await UploadImage.getImageFromCamera())}/>
                    </View>
                    <View style={styles.cameraRollIcon}>
                        <Icon name='picture-o' type='font-awesome' size={30} color={Colors.text}
                              onPress={async () => this.setState(await UploadImage.getImageFromCameraRoll())}/>
                    </View>
                </View>
                <RInputField
                    label={i18n.t('group.name')}
                    placeholder={i18n.t('group.placeholder.name')}
                    onChange={name => this.setState({name})}
                    value={this.state.name}
                    maxLength={30}
                    validate={this.state.validate}
                    onValidate={(validName) => this.setState({validName})}
                    type={'default'}
                    required
                />
                <RInputField
                    label={i18n.t('group.description')}
                    placeholder={i18n.t('group.placeholder.description')}
                    onChange={description => this.setState({description})}
                    value={this.state.description}
                    type={'default'}
                    multiline={true}
                    numberOfLines={3}
                />
                <Text style={styles.label}>{i18n.t('group.addMembers')}:</Text>
                {this.state.selectedFriends.length < 1 && this.state.validate &&
                <Text style={styles.errorTxt}>{'\u25CF'} {i18n.t('group.error.noMembers')}</Text>
                }
                <ScrollView style={styles.scrollView} contentContainerStyle={{flexGrow: 1}} nestedScrollEnabled={true}>
                    <View>
                        {this.state.friends.map(friend => {
                                return (
                                    this.state.selectedFriends.includes(friend.id) ?
                                        <UserTeaser selected={true}
                                                    user={friend}
                                                    key={friend.id}
                                                    onPress={() => this.selectFriend(friend.id)}/>
                                        :
                                        friend.id !== this.context.userId &&
                                            <UserTeaser selected={false}
                                                        user={friend}
                                                        key={friend.id}
                                                        onPress={() => this.selectFriend(friend.id)}/>
                                            )
                            }
                        )}
                    </View>
                </ScrollView>
            </ScrollView>
                    <View style={styles.btn}>
                        {
                            this.state.keyboardShown && Platform.OS === 'android' ?
                                <Icon raised reverse name='arrow-down' type='font-awesome'
                                      color={Colors.primary} size={25} onPress={() => Keyboard.dismiss()}/>
                                :
                                <Icon raised reverse name='check' type='font-awesome'
                                      color={Colors.success} size={25} onPress={() => this.postGroup()}/>
                        }
                        {
                            this.state.validate && (!this.state.validName || this.state.selectedFriends < 2)
                            && <Text style={styles.asterisk}>*</Text>
                        }
                    </View>
            </View>
        )
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.backgroundColor
    },
    btn: {
        flexDirection: 'row',
        justifyContent: 'center',
        borderTopWidth: StyleSheet.hairlineWidth,
        backgroundColor: Colors.backgroundColor,
        borderColor: Colors.text
    },
    scrollView: {
        margin: '5%',
        marginTop: 10,
        marginBottom: 0,
    },
    label: {
        fontSize: 20,
        fontWeight: 'bold',
        marginLeft: '5%',
        marginTop: 20,
        color: Colors.text
    },
    errorTxt: {
        fontSize: 15,
        marginLeft: '5%',
        marginTop: 5,
        color: 'firebrick'
    },
    img: {
        borderWidth: 4,
        borderRadius: 10,
        width: 200,
        height: 200,
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: '1%'
    },
    imageIcons: {
        flexDirection: 'row',
        justifyContent: 'center'
    },
    imageContainer: {
        alignItems: 'center',
        marginBottom: '4%',
        marginTop: '4%'
    },
    cameraIcon: {
        marginRight: 10,
        padding: '1%',
        borderWidth: 1,
        borderColor: Colors.text,
        borderRadius: 10
    },
    cameraRollIcon: {
        padding: '1%',
        borderWidth: 1,
        borderRadius: 10,
        borderColor: Colors.text
    },
    asterisk: {
        color: 'firebrick',
        fontSize: 25,
        marginLeft: 6
    }
});
