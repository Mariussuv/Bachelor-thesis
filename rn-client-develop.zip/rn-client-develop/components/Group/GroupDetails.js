import React from 'react';
import {Image, StyleSheet, Text, View} from "react-native";
import i18n from "i18n-js";
import {ScrollView} from "react-native-gesture-handler";
import {Icon} from "react-native-elements";
import UserTeaser from "../User/UserTeaser";
import domain from "../../domain";
import Colors from "../../constants/Colors";

const DOMAIN = domain.getDomain();

export default function GroupDetails({navigation, route}) {

    const {group, users} = route.params.groupWithMembers;
    const {updateGroup, deleteGroup} = route.params;

    // Sort users alphabetically
    users.sort((a, b) => (a.firstName < b.firstName) ? -1 : (a.firstName > b.firstName) ? 1 : 0);

    navigation.setOptions({
        headerTitle: group.groupName
    });

    return (
        <View style={styles.container}>
            <ScrollView style={styles.container}>
                {group.imageUri !== '' && group.imageUri !== undefined && group.imageUri !== null &&
                <View style={styles.imgContainer}>
                    <Image source={{uri: DOMAIN + group.imageUri}} style={styles.img}/>
                </View>
                }
                <Text style={styles.label}>{i18n.t('group.name')}</Text>
                <View>
                    <Text style={styles.textBox}>{group.groupName}</Text>
                </View>
                {
                    group.description !== '' &&
                    <Text style={styles.label}>{i18n.t('group.description')}</Text>
                }
                {
                    group.description !== '' &&
                    <View>
                        <Text style={styles.textBox}>{group.description}</Text>
                    </View>
                }

                <Text style={styles.label}>{i18n.t('group.members')}</Text>
                <ScrollView style={styles.scrollView} contentContainerStyle={{flexGrow: 1}} nestedScrollEnabled={true}>
                    <View>
                        {
                            users.map(user => {
                                return (
                                    <UserTeaser selected={false}
                                                user={user}
                                                key={user.id}
                                                onPress={() => ''}/>
                                )
                            })
                        }
                    </View>
                </ScrollView>
            </ScrollView>
            <View style={styles.editBtn}>
                <Icon raised reverse name='edit' type='font-awesome'
                      color={Colors.roqet} size={25} onPress={() =>
                    navigation.navigate('EditGroup', {group, users, updateGroup, deleteGroup})}/>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.backgroundColor
    },
    scrollView: {
        margin: '5%',
        marginTop: 20,
        marginBottom: 0,
        borderRadius: 10
    },
    label: {
        fontSize: 20,
        fontWeight: 'bold',
        marginLeft: '5%',
        marginTop: '2%',
        color: Colors.text
    },
    userContainer: {
        flex: 1,
        padding: 6,
        borderWidth: 1,
        borderRadius: 6,
        height: 50,
        margin: 1
    },
    textBox: {
        borderRadius: 6,
        borderWidth: 1,
        borderColor: Colors.text,
        fontSize: 20,
        padding: 10,
        paddingLeft: 15,
        margin: '5%',
        alignSelf: 'stretch',
        color: Colors.text
    },
    imgContainer: {
        borderBottomWidth: 0.8,
        alignItems: 'center'
    },
    img: {
        width: 250,
        height: 250,
        borderWidth: 1,
        borderColor: 'black',
        borderRadius: 10,
        marginTop: '4%',
        marginBottom: '4%'
    },
    editBtn: {
        flexDirection: 'row',
        justifyContent: 'center',
        borderTopWidth: StyleSheet.hairlineWidth,
        borderColor: Colors.text,
        backgroundColor: Colors.backgroundColor
    }
});
