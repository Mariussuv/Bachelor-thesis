import React from 'react';
import {View, Text, StyleSheet, TouchableHighlight, useWindowDimensions, Image} from 'react-native';
import {Icon} from 'react-native-elements'
import domain from "../../domain";
import Colors from '../../constants/Colors'

const DOMAIN = domain.getDomain();

export default function GroupTeaser(props) {
    const {navigation, groupWithMembers, updateGroup, deleteGroup} = props;
    const windowWidth = useWindowDimensions().width;
    const imageUri = groupWithMembers.group.imageUri;

    // When dividing by 30 and rounding to nearest we get the appropriate number of displayed bubbles
    const numberOfBubbles = Math.round(windowWidth / 30);

    // When dividing by 12 (13 if checkMark is shown) and rounding to nearest we get the appropriate length for the displayed group name
    const nameDividingFactor = props.selected ? 13 : 12;
    const groupNameMaxDisplayLength = Math.round(windowWidth / nameDividingFactor);
    const groupNameLength = groupWithMembers.group.groupName?.length;

    // When dividing by 9 (11 if checkMark is shown) and rounding to nearest we get the appropriate length for the displayed description text
    const descriptionDividingFactor = props.selected ? 11 : 9;
    const descriptionMaxDisplayLength = Math.round(windowWidth / descriptionDividingFactor);
    const descriptionLength = groupWithMembers.group.description?.length;

    const slicedUsers = groupWithMembers.users.slice(0, groupWithMembers.users.length > numberOfBubbles ?
        numberOfBubbles : numberOfBubbles + 1);

    return (
        <TouchableHighlight
            style={[styles.touchableContainer, {backgroundColor: props.selected ? 'white' : 'transparent'}]}
            onPress={() => {
                props.selectable ?
                    props.onPress()
                    :
                    navigation.navigate('GroupDetails', {groupWithMembers, updateGroup, deleteGroup})
            }}
            activeOpacity={1} underlayColor='transparent'>
            <View style={styles.container}>
                {
                    imageUri ?
                        <View style={styles.imgContainer}>
                            <Image source={{uri: DOMAIN + imageUri}} style={styles.img}/>
                        </View>
                        :
                            <Icon
                                raised
                                name='users'
                                type='font-awesome'
                                color={Colors.roqet}
                                size={30}
                            />
                }
                <View style={styles.txtContainer}>
                    <Text style={styles.name}>
                        {/* Limit the length of the group title so that it does not exceed its line length. */}
                        {groupWithMembers.group.groupName?.slice(0, groupNameLength > groupNameMaxDisplayLength ?
                        groupNameMaxDisplayLength - 1 : groupNameMaxDisplayLength)}
                        {groupNameLength > groupNameMaxDisplayLength && '...'}
                    </Text>
                    {
                        <Text style={styles.description}>
                            {groupWithMembers.group.description?.slice(0, descriptionLength >
                                descriptionMaxDisplayLength ? descriptionMaxDisplayLength -1 : descriptionMaxDisplayLength)}
                            {descriptionLength > descriptionMaxDisplayLength && '...'}
                        </Text>
                    }
                    <View style={[styles.members, {justifyContent: 'flex-start'}]}>
                        {
                            slicedUsers.map((member) => {
                                return (
                                    member?.imageUri ?
                                        <View style={styles.memberBubble} key={member?.id}>
                                            <Image source={{uri: DOMAIN + member?.imageUri}} style={styles.bubbleImg}/>
                                        </View>
                                        :
                                        <View style={styles.memberBubble} key={member?.id}>
                                            <Text style={styles.memberInitials}>
                                                {member?.firstName.charAt(0)}{member?.lastName.charAt(0)}
                                            </Text>
                                        </View>
                                )
                            })
                        }
                        {
                            groupWithMembers.users.length > numberOfBubbles &&
                            <View style={styles.memberBubble}>
                                <Text style={styles.memberInitials}>+</Text>
                            </View>
                        }
                    </View>
                </View>
                {
                    props.selected &&
                    <View>
                        <View style={styles.checkMark}>
                            <Icon color='#79a2ab' name='check' position='absolute' right={20}
                                  top={groupWithMembers.users?.length >= numberOfBubbles ? 0 : 20} size={35}/>
                        </View>
                    </View>
                }
            </View>
        </TouchableHighlight>
    );
}

const styles = StyleSheet.create({
    touchableContainer: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'flex-start',
    },
    container: {
        flexDirection: 'row',
        flex: 1,
        padding: 2,
        backgroundColor: Colors.backgroundColor
    },
    txtContainer: {
        flexDirection: 'column',
        flex: 1,
        padding: 2,
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderColor: Colors.text,
        marginRight: 4
    },
    icon: {
        alignItems: 'center',
        justifyContent: 'center'
    },
    img: {
        width: 65,
        height: 65,
        borderRadius: 50
    },
    imgContainer: {
        alignItems: 'center',
        justifyContent: 'center',
        paddingRight: '2%',
        paddingLeft: '2%',
        padding: 7.5
    },
    name: {
        fontSize: 18,
        fontWeight: 'bold',
        color: Colors.text,
    },
    description: {
        fontSize: 14,
        color: Colors.text,
    },
    members: {
        flexDirection: 'row',
        marginTop: '2%'
    },
    memberBubble: {
        borderWidth: StyleSheet.hairlineWidth,
        borderColor: Colors.text,
        borderRadius: 50,
        width: 20,
        height: 20,
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: 1
    },
    memberInitials: {
        fontSize: 10,
        color: Colors.text
    },
    checkMark: {
        position: "absolute",
        flex: 1,
        right: 0,
        alignContent: 'flex-end'
    },
    bubbleImg: {
        borderWidth: StyleSheet.hairlineWidth,
        borderColor: Colors.text,
        borderRadius: 50,
        width: 20,
        height: 20,
        alignItems: 'center',
        justifyContent: 'center',
    }
});
