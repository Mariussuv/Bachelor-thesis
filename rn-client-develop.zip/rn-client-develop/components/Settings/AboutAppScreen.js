import * as React from "react";
import {StyleSheet, Text, View} from 'react-native';
import Colors from "../../constants/Colors";

export default function AboutApp() {

        return (
            <View style={styles.container}>
                <Text style={styles.txtContainer}>
                    Roqet is an application designed to instantly create and host events with
                    your friends, whether it is casual or more formal. Speed is of the essence here.
                    Simply type in title, description, location and set date and time, invite your
                    friends and you are good to go! The idea behind it is to mitigate the need of
                    messaging as important information tend to be lost in groups as the conversation
                    grows.
                </Text>
            </View>
        );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        backgroundColor: Colors.backgroundColor,
    },
    txtContainer: {
        lineHeight: 20,
        margin: 10,
        color: Colors.text
    }
});
