import * as React from "react";
import {StyleSheet, Text, View} from 'react-native';
import Colors from "../../constants/Colors";

export default function AboutUs() {

        return (
            <View style={styles.container}>
                <Text style={styles.txtContainer}>
                    During the development of this application, we were three computer
                    engineering students, whose task was to plan, research and implement
                    this application as our bachelor thesis during spring semester 2020.
                    In cooperation with our supervisor, this application was formed to
                    what it is today. Additional consulting was contributed by Agens, a
                    company based in Grimstad that specializes in application
                    implementation.
                </Text>
                <Text style={styles.txtContainer}>
                    In addition to being a bachelor thesis project, this application was
                    initially a business idea, therefore we are planning on further
                    development and optimization.
                </Text>
            </View>
        );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        backgroundColor: Colors.backgroundColor,
    },
    txtContainer: {
        lineHeight: 20,
        margin: 10,
        color: Colors.text
    }
});
