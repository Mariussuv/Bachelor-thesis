import React, {Component} from 'react';
import {Text, View, StyleSheet} from 'react-native';
import {TouchableHighlight} from 'react-native';
import {Icon} from 'react-native-elements';
import Colors from "../../constants/Colors";

export default class SettingElement extends Component {
    constructor(props) {
        super(props);

        this.state = {
            disabled: true
        }
    }

    render() {
        return (
            <TouchableHighlight onPress={() => this.props.onPress()}
                                activeOpacity={1} underlayColor='lightgray'>
                <View style={styles.container}>
                    <View>
                        <Text style={styles.text}>{this.props.label}</Text>
                    </View>
                    <View style={styles.icon}>
                        <Icon color='#79a2ab' name='chevron-right' position='absolute' right={10}/>
                    </View>
                </View>
            </TouchableHighlight>
        )
    }
}

const styles = StyleSheet.create({
    container: {
        padding: 10,
        borderBottomWidth: 1,
        borderColor: '#79a2ab',
        flexDirection: 'row'
    },
    text: {
        color: Colors.text
    },
    icon: {
        flex: 1,
        width: 200,
        alignContent: 'flex-end',
    }
});
