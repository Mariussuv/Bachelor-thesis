import React, {Component} from 'react';
import {Image, Keyboard, StyleSheet, View} from 'react-native';
import UserContext from "../../context/user-context";
import RInputField from "../Basic/RInputField";
import UserAPI from "../../api/UserApiHandler";
import i18n from "i18n-js";
import {Icon} from "react-native-elements";
import UploadImage from "../../systemComponents/UploadImageComponents";
import {ScrollView} from "react-native-gesture-handler";
import domain from "../../domain";
import Colors from "../../constants/Colors";

const DOMAIN = domain.getDomain();

export default class Account extends Component {

    static contextType = UserContext;

    constructor(props) {
        super(props);
        this.state = {
            firstName: '',
            lastName: '',
            phoneNumber: '',
            imageUri: '',
            imageExtension: '',
            keyboardShown: false
        };

        this.editAccount = this.editAccount.bind(this);
    }

    componentDidMount() {
        Keyboard.addListener("keyboardDidShow", () => this.setState({keyboardShown: true}));
        Keyboard.addListener("keyboardDidHide", () => this.setState({keyboardShown: false}));
        UserAPI.getUser(this.context.userId)
            .then(user => {
                this.setState({
                    firstName: user.firstName,
                    lastName: user.lastName,
                    phoneNumber: user.phoneNumber,
                    imageUri: user.imageUri ? DOMAIN + user.imageUri : '',
                    oldImageUri: user.imageUri
                });
            }).catch(err => {
            console.log(err);
        })
    }

    editAccount() {
        const {navigation} = this.props;
        const newInfoModel = {
            userId: this.context.userId,
            token: this.context.token,
            user: {
                firstName: this.state.firstName,
                lastName: this.state.lastName,
                phoneNumber: this.state.phoneNumber,
                imageUri: this.state.imageUri === '' ? '' : this.state.oldImageUri
            }
        };

        UserAPI.editAccount(newInfoModel)
            .then(() => {
                const userId = this.context.userId;
                if (this.state.imageUri && this.state.imageUri !== DOMAIN + this.state.oldImageUri) {
                    const imageFile = UploadImage.createImageFile(this.state.oldImageUri,
                        this.state.imageUri, 'user', userId, this.context.userId);
                    UserAPI.addUserImage(userId, imageFile)
                        .then(() => navigation.pop())
                        .catch(err => console.log(err));
                } else {
                    navigation.pop()
                }
            }).catch(err => {
            console.log(err);
        });
    }

    render() {
        let {imageUri} = this.state;

        return (
            <View style={styles.container}>
                <ScrollView style={styles.container}>
                    <View style={styles.imageContainer}>
                        {imageUri !== '' && imageUri !== undefined && imageUri !== null &&
                        <Image source={{uri: imageUri}} style={styles.img}/>}
                    </View>
                    {imageUri !== '' && imageUri !== undefined && imageUri !== null &&
                    <View style={{position: 'absolute', right: '19.4%', top: '0.3%'}}>
                        <Icon name='times-circle-o' type='font-awesome' size={25} color={Colors.text}
                              onPress={() => this.setState({imageUri: ''})}/>
                    </View>
                    }
                    <View style={styles.imageIcons}>
                        <View style={{marginRight: 10, padding: '1%', borderWidth: 1, borderRadius: 10}}>
                            <Icon name='camera' type='font-awesome' size={30} color={Colors.text}
                                  onPress={async () => this.setState(await UploadImage.getImageFromCamera())}/>
                        </View>
                        <View style={{padding: '1%', borderWidth: 1, borderRadius: 10}}>
                            <Icon name='picture-o' type='font-awesome' size={30} color={Colors.text}
                                  onPress={async () => this.setState(await UploadImage.getImageFromCameraRoll())}/>
                        </View>
                    </View>
                    <RInputField
                        label={i18n.t('firstName')}
                        placeholder={i18n.t('account.placeholder.editFirstName')}
                        onChange={firstName => this.setState({firstName})}
                        value={this.state.firstName}
                        type={'default'}
                        required={true}
                    />
                    <RInputField
                        label={i18n.t('lastName')}
                        placeholder={i18n.t('account.placeholder.editLastName')}
                        onChange={lastName => this.setState({lastName})}
                        value={this.state.lastName}
                        type={'default'}
                        required={true}
                    />
                    <RInputField
                        label={i18n.t('phoneNumber')}
                        placeholder={i18n.t('account.placeholder.editPhoneNumber')}
                        onChange={phoneNumber => this.setState({phoneNumber})}
                        value={this.state.phoneNumber}
                        type={'phoneNumber'}
                        required={true}
                    />
                </ScrollView>
                {
                    this.state.keyboardShown ?
                        <View style={styles.btn}>
                            <Icon raised reverse name='arrow-down' type='font-awesome'
                                  color={Colors.primary} size={25} onPress={() => Keyboard.dismiss()}/>
                        </View>
                        :
                <View style={styles.btn}>
                    <Icon raised reverse name='check' type='font-awesome'
                          color={Colors.success} size={25} onPress={() => this.editAccount()}/>
                </View>
                }
            </View>

        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.backgroundColor
    },
    btn: {
        alignItems: 'center',
        borderTopWidth: StyleSheet.hairlineWidth,
        borderColor: Colors.text
    },
    img: {
        borderWidth: 1,
        borderRadius: 10,
        width: 200,
        height: 200,
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: '1%'
    },
    imageIcons: {
        flexDirection: 'row',
        justifyContent: 'center'
    },
    imageContainer: {
        alignItems: 'center',
        marginBottom: '4%',
        marginTop: '4%'
    }
});
