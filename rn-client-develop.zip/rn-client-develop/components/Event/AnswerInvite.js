import React, { Component } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import InviteAPI from '../../api/InviteApiHandler';
import UserContext from "../../context/user-context";
import AnswerButton from "./AnswerButton"
import i18n from "i18n-js";

export default class AnswerInvite extends Component{
    static contextType = UserContext;

    constructor(props){
        super(props);
        this.state = {
            status: props.status
        }
    }

    sendAnswer(status){
        this.setState({status});
        InviteAPI.answerInvite(status, this.props.id, this.context.userId, this.context.token)
            // Update event screen
            .then(() => {
                if (this.props.onPress) {
                    this.props.onPress();
                }
                if (this.props.updateEvent) {
                    this.props.updateEvent();
                }
            })
            .catch(e => console.log(e));
    }

    render(){
        return(
            <View>
                <Text style={styles.txt}>{i18n.t('invite.attendingQuestion')}</Text>
                 <View style={styles.buttonContainer}>
                     {/* 1 = Attending (green), 2 = Invited (yellow), 3 = Not Attending (red)*/}
                     <AnswerButton active={1===this.state.status} status={1} onPress = {() => this.sendAnswer(1)}/>
                     <AnswerButton active={0===this.state.status} status={0} onPress = {() => this.sendAnswer(0)}/>
                     <AnswerButton active={2===this.state.status} status={2} onPress = {() => this.sendAnswer(2)}/>
                </View>
            </View>
        )
    }

}

const styles = StyleSheet.create({
    buttonContainer: {
        flexDirection: "row",
        alignContent: "center",
        marginTop: 5
    },
    txt: {
        marginLeft: 7,
        marginTop: 2
    }
})
