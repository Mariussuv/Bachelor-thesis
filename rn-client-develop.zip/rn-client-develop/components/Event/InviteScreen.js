import React, {Component} from 'react';
import {View, StyleSheet, Text, TouchableHighlight} from 'react-native';
import UserContext from '../../context/user-context';
import {ScrollView} from 'react-native-gesture-handler';
import UserAPI from '../../api/UserApiHandler';
import GroupAPI from "../../api/GroupApiHandler";
import InviteAPI from "../../api/InviteApiHandler";
import i18n from "i18n-js";
import GroupTeaser from "../Group/GroupTeaser";
import UserTeaser from "../User/UserTeaser";
import Colors from "../../constants/Colors";
import {Icon} from "react-native-elements";

export default class InviteScreen extends Component {
    static contextType = UserContext;

    constructor(props) {
        super(props);
        this.state = {
            friends: [],
            selectedUserIds: [],
            selectedGroupIds: [],
            loading: true,
            tab: 'friends',
            borderWidthGroups: 0,
            borderWidthFriends: 1,
            groupsWithMembers: []
        };

        this.invite = this.invite.bind(this);
        this.changeTab = this.changeTab.bind(this);
    }

    componentDidMount() {
        UserAPI.getUsers()
            .then(users => {
                // Remove self from friend list
                const friends = users.filter(user => user.id !== this.context.userId)
                    .sort((a,b) => (a.firstName < b.firstName) ? -1 : (a.firstName > b.firstName) ? 1 : 0);
                this.setState({friends});
                this.setState({loading: false});
            }).catch(err => {
            console.log('Could not fetch from API' + err);
        });
        GroupAPI.getGroups(this.context.token, this.context.userId)
            .then(groupsWithMembers => {
                groupsWithMembers.sort((a,b) =>
                    (a.group.groupName < b.group.groupName) ? -1 : (a.group.groupName > b.group.groupName) ? 1 : 0);
                this.setState({groupsWithMembers, loading: false});
            });
    }

    invite(eventId, event, userIds) {
        // If adding people to existing event, just navigate back if noe new people are selected
        if (userIds?.length > 0 && !this.state.selectedGroupIds && this.state.selectedUserIds) {
            this.props.navigation.navigate("EventDetails");
            return;
        }

        // Get selected groupsWithMembers from the list of selected groupIds
        const selectedGroupsWithMembers = this.state.groupsWithMembers.filter((g) => {
            return this.state.selectedGroupIds.includes(g.group.id);
        });

        // Extract the members from the selected groups
        let membersFromSelectedGroups = [];
        selectedGroupsWithMembers.forEach(g =>
            membersFromSelectedGroups = [...membersFromSelectedGroups, ...g.users]);

        // Extract memberIds from users
        let memberIdsFromSelectedGroups = [];
        membersFromSelectedGroups.forEach(m => {
            memberIdsFromSelectedGroups = [...memberIdsFromSelectedGroups, m.id]
        });

        // Remove duplicates
        const uniqueMemberIdsSet = new Set(
            [...memberIdsFromSelectedGroups, ...this.state.selectedUserIds]);

        //Remove owner in case the user is added via groups
        const uniqueMemberIdsWithoutOwner = userIds ? [...uniqueMemberIdsSet].filter(id => !userIds.includes(id))
            : [...uniqueMemberIdsSet].filter(id => id !== this.context.userId);

        //Add owner to invite. Adds to end, so the invitationId easily can be found.
        const uniqueMemberIdsWithOwner = userIds && userIds.includes(this.context.userId) ?  uniqueMemberIdsWithoutOwner
            : [...uniqueMemberIdsWithoutOwner, this.context.userId];

        const model = {
            userId: this.context.userId,
            token: this.context.token,
            EventId: eventId,
            InvitedUserIds: uniqueMemberIdsWithOwner
        };
        InviteAPI.inviteUsers(model)
            .then((invitations) => {
                const inviteId = invitations[invitations.length - 1]?.id;
                InviteAPI.answerInvite(1, inviteId, this.context.userId, this.context.token)
                    .catch(err => console.log(err));
                this.props.navigation.popToTop();
                this.props.navigation.navigate("EventDetails", {event, invitations, status: 1, id: inviteId})
            })
            .catch(error => {
                console.log(error)
            });
    };

    changeTab(tab) {
        if (tab === 'friends') {
            this.setState({borderWidthFriends: 1, borderWidthGroups: 0, tab: 'friends'})
        } else {
            this.setState({borderWidthGroups: 1, borderWidthFriends: 0, tab: 'groups'})
        }
    }

    selectUser(userId) {
        if (!this.state.selectedUserIds.includes(userId)) {
            const selectedUserIds = [...this.state.selectedUserIds, userId];
            this.setState({selectedUserIds});
        } else {
            let filteredUsers = this.state.selectedUserIds.filter(function (selectedUserId) {
                return selectedUserId !== userId
            });
            this.setState({selectedUserIds: filteredUsers});
        }
    }

    selectGroup(groupId) {
        if (!this.state.selectedGroupIds.includes(groupId)) {
            const selectedGroupIds = [...this.state.selectedGroupIds, groupId];
            this.setState({selectedGroupIds});
        } else {
            const filteredGroups = this.state.selectedGroupIds.filter(function (selectedGroupId) {
                return selectedGroupId !== groupId
            });
            this.setState({selectedGroupIds: filteredGroups});
        }
    }


    render() {
        const {navigation} = this.props;
        const {event, userIds} = this.props.route.params;
        const eventId = event.id;
        return (
            <View style={styles.container}>
                {this.state.loading ?
                    <Text>Loading...</Text>
                    :
                    <View style={styles.tabContainer}>
                        <View style={styles.tabs}>
                            <TouchableHighlight style={[styles.friendsTab,
                                {
                                    borderWidth: this.state.borderWidthFriends,
                                    borderBottomWidth: this.state.borderWidthGroups
                                }]}
                                                activeOpacity={1} underlayColor={'transparent'}
                                                onPress={() => this.changeTab('friends')}>
                                <Text style={styles.label}>{i18n.t('friends')}</Text>
                            </TouchableHighlight>
                            <TouchableHighlight style={[styles.groupsTab,
                                {
                                    borderWidth: this.state.borderWidthGroups,
                                    borderBottomWidth: this.state.borderWidthFriends
                                }]}
                                                activeOpacity={1} underlayColor={'transparent'}
                                                onPress={() => this.changeTab('groups')}>
                                <Text style={styles.label}>{i18n.t('groups')}</Text>
                            </TouchableHighlight>
                        </View>
                        <View style={styles.tabBody}>
                            {
                                this.state.tab === 'friends' ?
                                    <ScrollView>
                                        <View style={{flex: 1}}>
                                            {this.state.friends.map(friend => {
                                                    if (userIds) {
                                                        if(!userIds.includes(friend.id)) {
                                                            return (
                                                                this.state.selectedUserIds.includes(friend.id) ?
                                                                    <UserTeaser selected={true}
                                                                                user={friend}
                                                                                key={friend.id}
                                                                                onPress={() => this.selectUser(friend.id)}/>
                                                                    :
                                                                    <UserTeaser selected={false}
                                                                                user={friend}
                                                                                key={friend.id}
                                                                                onPress={() => this.selectUser(friend.id)}/>)
                                                        }
                                                    } else {
                                                        return (
                                                            this.state.selectedUserIds.includes(friend.id) ?
                                                                <UserTeaser selected={true}
                                                                            user={friend}
                                                                            key={friend.id}
                                                                            onPress={() => this.selectUser(friend.id)}/>
                                                                :
                                                                <UserTeaser selected={false}
                                                                            user={friend}
                                                                            key={friend.id}
                                                                            onPress={() => this.selectUser(friend.id)}/>)
                                                    }
                                                }
                                            )}
                                        </View>
                                    </ScrollView>
                                    :
                                    <ScrollView>
                                        {this.state.groupsWithMembers.map(groupWithMembers => {
                                                return (
                                                    this.state.selectedGroupIds.includes(groupWithMembers.group.id) ?
                                                        <GroupTeaser key={groupWithMembers.group.id}
                                                                     groupWithMembers={groupWithMembers}
                                                                     navigation={navigation}
                                                                     selected
                                                                     selectable
                                                                     onPress={() => this.selectGroup(groupWithMembers.group.id)}
                                                                     updateGroup={this.updateGroup}/>
                                                        :
                                                        <GroupTeaser key={groupWithMembers.group.id}
                                                                     groupWithMembers={groupWithMembers}
                                                                     navigation={navigation}
                                                                     selectable
                                                                     onPress={() => this.selectGroup(groupWithMembers.group.id)}
                                                                     updateGroup={this.updateGroup}/>)
                                            }
                                        )}
                                    </ScrollView>
                            }
                        </View>
                    </View>
                }
                <View style={styles.btn}>
                    {
                        !this.state.loading &&
                        <Icon raised reverse name='check' type='font-awesome'
                              color={Colors.success} size={25} onPress={() => this.invite(eventId, event, userIds)}/>
                    }
                </View>
            </View>
        )
    }

}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.backgroundColor
    },
    tabContainer: {
        flex: 1,
        marginTop: 10
    },
    tabs: {
        flex: 1,
        flexDirection: 'row'
    },
    tabBody: {
        flex: 10
    },
    friendsTab: {
        flex: 1,
        borderLeftWidth: 0,
        borderTopRightRadius: 10,
        borderColor: Colors.text,
        alignItems: 'center'
    },
    groupsTab: {
        flex: 1,
        borderTopLeftRadius: 10,
        borderRightWidth: 0,
        borderColor: Colors.text,
        alignItems: 'center'
    },
    label: {
        fontSize: 25,
        marginLeft: '5%',
        marginTop: '2%',
        color: Colors.text
    },
    btn: {
        alignItems: 'center',
        borderTopWidth: StyleSheet.hairlineWidth,
        borderColor: Colors.text,
    }
});
