import React, {Component} from 'react';
import {StyleSheet, View, Text, Dimensions, TouchableHighlight, ScrollView, Image, RefreshControl} from 'react-native';
import moment from "moment";
import AnswerInvite from '../Event/AnswerInvite'
import {Icon} from "react-native-elements";
import i18n from "i18n-js";
import InviteAPI from "../../api/InviteApiHandler";
import UserContext from "../../context/user-context";
import UserTeaser from "../User/UserTeaser";
import EventAPI from "../../api/EventApiHandler";
import domain from "../../domain";
import Colors from '../../constants/Colors'

const DOMAIN = domain.getDomain();

export default class EventDetails extends Component {

    static contextType = UserContext;

    constructor(props) {
        super(props);
        const {event, invitations} = props.route.params;

        this.state = {
            borderWidthAttending: 1,
            borderWidthInvited: 0,
            event: event,
            invitations: invitations ? invitations : [],
            tab: 'attending',
            refreshing: false,
            eventOwner: ''
        };

        this.refresh = this.refresh.bind(this);
        this.changeTab = this.changeTab.bind(this);
        this.getInvitations = this.getInvitations.bind(this);
        this.addInvitations = this.addInvitations.bind(this);
    }

    componentDidMount() {
        this.getInvitations();
    }

    refresh = () => {
        this.setState({refreshing: true});
        this.loadEvent();
        this.setState({refreshing: false});
    };

    loadEvent() {
        EventAPI.getEvent(this.state.event.id, this.context.token, this.context.userId)
            .then(event => {
                this.setState({event, loading: false});
            }).catch(err => {
            console.log(err);
        });
        this.getInvitations();
    }

    getInvitations() {
        InviteAPI.getSpecificEventInvitations(this.state.event.id, this.context.token, this.context.userId)
            .then(invitations => {
                // Sort users alphabetically
                invitations.sort((a, b) => (a.user.firstName < b.user.firstName) ? -1 : (a.user.firstName > b.user.firstName) ? 1 : 0);

                // Get the eventOwner object and extract first and last name
                const eventOwnerInvite = invitations.filter(invitation => invitation.user.id === this.state.event.ownerId);
                const eventOwner = eventOwnerInvite[0].user.firstName + ' ' + eventOwnerInvite[0].user.lastName;
                this.setState({invitations, eventOwner});
            }).catch(err => console.log(err));
    }

    changeTab(tab) {
        if (tab === 'invited') {
            this.setState({borderWidthInvited: 1, borderWidthAttending: 0, tab: 'invited'})
        } else {
            this.setState({borderWidthAttending: 1, borderWidthInvited: 0, tab: 'attending'})
        }
    }

    addInvitations(event, navigation) {
        const userIds = [];
        this.state.invitations.forEach(i => userIds.push(i.user.id));
        navigation.navigate('InviteScreen', {event, userIds})
    }

    render() {
        const {navigation} = this.props;
        const {event, status, id, updateEvent} = this.props.route.params;
        const date = event.dateTime ? moment.utc(event.dateTime).local().format('DD.MM.YYYY') : '';
        const time = event.dateTime ? moment.utc(event.dateTime).local().format('HH:mm') : '';

        navigation.setOptions({
            headerTitle: '',
            headerRight: () => (
                this.context.userId === event.ownerId &&
                <View style={{flexDirection: 'row'}}>
                    <View style={{marginRight: 15, marginTop: 1}}>
                        <Icon name='user-plus' type='font-awesome' color='black' size={25} color={Colors.text}
                              onPress={() => this.addInvitations(event, navigation)}/>
                    </View>
                    <View style={{marginRight: 15}}>
                        <Icon name='edit' type='font-awesome' color='black' size={30} color={Colors.text}
                              onPress={() => navigation.navigate('EditEvent', {oldEvent: event, updateEvent})}/>
                    </View>
                </View>
            )
        });

        return (
            <View style={styles.container}>
                <ScrollView refreshControl={
                    <RefreshControl refreshing={this.state.refreshing} onRefresh={this.refresh}/>
                }>
                    <View style={styles.eventTitleContainer}>
                        <Text style={styles.eventTitle}>{event.title}</Text>
                        {
                            this.state.eventOwner !== '' &&
                            <Text style={styles.eventHost}>{i18n.t('event.hostedBy') + this.state.eventOwner}</Text>
                        }
                    </View>
                    {event.imageUri !== '' &&
                    <View
                        style={styles.imgContainer}>
                        <Image source={{uri: DOMAIN + event.imageUri}} style={styles.img}/>
                    </View>
                    }
                    <View style={styles.infoContainer}>
                        {
                            (time || date) &&
                            <View style={styles.dateTimeContainer}>
                                <View style={styles.dateContainer}>
                                    <Icon
                                        name='calendar'
                                        type='font-awesome'
                                        color={Colors.text}
                                        size={15}/>
                                    <Text style={styles.dateTimeTxt}>{date}</Text>
                                </View>
                                <View style={styles.timeContainer}>
                                    <Icon
                                        name='clock-o'
                                        type='font-awesome'
                                        color={Colors.text}
                                        size={16}/>
                                    <Text style={styles.dateTimeTxt}>{time}</Text>
                                </View>
                            </View>
                        }
                    </View>
                    {event.description !== '' &&
                    <View style={styles.descriptionContainer}>
                        <Text style={styles.label}>{i18n.t('description')}</Text>
                        <Text style={styles.descriptionTxt}>{event.description}</Text>
                    </View>
                    }
                    {
                        event.location !== '' &&
                        <View style={styles.locationContainer}>
                            <Text style={styles.label}>{i18n.t('location')}</Text>
                            <View style={styles.location}>
                                <Icon name='map-marker' color={'#B22222'} type='font-awesome' size={25}/>
                                <Text style={styles.locationTxt}>{event.location}</Text>
                            </View>
                        </View>
                    }
                    <View style={styles.tabContainer}>
                        <View style={styles.tabs}>
                            <TouchableHighlight style={[styles.attendingTab,
                                {
                                    borderWidth: this.state.borderWidthAttending,
                                    borderBottomWidth: this.state.borderWidthInvited
                                }]}
                                                activeOpacity={1} underlayColor={'transparent'}
                                                onPress={() => this.changeTab('attending')}>
                                <Text style={styles.label}>{i18n.t('attending')}</Text>
                            </TouchableHighlight>
                            <TouchableHighlight style={[styles.invitedTab,
                                {
                                    borderWidth: this.state.borderWidthInvited,
                                    borderBottomWidth: this.state.borderWidthAttending
                                }]}
                                                activeOpacity={1} underlayColor={'transparent'}
                                                onPress={() => this.changeTab('invited')}>
                                <Text style={styles.label}>{i18n.t('invited')}</Text>
                            </TouchableHighlight>
                        </View>
                        <View style={{maxHeight: Dimensions.get('window').height - 260}}>
                            {
                                this.state.tab === 'attending' ?
                                    <ScrollView nestedScrollEnabled={true} style={{marginTop: 10}}>
                                        {
                                            this.state.invitations.map(invitation => {
                                                if (invitation.status === 1) {
                                                    return (
                                                        <UserTeaser user={invitation.user} key={invitation.user.id}
                                                                    status={'attending'} onPress={() => ''}/>
                                                    )
                                                }
                                            })
                                        }
                                    </ScrollView>
                                    :
                                    <ScrollView nestedScrollEnabled={true} style={{marginTop: 10}}>
                                        {
                                            this.state.invitations.map(invitation => {
                                                if (invitation.status === 0) {
                                                    return (
                                                        <UserTeaser user={invitation.user} key={invitation.user.id}
                                                                    status={'invited'} onPress={() => ''}/>
                                                    )
                                                }
                                            })
                                        }
                                    </ScrollView>
                            }
                        </View>
                    </View>
                </ScrollView>
                <View style={styles.statusContainer}>
                    <AnswerInvite eventId={event.id} status={status} id={id}
                                  updateEvent={updateEvent ? updateEvent : ''} onPress={() => this.getInvitations()}/>
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.backgroundColor
    },
    eventTitleContainer: {
        marginTop: 20,
        marginBottom: 4,
        alignItems: 'center'
    },
    eventTitle: {
        fontSize: 25,
        textAlign: 'center',
        color: Colors.text
    },
    infoContainer: {
        paddingTop: 10,
        paddingBottom: 10,
        borderBottomWidth: 1,
        borderColor: Colors.text,
        borderTopWidth: 1,
        alignItems: 'center'
    },
    descriptionContainer: {
        padding: 6,
        marginBottom: 10
    },
    descriptionTxt: {
        fontSize: 15,
        marginLeft: 15,
        color: Colors.text
    },
    locationTxt: {
        fontSize: 15,
        marginLeft: 10,
        color: Colors.text
    },
    locationContainer: {
        padding: '2%',
    },
    location: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingLeft: '4%',
    },
    label: {
        fontSize: 20,
        marginTop: 5,
        fontWeight: 'bold',
        marginBottom: 10,
        color: Colors.text
    },
    tabContainer: {
        flex: 1,
        marginTop: 20
    },
    tabs: {
        flex: 1,
        flexDirection: 'row'
    },
    attendingTab: {
        flex: 1,
        borderTopRightRadius: 10,
        borderLeftWidth: 0,
        borderColor: Colors.text,
        alignItems: 'center'
    },
    invitedTab: {
        flex: 1,
        borderTopLeftRadius: 10,
        borderRightWidth: 0,
        borderColor: Colors.text,
        alignItems: 'center'
    },
    statusContainer: {
        borderTopWidth: StyleSheet.hairlineWidth,
        borderColor: Colors.text
    },
    imgContainer: {
        alignItems: 'center'
    },
    img: {
        width: 250,
        height: 250,
        borderWidth: 1,
        borderColor: Colors.text,
        borderRadius: 10,
        marginTop: '4%',
        marginBottom: '4%'
    },
    inviteUsersButton: {
        position: 'absolute',
        right: 10,
        bottom: 100,
    },
    dateTimeContainer: {
        flexDirection: 'row',
        justifyContent: 'center',
    },
    timeContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginLeft: 15
    },
    dateContainer: {
        flexDirection: 'row',
        alignItems: 'center'
    },
    dateTimeTxt: {
        fontSize: 18,
        marginLeft: 2,
        color: Colors.text
    },
    eventHost: {
        fontSize: 11,
        marginTop: 4
    }
});
