import React, {Component} from 'react';
import {StyleSheet, View, Alert, ScrollView, Image, Keyboard, Platform, Text} from 'react-native';
import RDateTimePicker from "../Basic/RDateTimePicker";
import UserContext from "../../context/user-context";
import RInputField from "../Basic/RInputField";
import EventAPI from "../../api/EventApiHandler";
import moment from "moment";
import {Icon} from "react-native-elements";
import i18n from "i18n-js";
import UploadImage from "../../systemComponents/UploadImageComponents";
import domain from "../../domain";
import {KeyboardAwareScrollView} from "react-native-keyboard-aware-scroll-view";
import Colors from "../../constants/Colors";

const DOMAIN = domain.getDomain();

export default class EditEvent extends Component {

    static contextType = UserContext;

    constructor(props) {
        super(props);

        const {navigation} = this.props;
        const {oldEvent, updateEvent} = props.route.params;

        this.state = {
            jsDateTime: moment.utc(oldEvent.dateTime).local().toDate(),
            aspNetDateTime: oldEvent.dateTime,
            title: oldEvent.title,
            description: oldEvent.description,
            location: oldEvent.location,
            id: oldEvent.id,
            ownerId: oldEvent.ownerId,
            oldEvent: oldEvent,
            updateEvent: updateEvent ? updateEvent : null,
            navigation: navigation,
            imageUri: oldEvent.imageUri !== '' && oldEvent.imageUri !== undefined ? DOMAIN + oldEvent.imageUri : '',
            oldImageUri: oldEvent.imageUri,
            oldImageUriWithDomain: DOMAIN + oldEvent.imageUri,
            imageExtension: '',
            keyboardShown: false,
            validate: false,
            validTitle: true
        };

        this.deleteEvent = this.deleteEvent.bind(this);
        this.editEvent = this.editEvent.bind(this);
    }

    componentDidMount() {
        Keyboard.addListener("keyboardDidShow", () => this.setState({keyboardShown: true}));
        Keyboard.addListener("keyboardDidHide", () => this.setState({keyboardShown: false}));
    }

    editEvent() {
        // An event is only valid if it has a title
        this.setState({validate: true});
        if (!this.state.validTitle) {
            return;
        }
        const eventModel = {
            userId: this.context.userId,
            token: this.context.token,
            event: {
                id: this.state.id,
                title: this.state.title,
                description: this.state.description,
                location: this.state.location,
                dateTime: this.state.aspNetDateTime,
                ownerId: this.state.ownerId,
                imageUri: this.state.imageUri === '' ? '' : this.state.oldImageUri
            }
        };
        EventAPI.editEvent(eventModel, this.state.id)
            .then(event => {
                if (this.state.imageUri !== '' &&
                    this.state.imageUri !== this.state.oldImageUriWithDomain) {
                    const imageFile = UploadImage.createImageFile(this.state.oldImageUri,
                        this.state.imageUri, 'event', event.id, this.context.userId);
                    EventAPI.addEventImage(event.id, imageFile, this.context.userId)
                        .then(eventWithImage => {
                            if (this.state.updateEvent) {
                                this.state.updateEvent();
                            }
                            this.state.navigation.navigate('EventDetails', {event: eventWithImage});
                        })
                        .catch(err => console.log(err));
                } else {
                    if (this.state.updateEvent) {
                        this.state.updateEvent();
                    }
                    this.state.navigation.navigate('EventDetails', {event});
                }
            }).catch(err => {
            console.log(err);
            this.state.navigation.navigate('EventDetails', {event: this.state.oldEvent});
        });
    }

    deleteEvent() {
        EventAPI.deleteEvent(this.state.oldEvent.id, this.context.userId, this.context.token)
            .then(() => {
                if (this.state.updateEvent) {
                    this.state.updateEvent();
                }
                this.state.navigation.popToTop()
            })
            .catch(err => console.log(err));
    }

    render() {
        let {imageUri} = this.state;

        return (
            <View style={styles.container}>
                <ScrollView style={styles.container}>
                    <KeyboardAwareScrollView behavior='padding'
                                             resetScrollToCoords={{x: 0, y: 0}}
                                             scrollEnabled={false}>
                        <View style={styles.imageContainer}>
                            {imageUri !== '' && <Image source={{uri: imageUri}} style={styles.img}/>}
                        </View>
                        {imageUri !== '' &&
                        <View style={{position: 'absolute', right: '19.4%', top: '0.3%'}}>
                            <Icon name='times-circle-o' type='font-awesome' size={25}
                                  onPress={() => this.setState({imageUri: ''})}/>
                        </View>
                        }
                        <View style={styles.imageIcons}>
                            <View style={{marginRight: 10, padding: '1%', borderWidth: 1, borderRadius: 10}}>
                                <Icon name='camera' type='font-awesome' size={30}
                                      onPress={async () => this.setState(await UploadImage.getImageFromCamera())}/>
                            </View>
                            <View style={{padding: '1%', borderWidth: 1, borderRadius: 10}}>
                                <Icon name='picture-o' type='font-awesome' size={30}
                                      onPress={async () => this.setState(await UploadImage.getImageFromCameraRoll())}/>
                            </View>
                        </View>
                        <RInputField
                            label={i18n.t('title')}
                            placeholder={i18n.t('event.placeholder.title')}
                            onChange={title => this.setState({title})}
                            value={this.state.title}
                            type={'default'}
                            required={true}
                            validate={this.state.validate}
                            onValidate={(validTitle) => this.setState({validTitle})}
                        />
                        <RInputField
                            label={i18n.t('description')}
                            placeholder={i18n.t('event.placeholder.description')}
                            onChange={description => this.setState({description})}
                            value={this.state.description}
                            multiline={true}
                            numberOfLines={3}
                            type={'default'}
                        />
                        <RInputField
                            label={i18n.t('location')}
                            placeholder={i18n.t('event.placeholder.location')}
                            type={'default'}
                            onChange={location => this.setState({location})}
                            value={this.state.location}
                        />

                        <View style={{marginTop: 10, marginBottom: 40}}>
                            <RDateTimePicker value={this.state.jsDateTime} onChange={(jsDateTime, aspNetDateTime) =>
                                this.setState({jsDateTime, aspNetDateTime})}/>
                        </View>
                    </KeyboardAwareScrollView>
                </ScrollView>
                {
                    this.state.keyboardShown && Platform.OS === 'android' ?
                    <View style={styles.footerBtnContainer}>
                        <Icon raised reverse name='arrow-down' type='font-awesome'
                              color={Colors.primary} size={25} onPress={() => Keyboard.dismiss()}/>
                    </View>
                        :
                <View style={styles.footerBtnContainer}>
                        <View style={[styles.btn]}>
                            <Icon raised reverse name='trash' type='font-awesome' color={Colors.danger} size={25}
                                onPress={() => Alert.alert(i18n.t('event.delete'), i18n.t('event.deleteMessage'),
                                    [{text: i18n.t('no')}, {text: i18n.t('yes'),
                                        onPress: () => this.deleteEvent()}])}/>
                        </View>
                    <View style={styles.btn}>
                        <Icon name='save' type='font-awesome' color={Colors.success} size={25} raised reverse
                              onPress={() => this.editEvent()}/>
                    </View>
                    {
                        this.state.validate && !this.state.validTitle && <Text style={styles.asterisk}>*</Text>
                    }
                </View>
                }
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.backgroundColor
    },
    btn: {
        alignItems: 'center',
        marginRight: 10,
    },
    img: {
        borderWidth: 1,
        borderColor: 'black',
        borderRadius: 10,
        width: 200,
        height: 200,
        alignItems: 'center',
        justifyContent: 'center',
    },
    imageIcons: {
        flexDirection: 'row',
        justifyContent: 'center'
    },
    imageContainer: {
        alignItems: 'center',
        marginBottom: '4%',
        marginTop: '4%'
    },
    footerBtnContainer: {
        flexDirection: 'row',
        justifyContent: 'center',
        padding: 4,
        borderTopWidth: StyleSheet.hairlineWidth,
        borderColor: Colors.text,
        backgroundColor: Colors.backgroundColor
    },
    asterisk: {
        color: 'firebrick',
        fontSize: 25,
    }
});
