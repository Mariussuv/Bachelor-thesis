import React, {Component} from 'react';
import {Image, View, Text, StyleSheet, TouchableHighlight, Dimensions} from 'react-native';
import calendar from '../../assets/images/calendar.png'
import moment from "moment";
import {Ionicons} from '@expo/vector-icons';
import domain from "../../domain";
import {Icon} from "react-native-elements";
import Colors from "../../constants/Colors";

const DOMAIN = domain.getDomain();

export default class EventTeaser extends Component {
    constructor(props) {
        super(props);
        this.state = {
            icon: "md-heart",
            iconColor: Colors.heart.yellow,
            locationLength: Math.round(Dimensions.get('window').width / 24),
            descriptionLength: Math.round(Dimensions.get('window').width / 12),
            titleLength: Math.round(Dimensions.get('window').width / 17)
        };

        this.updateStatus = this.updateStatus.bind(this);
    }

    componentDidMount() {
        this.updateStatus();
    }

    updateStatus() {
        switch (this.props.status) {
            case 1:
                this.setState({icon: "md-heart", iconColor: Colors.heart.green});
                break;
            case 2:
                this.setState({icon: "md-heart-dislike", iconColor: Colors.heart.red});
                break;
            default:
                this.setState({icon: "md-heart", iconColor: Colors.heart.yellow});
                break;
        }
    }

    render() {
        const {event, status, navigation, id, updateEvent} = this.props;
        const date = moment.utc(event.dateTime).local().format('DD.MM.YYYY');
        const time = moment.utc(event.dateTime).local().format('HH:mm');

        return (
            <TouchableHighlight style={styles.touchableContainer}
                                onPress={() => navigation.navigate('EventDetails',
                                    {event, status, id, updateEvent})}
                                activeOpacity={1} underlayColor='white'>
                <View style={styles.container}>
                    <View>
                        <Image source={event.imageUri ? { uri: DOMAIN + event.imageUri} : calendar} style={styles.img}/>
                    </View>
                    <View style={styles.txtContainer}>
                        <Text style={styles.title}>
                            {event?.title?.slice(0, this.state.titleLength)}
                            {event.title?.length > this.state.titleLength && '...'}

                        </Text>
                        <Text style={styles.description}>
                            {event.description?.slice(0, this.state.descriptionLength)}
                            {event.description?.length > this.state.descriptionLength && '...'}
                        </Text>
                        <View style={styles.locationAndTimeContainer}>
                            {
                                event.location !== null && event.location !== '' &&
                                <View style={styles.locationContainer}>
                                    <View style={styles.locationIconContainer}>
                                        <Icon name='map-marker' color={'#B22222'} type='font-awesome' size={10}/>
                                    </View>
                                    <Text style={styles.location}>{event.location.slice(0, this.state.locationLength)}
                                        {event.location?.length > this.state.locationLength ? '...' : ''
                                    }</Text>
                                </View>
                            }
                            <View style={styles.dateTimeContainer}>
                                <View style={styles.dateContainer}>
                                    <Icon
                                        name='calendar'
                                        type='font-awesome'
                                        color={Colors.text}
                                        size={10}/>
                                    <Text style={styles.dateTimeTxt}>{date}</Text>
                                </View>
                                <View style={styles.timeContainer}>
                                    <Icon
                                        name='clock-o'
                                        type='font-awesome'
                                        color={Colors.text}
                                        size={10}/>
                                    <Text style={styles.dateTimeTxt}>{time}</Text>
                                </View>
                            </View>
                        </View>
                    </View>
                    <View style={styles.heartContainer}>
                        <Ionicons color={this.state.iconColor} name={this.state.icon} size={32}/>
                    </View>
                </View>
            </TouchableHighlight>
        );
    }
}

const styles = StyleSheet.create({
    touchableContainer: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'flex-start',
    },
    container: {
        flexDirection: 'row',
        flex: 1,
        padding: 5,
        backgroundColor: Colors.backgroundColor
    },
    txtContainer: {
        flexDirection: 'column',
        flex: 1,
        alignSelf: 'stretch',
        textAlign: 'center',
        alignItems: 'stretch',
        marginLeft: 20,
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderColor: Colors.text,
    },
    img: {
        width: 70,
        height: 70,
        borderRadius: 50,
    },
    title: {
        fontSize: 18,
        fontWeight: 'bold',
        color: Colors.text,
    },
    description: {
        fontSize: 14,
        color: Colors.text,
    },
    date: {
        marginTop: 5,
        fontSize: 12,
        color: Colors.text,
    },
    location: {
        marginTop: 5,
        fontSize: 12,
        color: Colors.text
    },
    locationAndTimeContainer: {
        flexDirection: 'row',
    },
    locationContainer: {
        flexDirection: 'row',
        marginRight: 10,
    },
    locationIconContainer: {
        marginTop: 8,
        marginRight: 4,
    },
    heartContainer: {
        marginRight: 10,
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderColor: Colors.text,
    },
    dateTimeContainer: {
        flexDirection: 'row',
        justifyContent: 'center',
        marginTop: 5
    },
    timeContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginLeft: 10
    },
    dateContainer: {
        flexDirection: 'row',
        alignItems: 'center'
    },
    dateTimeTxt: {
        fontSize: 12,
        marginLeft: 2,
        color: Colors.text
    }
});
