import React, { Component } from 'react';
import {StyleSheet, TouchableHighlight} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Colors from "../../constants/Colors";

export default class RButton extends Component {
    constructor(props) {
        super(props);
        this.state = {
            color: 'white',
            txtColor: 'white',
            borderColor: 'black',
            icon: "md-heart",
            background: 'white'
        }
    }
    componentDidMount(){
        switch (this.props.status){
            case 0:
                this.setState({color: Colors.heart.yellow, icon: "md-heart", background: Colors.heart.green});
                break;
            case 1:
                this.setState({color: Colors.heart.green, icon: "md-heart", background: Colors.heart.green});
                break;
            case 2:
                this.setState({color: Colors.heart.red, icon: "md-heart-dislike", background: Colors.heart.green});
                break;
            default:
                this.setState({color: Colors.heart.green, icon: "md-heart"});
                break;
        }
    }

    render() {
        return (
                this.props.active ?
                <TouchableHighlight style={styles.active} onPress={() => this.props.onPress()}
                                    activeOpacity={0.85} underlayColor='transparent'>
                        <Ionicons color={this.state.color} name={this.state.icon} size={40}/>
                </TouchableHighlight>
                :
                <TouchableHighlight style={styles.container} onPress={() => this.props.onPress()}
                                    activeOpacity={0.85} underlayColor={'transparent'}>
                        <Ionicons color={this.state.color} name={this.state.icon} size={40}/>
                </TouchableHighlight>
        )
    }
}
const styles = StyleSheet.create({
    container: {
        alignItems: 'center',
        justifyContent: 'center',
        flex: 1,
        padding: 1,
        borderWidth: 1,
        borderRadius: 6,
        margin: 6,
        opacity: 0.3,
        height: 50
    },
    active: {
        alignItems: 'center',
        justifyContent: 'center',
        flex: 1,
        padding: 1,
        borderWidth: 1,
        borderRadius: 6,
        margin: 6,
        opacity: 1
    }
});
