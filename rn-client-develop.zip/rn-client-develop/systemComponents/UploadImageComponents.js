import Constants from "expo-constants";
import i18n from "i18n-js";
import * as Permissions from "expo-permissions";
import * as ImagePicker from "expo-image-picker";

/**
 * To use the camera module both permissions for camera and for camera roll is needed.
 */

class UploadImageComponents {

    /**
     *  Ask for permission to access camera and camera roll (only first time camera roll is accessed).
     * @returns bool
     */
    getCameraPermissionAsync = async () => {
        const {status} = Constants.platform.ios ? await Permissions.askAsync(Permissions.CAMERA) :
            await ImagePicker.requestCameraPermissionsAsync();
        if (status !== 'granted') {
            alert(i18n.t('error.cameraPermissions'));
            return false;
        } else {
           return true;
        }
    };

    /**
     *  Ask for permission to access camera roll (only first time camera roll is accessed)
     * @returns bool
     */
    getCameraRollPermissionAsync = async () => {
        // Different methods on iOS and Android
        const {status} = Constants.platform.ios ? await Permissions.askAsync(Permissions.CAMERA_ROLL)
            : await ImagePicker.requestCameraRollPermissionsAsync();
        if (status !== 'granted') {
            alert(i18n.t('error.cameraRollPermissions'));
            return false;
        } else {
            return true;
        }
    };

    /**
     * Opens camera module on phone and returns taken photo uri or empty string if cancelled
     * @returns {Promise<string>} imageUri
     */
    openCamera = async () => {
        try {
            let result = await ImagePicker.launchCameraAsync({
                allowsEditing: true,
                aspect: [1, 1],
                // Reduce image size to 20% to save cost on server
                quality: 0.2,
            });
            if (!result.cancelled) {
                return result.uri;
            } else {
                return '';
            }
        } catch (e) {
            console.log(e);
        }
    };

    /**
     * Opens camera roll on phone and returns the image uri or empty string if cancelled
     * @returns {Promise<string>}
     */
    openCameraRoll = async () => {
        try {
            let result = await ImagePicker.launchImageLibraryAsync({
                allowsEditing: true,
                aspect: [1, 1],
                // Reduce image size to 20% to save cost on server
                quality: 0.2,
            });
            if (!result.cancelled) {
                return result.uri;
            } else {
                return '';
            }
        } catch (E) {
            console.log(E);
        }
    };

    async getImageFromCameraRoll() {
        const permitted = await UploadImage.getCameraRollPermissionAsync();
        if(permitted) {
            const imageUri = await UploadImage.openCameraRoll();
            const imageExtension = imageUri?.substring(imageUri.lastIndexOf('.'), imageUri.length);
            return {imageUri, imageExtension};
        }
    }

    async getImageFromCamera() {
        const permittedCamera = await UploadImage.getCameraPermissionAsync();
        const permittedCameraRoll = await UploadImage.getCameraRollPermissionAsync();

        // Both permissions are needed to open the camera
        if(permittedCamera && permittedCameraRoll) {
            const imageUri = await UploadImage.openCamera();
            const imageExtension = imageUri?.substring(imageUri.lastIndexOf('.'), imageUri.length);
            return {imageUri, imageExtension};
        }
    }

    /**
     *
     * @param oldImageUri
     * @param newImageUri
     * @param type ('user', 'group' or 'event)
     * @param id
     * @param userId
     * @returns {FormData}
     */
    createImageFile(oldImageUri, newImageUri, type, id, userId) {
        const imageExtension = newImageUri.substring(newImageUri.lastIndexOf('.'), newImageUri.length);

        let newImageName = '';
        if (type === 'user') {
            // Format: <TYPE>_<USER_ID>_<RANDOM_NUMBER>_v<NUMBER> (v = version)
            newImageName = type + '_' + userId + '_' + Math.floor(Math.random() * 1000000) + '_v0' + imageExtension;
        } else {
            // Format: <TYPE>_<USER_ID>_ID<ID>_<RANDOM_NUMBER>_v<NUMBER> (v = version)
            newImageName = type + '_' + userId + '_ID' + id + '_' + Math.floor(Math.random() * 1000000) + '_v0' + imageExtension;
        }

        if (oldImageUri) {
            // Extract file name without file location, file extension and version.
            const oldImageName = oldImageUri.substring(oldImageUri.lastIndexOf('/')+1,
                oldImageUri.lastIndexOf('.'));

            // Extract image version and add 1 to get newImageVersion
            const newImageVersion = parseInt(oldImageName.substr(
                oldImageName.lastIndexOf('v') + 1, oldImageName.length)) + 1;

            const imageExtension = oldImageUri.substring(oldImageUri.lastIndexOf('.'), oldImageUri.length);
            newImageName = oldImageName.substring(0, oldImageName.lastIndexOf('v')+1) + newImageVersion + imageExtension;
        }

        let imageFile = new FormData();
        imageFile.append('image', {
            uri: newImageUri,
            name: newImageName,
            filename: newImageName,
            type: 'image/png'
        }, newImageName);
        imageFile.append('Content-Type', 'image/png');

        return imageFile;
    }
}

const UploadImage = new UploadImageComponents();
export default UploadImage;
