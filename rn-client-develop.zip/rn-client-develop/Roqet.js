import React, {Component} from 'react';
import {StyleSheet, View, AsyncStorage} from 'react-native';
import {NavigationContainer} from "@react-navigation/native";
import BottomTabNavigator from "./navigation/BottomTabNavigator";
import WelcomeScreen from "./screens/WelcomeScreen";
import {createStackNavigator} from '@react-navigation/stack';
import UserContext from "./context/user-context";
import EventDetails from "./components/Event/EventDetails";
import InviteScreen from "./components/Event/InviteScreen";
import NewEventScreen from "./screens/NewEventScreen";
import RegisterScreen1 from "./screens/RegisterScreen1";
import RegisterScreen2 from "./screens/RegisterScreen2";
import LoginScreen from "./screens/LoginScreen";
import EditEvent from "./components/Event/EditEvent";
import CreateGroup from "./components/Group/CreateGroup";
import * as Localization from 'expo-localization';
import i18n from "i18n-js";
import en from "./locales/en";
import nb_NO from "./locales/nb_NO";
import GroupDetails from "./components/Group/GroupDetails";
import EditGroup from "./components/Group/EditGroup";
import AccountScreen from "./components/Settings/AccountScreen";
import AboutUsScreen from "./components/Settings/AboutUsScreen";
import AboutAppScreen from "./components/Settings/AboutAppScreen";
import UserAPI from './api/UserApiHandler'
import Colors from "./constants/Colors";

const Stack = createStackNavigator();

// Set the key-value pairs for the different languages you want to support.
i18n.translations = {en, nb_NO};

// Set the locale once at the beginning of your app.
i18n.locale = Localization.locale.replace('-', '_');

// When a value is missing from a language it'll fallback to another language with the key present.
i18n.fallbacks = true;

export default class Roqet extends Component {
    constructor(props) {
        super(props);

        this.logIn = () => {
            this.setState({loggedIn: true})
        };
        this.logOut = () => {
            this.setState({loggedIn: false})
        };
        this.setUserId = (userId) => {
            this.setState({userId})
        };
        this.setToken = (token) => {
            this.setState({token})
        };

        this.state = {
            loggedIn: false,
            logIn: this.logIn,
            logOut: this.logOut,
            userId: '',
            setUserId: this.setUserId,
            token: '',
            setToken: this.setToken
        };

        this.getCredentialsFromAsyncStorage = this.getCredentialsFromAsyncStorage.bind(this);
    }

    componentDidMount() {
        this.getCredentialsFromAsyncStorage().catch(err => console.log(err));
    }

    getCredentialsFromAsyncStorage = async () => {
        try {
            const token = await AsyncStorage.getItem('@Roqet:Token') || '';
            const userId = await AsyncStorage.getItem('@Roqet:UserId') || '';
            if (userId && token) {
                UserAPI.verifyToken(token, userId).then(response => {
                    this.setState({userId, token: response, loggedIn: true});
                }).catch(err => console.log(err));
            }
        } catch (error) {
            // Error retrieving data
            console.log(error.message);
        }
    };

    render() {
        return (
            <UserContext.Provider value={this.state}>
                <View style={styles.container}>
                    {this.state.loggedIn ?
                        <NavigationContainer>
                            <Stack.Navigator screenOptions={{headerStyle: {backgroundColor: Colors.backgroundColor},
                                headerTintColor: Colors.text}}>
                                <Stack.Screen name={i18n.t('navigation.events')} component={BottomTabNavigator}/>
                                <Stack.Screen name="EventDetails" component={EventDetails}/>
                                <Stack.Screen name="EditEvent" component={EditEvent}
                                              options={{headerTitle: i18n.t('event.edit')}}/>
                                <Stack.Screen name="InviteScreen" component={InviteScreen}
                                              options={{headerTitle: i18n.t('invite.inviteSelected')}}/>
                                <Stack.Screen name="NewEventScreen" component={NewEventScreen}/>
                                <Stack.Screen name="CreateGroup" component={CreateGroup}
                                              options={{headerTitle: i18n.t('group.create')}}/>
                                <Stack.Screen name="GroupDetails" component={GroupDetails}/>
                                <Stack.Screen name="EditGroup" component={EditGroup}
                                              options={{headerTitle: i18n.t('group.edit')}}/>
                                <Stack.Screen name="AccountScreen" component={AccountScreen}
                                              options={{headerTitle: i18n.t('account.edit')}}/>
                                <Stack.Screen name="AboutUsScreen" component={AboutUsScreen}
                                              options={{headerTitle: i18n.t('about.aboutUs')}}/>
                                <Stack.Screen name="AboutAppScreen" component={AboutAppScreen}
                                              options={{headerTitle: i18n.t('about.aboutApp')}}/>
                            </Stack.Navigator>
                        </NavigationContainer>
                        :
                        <NavigationContainer>
                            <Stack.Navigator initialRouteName={WelcomeScreen}>
                                <Stack.Screen name="WelcomeScreen" component={WelcomeScreen}
                                              options={{headerShown: false, headerTitle: i18n.t('roqet')}}/>
                                <Stack.Screen name="RegisterScreen1" component={RegisterScreen1}
                                              options={{headerTitle: i18n.t('signUp')}}/>
                                <Stack.Screen name="RegisterScreen2" component={RegisterScreen2}
                                              options={{headerTitle: i18n.t('signUp')}}/>
                                <Stack.Screen name="LoginScreen" component={LoginScreen}
                                              options={{headerTitle: i18n.t('login')}}/>
                            </Stack.Navigator>
                        </NavigationContainer>
                    }
                </View>
            </UserContext.Provider>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.backgroundColor
    }
});
