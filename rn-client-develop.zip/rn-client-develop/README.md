# rn-client

    
  
##Build
    expo build:android
  
  - Choose APK
  
###Facebook hash key
    b3rR9cIdVtPrrS+epIqpJ9g4lTA=

   
   
   
##Markdown commands

See https://www.markdownguide.org/cheat-sheet/ for more commands




