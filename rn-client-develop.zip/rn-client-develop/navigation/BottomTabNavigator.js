import * as React from 'react';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import TabBarIcon from '../components/TabBarIcon';
import EventScreen from '../screens/EventScreen';
import GroupScreen from '../screens/GroupScreen';
import NewEventScreen from '../screens/NewEventScreen';
import SettingScreen from '../screens/SettingScreen';
import i18n from "i18n-js";
import Colors from "../constants/Colors";

const BottomTab = createBottomTabNavigator();
const INITIAL_ROUTE_NAME = 'Event';


export default function BottomTabNavigator({navigation, route}) {
    navigation.setOptions({ headerTitle: getHeaderTitle(route)});

  return (
    <BottomTab.Navigator initialRouteName={INITIAL_ROUTE_NAME}
                         tabBarOptions={{
                             activeBackgroundColor: Colors.backgroundColor,
                             inactiveTintColor: Colors.text,
                             keyboardHidesTabBar: true,
                             inactiveBackgroundColor: Colors.backgroundColor}}>
      <BottomTab.Screen
        name="Events"
        component={EventScreen}
        options={{
          title: i18n.t('navigation.events'),
          tabBarIcon: ({ focused }) =>
              <TabBarIcon
                  focused={focused}
                  name= {'md-calendar'}
              />,
        }}
      />
        <BottomTab.Screen
            name="NewEvent"
            component={NewEventScreen}
            options={{
                title: i18n.t('navigation.newEvent'),
                tabBarIcon: ({ focused }) => (
                    <TabBarIcon focused={focused} name={Platform.OS === 'ios' ? 'ios-add-circle' : 'md-add-circle'} />
                ),
            }}
        />
      <BottomTab.Screen
        name="Groups"
        component={GroupScreen}
        options={{
          title: i18n.t('navigation.groups'),
            tabBarIcon: ({ focused }) => (
                <TabBarIcon focused={focused} name={Platform.OS === 'ios' ? 'ios-people' : 'md-people'} />
            ),
        }}
      />
      <BottomTab.Screen
        name="Settings"
        component={SettingScreen}
        options={{
          title: i18n.t('navigation.settings'),
            tabBarIcon: ({ focused }) => (
                <TabBarIcon focused={focused} name={Platform.OS === 'ios' ? 'ios-settings' : 'md-settings'} />
            ),
        }}
      />
    </BottomTab.Navigator>
  );
}

function getHeaderTitle(route) {
    const routeName = route.state?.routes[route.state.index]?.name ?? INITIAL_ROUTE_NAME;

    switch (routeName) {
        case 'BottomTabNavigator':
            return i18n.t('navigation.events');
        case 'Groups':
            return i18n.t('navigation.groups');
        case 'NewEvent':
            return i18n.t('navigation.newEvent');
        case 'Settings':
            return i18n.t('navigation.settings');
    }
}
