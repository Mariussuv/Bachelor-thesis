import i18n from "i18n-js";
import domain from "../domain";

const API_DOMAIN = domain.getApiDomain();

class InviteApiHandler {

    async inviteUsers(model) {
        const response = await fetch(API_DOMAIN + 'invite/group', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(model)
        });
        if (!response.ok) {
            throw new Error(i18n.t('api.inviteUsersFailed') + response.status);
        }
        return response.json();
    }

    async findInvite(userId, token, eventId) {
        const response = await fetch(API_DOMAIN + 'invite/find', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({userId, token, invitedUserId: null, eventId})
        });
        if (!response.ok) {
            throw new Error(i18n.t('api.findInviteFailed') + response.status);
        }
        return response.json();
    }

    async answerInvite(status, eventId, userId, token) {
        const response = await fetch(API_DOMAIN + 'invite/id/' + eventId + '/status/' + status, {
            method: 'PUT',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({userId, token})
        });
        if (!response.ok) {
            throw new Error(i18n.t('api.answerInviteFailed') + response.status);
        }
    }

    async getSpecificEventInvitations(eventId, token, userId) {
        const response = await fetch(API_DOMAIN + 'invite/event/' + eventId, {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({userId, token})
        });
        if (!response.ok) {
            throw new Error(i18n.t('api.getSpecificEventInvitationsFailed') + response.status);
        }
        return response.json();
    }
}

const InviteAPI = new InviteApiHandler();
export default InviteAPI;
