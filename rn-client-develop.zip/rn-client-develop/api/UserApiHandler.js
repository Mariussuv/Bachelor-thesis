import * as Facebook from "expo-facebook";
import * as Google from 'expo-google-app-auth';
import i18n from "i18n-js";
import domain from "../domain";

const API_DOMAIN = domain.getApiDomain();
const FB_APP_ID = '519779408705749';
const FB_APP_NAME = 'Roqet';
const GOOGLE_CLIENT_ID = '1029560928731-0mivn083qnavrq5btj5or5vg33tqh12s.apps.googleusercontent.com';

class UserApiHandler {

    async registerUser(newUser) {
        const response = await fetch(API_DOMAIN + 'register', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(newUser),
        });
        if (!response.ok) {
            // TODO: Add different error messages for different cases (email already taken)
            throw new Error(i18n.t('api.registerUserFailed') + response.status)
        }
        return response.json();
    }

    async logIn(model) {
        const response = await fetch(API_DOMAIN + 'login', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(model)
        });
        if (!response.ok) {
            if (response.status === 502) {
                throw new Error(i18n.t('api.logInFailed') + response.status);
            }
            throw new Error(i18n.t('api.logInWrong'));
        }
        return response.json();
    }

    async authorizeWithFb() {
        await Facebook.initializeAsync(FB_APP_ID, FB_APP_NAME);
        const {type, token} = await Facebook.logInWithReadPermissionsAsync({
            permissions: ['public_profile', 'email'],
        });
        if (type === 'success') {
            const response = await fetch(API_DOMAIN + 'register/facebook/facebooktoken/' + token, {
                method: 'POST',
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'application/json',
                }
            });

            if (!response.ok) {
                if (response.status === 502) {
                    throw new Error(i18n.t('api.logInFailed') + response.status);
                }
                throw new Error(i18n.t('api.fbLoginFailed') + response.status);
            }
            return response.json();
        } else {
            throw new Error(i18n.t('api.fbRegisterFailed'));
        }
    }

    async authorizeWithGoogle() {
        const result = await Google.logInAsync({
            androidClientId: GOOGLE_CLIENT_ID,
            scopes: ['profile', 'email'],
        });

        if (result.type === 'success') {
            return result;
        } else {
            throw new Error(i18n.t('api.googleLoginFailed'));
        }
    }

    async getUsers() {
        const response = await fetch(API_DOMAIN + 'user');
        if (!response.ok) {
            throw new Error(i18n.t('api.getUsersFailed') + response.status);
        }
        return response.json();
    }

    async getUser(id) {
        const response = await fetch(API_DOMAIN + 'user/' + id);
        if (!response.ok) {
            throw new Error(i18n.t('api.getUserFailed') + response.status);
        }
        return response.json();
    }

    async editAccount(newInfoModel) {
        const response = await fetch(API_DOMAIN + 'user', {
            method: 'PUT',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(newInfoModel)
        });
        if (!response.ok) {
            throw new Error(i18n.t('api.editAccountFailed') + response.status);
        }
    }

    async addUserImage(userId, image) {
        const response = await fetch(API_DOMAIN + 'user/' + userId + '/image', {
            method: 'POST',
            headers: {
                Accept: 'multipart/form-data',
                'Content-Type': 'multipart/form-data',
            },
            body: image
        });
        if (!response.ok) {
            throw new Error(i18n.t('api.addUserImageFailed') + response.status);
        }
        return response.json();
    }

    async verifyToken(token, userId) {
        const response = await fetch(API_DOMAIN + 'verify', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({token, userId})
        });
        if (!response.ok) {
            throw new Error(i18n.t('api.verifyTokenFailed') + response.status);
        }
        return response.json();
    }
}

const UserAPI = new UserApiHandler();
export default UserAPI;
