import i18n from "i18n-js";
import domain from "../domain";

const API_DOMAIN = domain.getApiDomain();

class GroupApiHandler {

    async getGroups(token, userId) {
        const response = await fetch(API_DOMAIN + 'group/groups', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({userId, token})
        });
        if (!response.ok) {
            throw new Error(i18n.t('api.getGroupsFailed') + response.status);
        }
        return response.json();
    }

    async createGroup(groupModel) {
        const response = await fetch(API_DOMAIN + 'group', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(groupModel)
        });
        if (!response.ok) {
            throw new Error(i18n.t('api.createGroupFailed') + response.status);
        }
        return response.json();
    }

    async addGroupImage(groupId, image, userId) {
        const response = await fetch(API_DOMAIN + 'group/' + groupId + '/image/userId/' + userId, {
            method: 'POST',
            headers: {
                Accept: 'multipart/form-data',
                'Content-Type': 'multipart/form-data',
            },
            body: image
        });
        if (!response.ok) {
            throw new Error(i18n.t('api.addGroupImageFailed') + response.status);
        }
        return response.json();
    }

    async editGroup(model, groupId) {
        const response = await fetch(API_DOMAIN + 'group/' + groupId, {
            method: 'PATCH',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(model),
        });
        if (!response.ok) {
            throw new Error(i18n.t('api.editGroupFailed') + response.status);
        }
        return response.json();
    }

    async deleteGroup(groupId, userId, token) {
        const response = await fetch(API_DOMAIN + 'group/' + groupId, {
            method: 'DELETE',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({userId, token}),
        });
        if (!response.ok) {
            throw new Error(i18n.t('api.deleteGroupFailed') + response.status);
        }
    }
}

const GroupAPI = new GroupApiHandler();
export default GroupAPI;
