import i18n from "i18n-js";
import domain from "../domain";

const API_DOMAIN = domain.getApiDomain();

class EventApiHandler {
    async getEvents(token, userId) {
        const response = await fetch(API_DOMAIN + 'invite/invites', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({userId, token})
        });
        if (!response.ok) {
            throw new Error(i18n.t('api.getEventsFailed') + response.status);
        }
        return response.json();
    }

    async getEvent(id, token, userId) {
        const response = await fetch(API_DOMAIN + 'event/id/' + id, {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({userId, token})
        });
        if (!response.ok) {
            throw new Error(i18n.t('api.getEventFailed') + response.status);
        }
        return response.json();
    }

    async createNewEvent(_userId, _token, newEvent) {
        const response = await fetch(API_DOMAIN + 'event', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                userId: _userId,
                token: _token,
                event: newEvent
            }),
        });
        if (!response.ok) {
            throw new Error(i18n.t('api.createEventFailed') + response.status);
        }
        return response.json();
    }

    async addEventImage(eventId, image, userId) {
        const response = await fetch(API_DOMAIN + 'event/' + eventId + '/image/userId/' + userId, {
            method: 'POST',
            headers: {
                Accept: 'multipart/form-data',
                'Content-Type': 'multipart/form-data',
            },
            body: image
        });
        if (!response.ok) {
            throw new Error(i18n.t('api.addEventImageFailed') + response.status);
        }
        return response.json();
    }

    async editEvent(model) {
        const response = await fetch(API_DOMAIN + 'event/edit', {
            method: 'PUT',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(model),
        });
        if (!response.ok) {
            throw new Error(i18n.t('api.editEventFailed') + response.status);
        }
        return response.json();
    }

    async deleteEvent(eventId, userId, token) {
        const response = await fetch(API_DOMAIN + 'event/' + eventId, {
            method: 'DELETE',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({userId, token}),
        });
        if (!response.ok) {
            throw new Error(i18n.t('api.deleteEventFailed') + response.status);
        }
        return response.json();
    }

}

const EventAPI = new EventApiHandler();
export default EventAPI;
